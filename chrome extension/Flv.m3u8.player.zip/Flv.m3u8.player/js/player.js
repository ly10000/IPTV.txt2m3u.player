// 屏蔽普通日志和信息
console.log = function() {};
console.info = function() {};
document.addEventListener("DOMContentLoaded", function() {
    // ==================== EPG 相关配置 ====================
    const EPG_CONFIG = {
        UPDATE_INTERVAL: 30000,         // EPG信息更新间隔(30秒，缩短确保及时更新)
        PREVIEW_SHOW_TIME: 5000,        // 节目预告显示时间(5秒)
        MAX_EPG_CHANNELS: 100,          // 最大预加载EPG频道数
        EPG_CACHE_TIME: 5 * 60000       // EPG缓存时间(5分钟)
    };
    // ==================== 默认配置（使用毫秒） ====================
    const DEFAULT_CONFIG = {
        LOAD_TIMEOUT_MS: 10000,      // 10秒
        STALL_TIMEOUT_MS: 10000,     // 10秒
        MAX_RETRY_ROUNDS: 2,         // 2轮
        SEARCH_DEBOUNCE_MS: 300,     // 300毫秒
        PLAYLIST_REFRESH_INTERVAL: 1000 * 60 * 10,  // 10分钟
        AUTO_REFRESH_ENABLED: true,                 // 启用自动刷新
        BLACKLIST_URL: chrome.runtime.getURL('blacklist.txt'), // 黑名单文件URL
        SHOW_EPG: true,                           // 是否显示EPG信息
        EPG_UPDATE_INTERVAL: 1000*60*60,               // EPG更新间隔(60分钟)
        CUSTOM_EPG_URL: ''                        // 自定义EPG URL
    };
    // 实际使用的配置（会被用户设置覆盖）
    const CONFIG = { ...DEFAULT_CONFIG };
    const state = {
        player: null,
        isPlaying: false,
        videoUrl: "",
        baseUrl: "",
        currentPlaylist: [],
        originalPlaylistUrl: "",
        currentPlaylistIndex: -1,
        isM3UPlaylist: false,
        streamInfo: {
            resolution: "未知",
            type: "未知"
        },
        loadRequestId: 0,
        timers: {
            load: null,
            stall: null,
            controls: null,
            hidePlaylist: null,
            searchDebounce: null,
            refreshPlaylist: null,
            epgUpdate: null,          // EPG更新定时器
            epgPreview: null,         // EPG预告显示定时器
            epgCheck: null            // EPG状态检查定时器
        },
        currentChannelInfo: {
            title: "",
            originalIndex: -1,
            urls: []
        },
        blacklist: [],           // 黑名单关键词数组
        isBlacklistLoaded: false, // 黑名单是否已加载
        // EPG相关状态
        epgManager: null,       // EPG管理器实例
        currentEpgUrl: "",      // 当前EPG源URL（优先使用配置的）
        currentProgramme: null, // 当前节目信息
        nextProgramme: null,    // 下一个节目信息
        channelProgrammes: {},  // 频道节目缓存
        epgLoading: false,      // EPG加载状态
        epgLoadingError: false, // EPG加载错误状态
        epgLastUpdate: null     // EPG最后更新时间
    };
    const UI = {
        videoPlayer: document.getElementById("videoPlayer"),
        videoInfo: document.getElementById("videoInfo"),
        videoContainer: document.querySelector(".video-container"),
        controls: document.getElementById("controls"),
        playPauseBtn: document.getElementById("playPauseBtn"),
        backBtn: document.getElementById("backBtn"),
        prevChannelBtn: document.getElementById("prevChannelBtn"),
        nextChannelBtn: document.getElementById("nextChannelBtn"),
        volumeBtn: document.getElementById("volumeBtn"),
        fullscreenBtn: document.getElementById("fullscreenBtn"),
        playlistBtn: document.getElementById("playlistBtn"),
        closePlaylistBtn: document.getElementById("closePlaylistBtn"),
        clearSearchBtn: document.getElementById("clearSearchBtn"),
        infoBtn: null,
        progress: document.getElementById("progress"),
        progressBar: document.getElementById("progressBar"),
        timeDisplay: document.getElementById("time"),
        volumeSlider: document.getElementById("volumeSlider"),
        volumeProgress: document.getElementById("volumeProgress"),
        volumeContainer: document.querySelector(".volume-container"),
        playlistContainer: document.getElementById("playlist-container"),
        playlistItems: document.getElementById("playlist-items"),
        playlistSearchInput: document.getElementById("playlist-search-input"),
        loading: document.getElementById("loading"),
        errorMessage: document.getElementById("errorMessage"),
        infoPanel: null,
        switchSourceBtn: null,
        // EPG相关UI元素
        epgPanel: null,              // EPG信息面板
        epgCurrentProgramme: null,   // 当前节目显示
        epgNextProgramme: null,      // 下一个节目显示
        epgProgrammeList: null,      // 节目列表容器
        epgLoadingIndicator: null,   // EPG加载指示器
        epgStatus: null              // EPG状态显示
    };
    // ==================== EPG 相关函数 ====================
    /**
     * 初始化EPG管理器
     */
    function initEPGManager() {
        if (!state.epgManager) {
            state.epgManager = new EPGManager();
            console.log('[EPG] EPG管理器已初始化');
            // 监听EPG加载完成事件
            state.epgManager.onLoaded(() => {
                console.log('[EPG] EPG数据加载完成');
                state.epgLastUpdate = new Date();
                updateAllChannelEPG();
                updateCurrentProgrammeInfo();
                startEPGUpdateTimer();
            });
            // 立即检查是否有可用的EPG URL（从配置加载）
            if (state.currentEpgUrl && CONFIG.SHOW_EPG) {
                console.log('[EPG] 使用配置的EPG URL:', state.currentEpgUrl);
                setTimeout(() => {
                    loadEPG(state.currentEpgUrl);
                }, 500);
            }
        }
    }
    /**
     * 从播放列表中提取EPG URL
     */
    function extractEpgUrlFromPlaylist(playlist) {
        // 查找全局EPG URL
        if (playlist.metadata && playlist.metadata.epgUrl) {
            return playlist.metadata.epgUrl;
        }
        // 查找第一个频道的EPG信息
        if (playlist.length > 0) {
            const firstChannel = playlist[0];
            if (firstChannel.epgUrl) {
                return firstChannel.epgUrl;
            }
        }
        return null;
    }
    /**
     * 加载EPG数据
     */
    async function loadEPG(epgUrl) {
        if (!epgUrl || !state.epgManager) {
            console.log('[EPG] EPG URL或管理器不可用');
            return false;
        }
        // 检查是否已经加载了相同的EPG URL
        if (state.currentEpgUrl === epgUrl && state.epgManager.isLoaded) {
            console.log('[EPG] EPG数据已加载，跳过重复加载');
            return true;
        }
        // 检查EPG功能是否启用
        if (!CONFIG.SHOW_EPG) {
            console.log('[EPG] EPG功能已禁用，跳过加载');
            return false;
        }
        try {
            state.epgLoading = true;
            state.epgLoadingError = false;
            showEPGLoading(true);
            console.log(`[EPG] 开始加载EPG数据: ${epgUrl}`);
            showNotification('正在加载节目指南...', 2000);
            const result = await state.epgManager.fetchEPG(epgUrl, {
                autoRefresh: true,
                refreshInterval: CONFIG.EPG_UPDATE_INTERVAL
            });
            if (result.success) {
                state.currentEpgUrl = epgUrl;
                state.epgLoadingError = false;
                state.epgLastUpdate = new Date();
                console.log(`[EPG] EPG数据加载成功: ${result.channels}个频道, ${result.programs}个节目`);
                showNotification(`节目指南加载完成 (${result.programs}个节目)`, 3000);
                // 立即更新所有频道EPG信息
                updateAllChannelEPG();
                updateCurrentProgrammeInfo();
                return true;
            } else {
                console.warn('[EPG] EPG数据加载失败:', result.error);
                state.epgLoadingError = true;
                showNotification(`节目指南加载失败: ${result.error}`, 5000);
                return false;
            }
        } catch (error) {
            console.error('[EPG] EPG加载异常:', error);
            state.epgLoadingError = true;
            showNotification(`节目指南加载异常: ${error.message}`, 5000);
            return false;
        } finally {
            state.epgLoading = false;
            showEPGLoading(false);
            updateInfoPanel();
        }
    }
    /**
     * 更新所有频道的EPG信息
     */
    function updateAllChannelEPG() {
        if (!state.epgManager || !state.epgManager.isLoaded) {
            console.log('[EPG] EPG管理器未就绪，跳过更新');
            return;
        }
        console.log('[EPG] 开始更新所有频道EPG信息');
        // 为每个频道加载节目信息
        state.currentPlaylist.forEach((channel, index) => {
            const channelName = channel.tvgName || channel.title;
            if (channelName) {
                const programmes = state.epgManager.getProgrammes(channelName, {
                    maxResults: 5,
                    includeCurrent: true
                });
                if (programmes.length > 0) {
                    state.channelProgrammes[channelName] = programmes;
                    console.log(`[EPG] 频道 "${channelName}" 找到 ${programmes.length} 个节目`);
                }
            }
        });
        // 更新播放列表显示
        if (!UI.playlistContainer.classList.contains("hidden")) {
            renderPlaylist(UI.playlistSearchInput.value);
        }
        // 更新当前频道节目信息
        updateCurrentProgrammeInfo();
        state.epgLastUpdate = new Date();
        console.log('[EPG] 所有频道EPG信息更新完成');
    }
    /**
     * 更新当前播放频道的节目信息
     */
// 最小化修复：让 updateCurrentProgrammeInfo 模拟"预热"行为
function updateCurrentProgrammeInfo() {
    if (!state.epgManager || !state.epgManager.isLoaded) {
        console.log('[EPG] EPG管理器未就绪，无法更新当前节目信息');
        return;
    }
    const currentChannel = state.currentPlaylist[state.currentPlaylistIndex];
    if (!currentChannel) {
        console.log('[EPG] 当前无播放频道，跳过节目信息更新');
        return;
    }
    const channelName = currentChannel.tvgName || currentChannel.title;
    if (!channelName) {
        console.log('[EPG] 频道名称无效，跳过节目信息更新');
        return;
    }
    console.log(`[EPG修复] 更新频道 "${channelName}" 的节目信息`);
    // 关键修复：不使用 getCurrentProgramme，直接使用 getProgrammes
    // 并且使用与右键预览相同的参数！
    // 关键：只获取当前和未来的节目
    const programmes = state.epgManager.getProgrammes(channelName, {
        maxResults: 10,
        includeCurrent: true,
        includePast: false,  // 改为false，不包含过去节目！
        includeFuture: true
    });
    console.log(`[EPG修复] 查询到 ${programmes.length} 个节目`);
    const now = new Date();
    let currentProgramme = null;
    if (programmes.length > 0) {
        // 方法1：查找当前节目（精确）
        currentProgramme = programmes.find(p => p.start <= now && p.stop > now);
        // 方法2：如果没有当前节目，找即将开始的节目
        if (!currentProgramme) {
            const upcoming = programmes.filter(p => p.start > now);
            if (upcoming.length > 0) {
                currentProgramme = upcoming[0];
                console.log(`[EPG修复] 使用即将开始的节目: ${currentProgramme.title}`);
            }
        }
        // 方法3：如果还是没有，但节目列表不为空，使用第一个
        if (!currentProgramme) {
            currentProgramme = programmes[0];
            console.log(`[EPG修复] 使用列表第一个节目: ${currentProgramme.title}`);
        }
    } else {
        // 如果没找到当前/未来节目，尝试包含过去节目查找最近结束的
        console.log(`[EPG修复] 无当前/未来节目，查找最近结束的节目`);
        const allProgrammes = state.epgManager.getProgrammes(channelName, {
            maxResults: 5,
            includePast: true,
            includeFuture: false
        });
        if (allProgrammes.length > 0) {
            // 找最近结束的节目
            const recentlyEnded = allProgrammes.filter(p => 
                (now - p.stop) < 30 * 60 * 1000  // 30分钟内结束
            );
            if (recentlyEnded.length > 0) {
                currentProgramme = recentlyEnded[0];
                console.log(`[EPG修复] 使用最近结束的节目: ${currentProgramme.title}`);
            } else {
                currentProgramme = allProgrammes[0];
                console.log(`[EPG修复] 使用最早的节目: ${currentProgramme.title}`);
            }
        }
    }
    state.currentProgramme = currentProgramme;
    // 获取下一个节目
    if (currentProgramme) {
        // 重新获取节目列表用于找下一个
        const futureProgrammes = state.epgManager.getProgrammes(channelName, {
            maxResults: 5,
            includePast: false,
            includeFuture: true
        });
        if (futureProgrammes.length > 1) {
            // 如果当前节目在列表中，找下一个
            const currentIndex = futureProgrammes.findIndex(p => 
                p.title === currentProgramme.title && 
                p.start.getTime() === currentProgramme.start.getTime()
            );
            if (currentIndex >= 0 && currentIndex < futureProgrammes.length - 1) {
                state.nextProgramme = futureProgrammes[currentIndex + 1];
            } else {
                state.nextProgramme = futureProgrammes.length > 0 ? futureProgrammes[0] : null;
            }
        } else {
            state.nextProgramme = null;
        }
    } else {
        state.nextProgramme = null;
    }
    // 更新UI显示
    updateEpgUI();
    console.log(`[EPG修复] 节目信息更新完成: ${state.currentProgramme ? state.currentProgramme.title : '无当前节目'}`);
}
    /**
     * 更新EPG相关UI
     */
    function updateEpgUI() {
        // 更新视频信息栏
        updateVideoInfoWithEPG();
        // 更新EPG面板
        updateEpgPanel();
    }
    /**
     * 在视频信息栏显示EPG信息
     */
    function updateVideoInfoWithEPG() {
        const currentChannel = state.currentPlaylist[state.currentPlaylistIndex];
        if (!currentChannel) {
            UI.videoInfo.textContent = "无频道信息";
            return;
        }
        let infoText = currentChannel.title || `频道 ${state.currentPlaylistIndex + 1}`;
        if (state.currentProgramme && CONFIG.SHOW_EPG) {
            const programme = state.currentProgramme;
            const now = new Date();
            // 检查节目是否还在有效时间内
            if (now >= programme.start && now <= programme.stop) {
                const remainingMinutes = Math.max(0, Math.floor((programme.stop - now) / 60000));
                // 格式化节目信息
                let epgText = `【${programme.title}】`;
                if (remainingMinutes > 0) {
                    epgText += ` (${remainingMinutes}分钟后结束)`;
                } else {
                    epgText += ` (即将结束)`;
                }
                infoText += ' - ' + epgText;
            } else {
                // 节目已过期，尝试重新获取
                const channelName = currentChannel.tvgName || currentChannel.title;
                if (channelName && state.epgManager && state.epgManager.isLoaded) {
                    const currentProgramme = state.epgManager.getCurrentProgramme(channelName);
                    if (currentProgramme) {
                        state.currentProgramme = currentProgramme;
                        const remainingMinutes = Math.max(0, Math.floor((currentProgramme.stop - now) / 60000));
                        infoText += `【${currentProgramme.title}】 (${remainingMinutes}分钟后结束)`;
                    } else {
                        infoText += ' [节目信息已过期]';
                    }
                }
            }
        } else if (CONFIG.SHOW_EPG) {
            // 检查EPG状态
            if (!state.epgManager) {
                infoText += ' [EPG未初始化]';
            } else if (!state.epgManager.isLoaded) {
                infoText += ' [EPG加载中...]';
            } else {
                infoText += ' [无节目信息]';
            }
        }
        UI.videoInfo.textContent = infoText;
    }
    /**
     * 创建EPG面板
     */
    function createEpgPanel() {
        if (UI.epgPanel) return;
        // 创建EPG主面板
        UI.epgPanel = document.createElement('div');
        UI.epgPanel.className = 'epg-panel';
        UI.epgPanel.style.cssText = `
            position: fixed;
            top: 60px;
            left: 10px;
            background: rgba(0, 0, 0, 0.85);
            color: white;
            padding: 15px;
            border-radius: 8px;
            font-size: 12px;
            z-index: 1000;
            width: 300px;
            max-height: 400px;
            overflow-y: auto;
            display: none;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(10px);
        `;
        // 创建标题
        const title = document.createElement('div');
        title.className = 'epg-title';
        title.textContent = '节目指南';
        title.style.cssText = `
            font-weight: bold;
            font-size: 14px;
            margin-bottom: 10px;
            padding-bottom: 5px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
            display: flex;
            justify-content: space-between;
            align-items: center;
        `;
        // 创建关闭按钮
        const closeBtn = document.createElement('button');
        closeBtn.textContent = '×';
        closeBtn.title = '关闭';
        closeBtn.style.cssText = `
            background: none;
            border: none;
            color: white;
            font-size: 16px;
            cursor: pointer;
            padding: 0 5px;
        `;
        closeBtn.onclick = hideEpgPanel;
        title.appendChild(closeBtn);
        // 创建状态显示
        UI.epgStatus = document.createElement('div');
        UI.epgStatus.className = 'epg-status';
        UI.epgStatus.style.cssText = `
            font-size: 11px;
            color: #aaa;
            margin-bottom: 10px;
        `;
        // 创建当前节目区域
        const currentSection = document.createElement('div');
        currentSection.className = 'epg-current-section';
        currentSection.style.marginBottom = '15px';
        const currentLabel = document.createElement('div');
        currentLabel.textContent = '当前节目';
        currentLabel.style.cssText = `
            color: #4dabf7;
            font-weight: bold;
            margin-bottom: 5px;
            font-size: 13px;
        `;
        UI.epgCurrentProgramme = document.createElement('div');
        UI.epgCurrentProgramme.className = 'epg-current-programme';
        UI.epgCurrentProgramme.style.cssText = `
            background: rgba(77, 171, 247, 0.1);
            padding: 8px;
            border-radius: 4px;
            border-left: 3px solid #4dabf7;
        `;
        currentSection.appendChild(currentLabel);
        currentSection.appendChild(UI.epgCurrentProgramme);
        // 创建下一个节目区域
        const nextSection = document.createElement('div');
        nextSection.className = 'epg-next-section';
        nextSection.style.marginBottom = '15px';
        const nextLabel = document.createElement('div');
        nextLabel.textContent = '下一个节目';
        nextLabel.style.cssText = `
            color: #37b24d;
            font-weight: bold;
            margin-bottom: 5px;
            font-size: 13px;
        `;
        UI.epgNextProgramme = document.createElement('div');
        UI.epgNextProgramme.className = 'epg-next-programme';
        UI.epgNextProgramme.style.cssText = `
            background: rgba(55, 178, 77, 0.1);
            padding: 8px;
            border-radius: 4px;
            border-left: 3px solid #37b24d;
        `;
        nextSection.appendChild(nextLabel);
        nextSection.appendChild(UI.epgNextProgramme);
        // 创建节目列表标题
        const listTitle = document.createElement('div');
        listTitle.textContent = '后续节目';
        listTitle.style.cssText = `
            color: #f59f00;
            font-weight: bold;
            margin-bottom: 5px;
            font-size: 13px;
        `;
        // 创建节目列表容器
        UI.epgProgrammeList = document.createElement('div');
        UI.epgProgrammeList.className = 'epg-programme-list';
        // 创建加载指示器
        UI.epgLoadingIndicator = document.createElement('div');
        UI.epgLoadingIndicator.className = 'epg-loading';
        UI.epgLoadingIndicator.textContent = '加载中...';
        UI.epgLoadingIndicator.style.cssText = `
            text-align: center;
            padding: 20px;
            color: #aaa;
            font-style: italic;
            display: none;
        `;
        // 组装面板
        UI.epgPanel.appendChild(title);
        UI.epgPanel.appendChild(UI.epgStatus);
        UI.epgPanel.appendChild(currentSection);
        UI.epgPanel.appendChild(nextSection);
        UI.epgPanel.appendChild(listTitle);
        UI.epgPanel.appendChild(UI.epgProgrammeList);
        UI.epgPanel.appendChild(UI.epgLoadingIndicator);
        document.body.appendChild(UI.epgPanel);
        // 添加点击外部关闭功能
        document.addEventListener('click', function(event) {
            if (UI.epgPanel && UI.epgPanel.style.display !== 'none' && 
                !UI.epgPanel.contains(event.target) && 
                event.target !== UI.infoBtn) {
                hideEpgPanel();
            }
        });
        // 监听窗口大小变化
        window.addEventListener('resize', function() {
            if (UI.epgPanel && UI.epgPanel.style.display !== 'none') {
                updateEpgPanelPosition();
            }
        });
    }
    /**
     * 更新EPG面板位置
     */
    function updateEpgPanelPosition() {
        if (!UI.epgPanel) return;
        // 确保面板在可视区域内
        const panelRect = UI.epgPanel.getBoundingClientRect();
        const viewportWidth = window.innerWidth;
        const viewportHeight = window.innerHeight;
        let left = 10;
        let top = 60;
        // 如果面板超出右边界，调整位置
        if (left + panelRect.width > viewportWidth - 10) {
            left = viewportWidth - panelRect.width - 10;
        }
        // 如果面板超出下边界，调整位置
        if (top + panelRect.height > viewportHeight - 10) {
            top = viewportHeight - panelRect.height - 10;
        }
        UI.epgPanel.style.left = left + 'px';
        UI.epgPanel.style.top = top + 'px';
    }
    /**
     * 更新EPG面板内容
     */
    function updateEpgPanel() {
        if (!UI.epgPanel) return;
        const currentChannel = state.currentPlaylist[state.currentPlaylistIndex];
        if (!currentChannel) {
            UI.epgPanel.style.display = 'none';
            return;
        }
        const channelName = currentChannel.tvgName || currentChannel.title;
        // 更新状态
        if (state.epgManager && state.epgManager.isLoaded) {
            const stats = state.epgManager.getStats();
            UI.epgStatus.textContent = `已连接 EPG (${stats.channelCount}个频道, ${stats.totalProgrammes}个节目)`;
            if (state.epgLastUpdate) {
                const minutesAgo = Math.floor((new Date() - state.epgLastUpdate) / 60000);
                UI.epgStatus.textContent += ` · ${minutesAgo}分钟前更新`;
            }
        } else if (state.currentEpgUrl) {
            UI.epgStatus.textContent = '正在加载 EPG 数据...';
        } else {
            UI.epgStatus.textContent = '未配置 EPG 源';
        }
        // 更新当前节目
        if (state.currentProgramme) {
            const programme = state.currentProgramme;
            const now = new Date();
            const progress = ((now - programme.start) / (programme.stop - programme.start)) * 100;
            const remainingMinutes = Math.floor((programme.stop - now) / 60000);
            UI.epgCurrentProgramme.innerHTML = `
                <div style="font-weight: bold; margin-bottom: 3px;">${programme.title}</div>
                <div style="font-size: 11px; color: #ccc; margin-bottom: 3px;">
                    ${programme.start.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })} 
                    - ${programme.stop.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })}
                </div>
                <div style="font-size: 11px; color: #aaa; margin-bottom: 5px;">${programme.desc || '无描述'}</div>
                <div style="display: flex; align-items: center;">
                    <div style="flex-grow: 1; background: rgba(255, 255, 255, 0.2); height: 4px; border-radius: 2px; overflow: hidden;">
                        <div style="width: ${Math.min(100, Math.max(0, progress))}%; height: 100%; background: #4dabf7;"></div>
                    </div>
                    <div style="margin-left: 8px; font-size: 11px; color: #4dabf7;">
                        ${remainingMinutes > 0 ? `${remainingMinutes}分钟后结束` : '即将结束'}
                    </div>
                </div>
            `;
        } else {
            UI.epgCurrentProgramme.innerHTML = '<div style="color: #aaa; font-style: italic;">暂无节目信息</div>';
        }
        // 更新下一个节目
        if (state.nextProgramme) {
            const programme = state.nextProgramme;
            const startTime = programme.start.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' });
            UI.epgNextProgramme.innerHTML = `
                <div style="font-weight: bold; margin-bottom: 3px;">${programme.title}</div>
                <div style="font-size: 11px; color: #ccc; margin-bottom: 3px;">
                    ${startTime} 开始 (${programme.duration}分钟)
                </div>
                <div style="font-size: 11px; color: #aaa;">${programme.desc || '无描述'}</div>
            `;
        } else {
            UI.epgNextProgramme.innerHTML = '<div style="color: #aaa; font-style: italic;">暂无后续节目</div>';
        }
        // 更新节目列表
        updateProgrammeList(channelName);
        // 显示/隐藏加载指示器
        UI.epgLoadingIndicator.style.display = state.epgLoading ? 'block' : 'none';
    }
    /**
     * 更新节目列表
     */
    function updateProgrammeList(channelName) {
        if (!UI.epgProgrammeList || !channelName) return;
        UI.epgProgrammeList.innerHTML = '';
        if (!state.epgManager || !state.epgManager.isLoaded) {
            UI.epgProgrammeList.innerHTML = '<div style="color: #aaa; padding: 10px; text-align: center; font-style: italic;">EPG数据未加载</div>';
            return;
        }
        // 获取今日节目表
        const programmes = state.epgManager.getTodayRemainingProgrammes(channelName);
        if (programmes.length === 0) {
            UI.epgProgrammeList.innerHTML = '<div style="color: #aaa; padding: 10px; text-align: center; font-style: italic;">暂无节目信息</div>';
            return;
        }
        // 创建节目列表
        programmes.slice(0, 6).forEach((programme, index) => {
            const item = document.createElement('div');
            item.className = 'epg-programme-item';
            item.style.cssText = `
                padding: 8px;
                margin-bottom: 5px;
                background: ${index % 2 === 0 ? 'rgba(255, 255, 255, 0.05)' : 'transparent'};
                border-radius: 4px;
                cursor: pointer;
                transition: background 0.2s;
            `;
            item.onmouseenter = () => {
                item.style.background = 'rgba(255, 255, 255, 0.1)';
            };
            item.onmouseleave = () => {
                item.style.background = index % 2 === 0 ? 'rgba(255, 255, 255, 0.05)' : 'transparent';
            };
            const timeText = programme.start.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' });
            const isCurrent = programme.isCurrent;
            const isNext = programme.isNext;
            item.innerHTML = `
                <div style="display: flex; justify-content: space-between; margin-bottom: 3px;">
                    <div style="color: ${isCurrent ? '#4dabf7' : isNext ? '#37b24d' : '#ccc'}; font-weight: ${isCurrent || isNext ? 'bold' : 'normal'}">
                        ${timeText}
                    </div>
                    <div style="font-size: 11px; color: #f59f00;">${programme.duration}分钟</div>
                </div>
                <div style="font-size: 12px; ${isCurrent || isNext ? 'font-weight: bold' : ''}">
                    ${programme.title}
                    ${isCurrent ? ' (当前)' : isNext ? ' (下一个)' : ''}
                </div>
                ${programme.desc ? `<div style="font-size: 11px; color: #aaa; margin-top: 2px;">${programme.desc.substring(0, 40)}${programme.desc.length > 40 ? '...' : ''}</div>` : ''}
            `;
            UI.epgProgrammeList.appendChild(item);
        });
        // 如果还有更多节目，显示提示
        if (programmes.length > 6) {
            const moreItem = document.createElement('div');
            moreItem.className = 'epg-more-item';
            moreItem.textContent = `还有 ${programmes.length - 6} 个节目...`;
            moreItem.style.cssText = `
                text-align: center;
                color: #aaa;
                font-size: 11px;
                padding: 5px;
                font-style: italic;
                cursor: pointer;
            `;
            moreItem.onclick = () => {
                showNotification(`共有 ${programmes.length} 个节目`, 2000);
            };
            UI.epgProgrammeList.appendChild(moreItem);
        }
    }
    /**
     * 显示EPG面板
     */
    function showEpgPanel() {
        if (!UI.epgPanel) {
            createEpgPanel();
        }
        // 更新面板位置
        updateEpgPanelPosition();
        // 确保EPG信息是最新的
        checkAndFixEPGState();
        updateEpgPanel();
        UI.epgPanel.style.display = 'block';
        // 设置定时关闭
        if (state.timers.epgPreview) {
            clearTimeout(state.timers.epgPreview);
        }
        state.timers.epgPreview = setTimeout(() => {
            hideEpgPanel();
        }, 15000); // 15秒后自动关闭
    }
    /**
     * 隐藏EPG面板
     */
    function hideEpgPanel() {
        if (UI.epgPanel) {
            UI.epgPanel.style.display = 'none';
        }
    }
    /**
     * 切换EPG面板显示
     */
    function toggleEpgPanel() {
        if (!UI.epgPanel || UI.epgPanel.style.display === 'none') {
            showEpgPanel();
        } else {
            hideEpgPanel();
        }
    }
    /**
     * 显示EPG加载状态
     */
    function showEPGLoading(show) {
        if (!UI.epgLoadingIndicator) return;
        if (show) {
            UI.epgLoadingIndicator.textContent = '加载节目指南中...';
            UI.epgLoadingIndicator.style.display = 'block';
        } else {
            UI.epgLoadingIndicator.style.display = 'none';
        }
    }
    /**
     * 启动EPG更新定时器
     */
    function startEPGUpdateTimer() {
        stopEPGUpdateTimer();
        // 缩短更新间隔为30秒，确保及时更新
        state.timers.epgUpdate = setInterval(() => {
            if (state.epgManager && state.epgManager.isLoaded) {
                console.log('[EPG] 定时更新: 开始更新EPG信息');
                // 更新当前频道节目信息
                updateCurrentProgrammeInfo();
                // 如果EPG数据超过5分钟未更新，尝试重新加载所有频道EPG
                if (state.epgLastUpdate) {
                    const minutesSinceLastUpdate = Math.floor((new Date() - state.epgLastUpdate) / 60000);
                    if (minutesSinceLastUpdate >= 5) {
                        console.log(`[EPG] EPG数据已${minutesSinceLastUpdate}分钟未更新，重新加载所有频道EPG`);
                        updateAllChannelEPG();
                    }
                }
            } else {
                console.log('[EPG] 定时更新: EPG管理器未就绪');
            }
        }, CONFIG.EPG_UPDATE_INTERVAL);
        console.log(`[EPG] 启动更新定时器: ${CONFIG.EPG_UPDATE_INTERVAL / 1000}秒间隔`);
    }
    /**
     * 停止EPG更新定时器
     */
    function stopEPGUpdateTimer() {
        if (state.timers.epgUpdate) {
            clearInterval(state.timers.epgUpdate);
            state.timers.epgUpdate = null;
        }
    }
    /**
     * 检查并修复EPG状态
     */
    function checkAndFixEPGState() {
        console.log('[EPG] 状态检查开始');
        console.log(`epg 开关状态:  ${CONFIG.SHOW_EPG}`);
        // 检查EPG管理器
        if (!state.epgManager) {
            console.warn('[EPG] EPG管理器未初始化，尝试重新初始化');
            initEPGManager();
            return false;
        }
        // 检查EPG数据是否加载
        if (!state.epgManager.isLoaded) {
            console.warn('[EPG] EPG数据未加载');
            // 如果有EPG URL，尝试重新加载
            if (state.currentEpgUrl && CONFIG.SHOW_EPG) {
                console.log('[EPG] 尝试重新加载EPG数据');
                setTimeout(() => {
                    loadEPG(state.currentEpgUrl);
                }, 1000);
            }
            return false;
        }
        // 检查当前频道节目信息
        if (!state.currentProgramme) {
            console.log('[EPG] 当前频道无节目信息，尝试重新获取');
            updateCurrentProgrammeInfo();
        }
        // 检查EPG数据是否过期
        if (state.epgLastUpdate) {
            const minutesSinceLastUpdate = Math.floor((new Date() - state.epgLastUpdate) / 60000);
            if (minutesSinceLastUpdate >= 10) {
                console.log(`[EPG] EPG数据已${minutesSinceLastUpdate}分钟未更新，重新加载`);
                if (state.currentEpgUrl && CONFIG.SHOW_EPG) {
                    setTimeout(() => {
                        loadEPG(state.currentEpgUrl);
                    }, 2000);
                }
            }
        }
        return true;
    }
    /**
     * 显示频道节目预告（鼠标悬停或键盘选择时显示）
     */
    function showChannelProgrammePreview(channelName, element) {
        // 如果已经有预览在显示，先移除
        const existingPreview = document.querySelector('.programme-preview');
        if (existingPreview) {
            // 如果是同一个频道的预览，直接更新位置
            const existingChannel = existingPreview.dataset.channelName;
            if (existingChannel === channelName) {
                updatePreviewPosition(existingPreview, element);
                return;
            }
            existingPreview.remove();
        }
        const preview = document.createElement('div');
        preview.className = 'programme-preview';
        preview.dataset.channelName = channelName; // 标记预览对应的频道
        let programmes = [];
        if (state.epgManager && state.epgManager.isLoaded) {
            programmes = state.epgManager.getProgrammes(channelName, {
                maxResults: 4,
                includeCurrent: true,
                includePast: false
            });
        }
        let content = `<div style="font-weight: bold; margin-bottom: 10px; border-bottom: 1px solid rgba(255,255,255,0.2); padding-bottom: 5px;">${channelName}</div>`;
        if (programmes.length > 0) {
            programmes.forEach((programme, index) => {
                const timeText = programme.start.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' });
                const isCurrent = programme.isCurrent;
                content += `
                    <div style="margin-bottom: ${index === programmes.length - 1 ? '0' : '10px'}; 
                                 padding: ${isCurrent ? '8px' : '0'};
                                 background: ${isCurrent ? 'rgba(77, 171, 247, 0.2)' : 'transparent'};
                                 border-radius: 4px;">
                        <div style="display: flex; justify-content: space-between; margin-bottom: 3px;">
                            <div style="color: ${isCurrent ? '#4dabf7' : '#ccc'}; font-weight: ${isCurrent ? 'bold' : 'normal'}">
                                ${timeText}
                            </div>
                            <div style="font-size: 11px; color: #f59f00;">${programme.duration}分钟</div>
                        </div>
                        <div style="font-size: 13px; ${isCurrent ? 'font-weight: bold; color: #4dabf7' : ''}">
                            ${programme.title}${isCurrent ? ' (正在播放)' : ''}
                        </div>
                    </div>
                `;
            });
        } else {
            content += '<div style="color: #aaa; font-style: italic; padding: 10px 0; text-align: center;">暂无节目信息</div>';
        }
        // 添加关闭提示
        content += '<div style="font-size: 10px; color: #888; margin-top: 10px; text-align: center; border-top: 1px solid rgba(255,255,255,0.1); padding-top: 5px;">鼠标移开或按ESC关闭</div>';
        preview.innerHTML = content;
        // 设置预览位置
        updatePreviewPosition(preview, element);
        document.body.appendChild(preview);
        // 添加ESC键关闭支持
        const escHandler = (e) => {
            if (e.key === 'Escape' || e.keyCode === 27) {
                hideChannelProgrammePreview();
                document.removeEventListener('keydown', escHandler);
            }
        };
        document.addEventListener('keydown', escHandler);
        // 添加点击外部关闭功能
        const clickOutsideHandler = (e) => {
            if (!preview.contains(e.target) && e.target !== element && !element.contains(e.target)) {
                hideChannelProgrammePreview();
                document.removeEventListener('click', clickOutsideHandler);
            }
        };
        // 延迟绑定点击事件，避免立即触发
        setTimeout(() => {
            document.addEventListener('click', clickOutsideHandler);
        }, 100);
    }
    /**
     * 更新预览位置函数
     */
    function updatePreviewPosition(preview, element) {
        const rect = element.getBoundingClientRect();
        const viewportWidth = window.innerWidth;
        const viewportHeight = window.innerHeight;
        // 默认显示在右侧
        let left = rect.right + 10;
        let top = rect.top;
        // 如果右侧空间不足，显示在左侧
        if (left + 370 > viewportWidth) {
            left = rect.left - 370 - 10;
        }
        // 如果超出底部，调整位置
        if (top + 300 > viewportHeight) {
            top = viewportHeight - 300 - 10;
        }
        // 确保不会超出顶部
        top = Math.max(10, top);
        preview.style.left = `${left}px`;
        preview.style.top = `${top}px`;
    }
    /**
     * 隐藏节目预告函数
     */
    function hideChannelProgrammePreview() {
        const preview = document.querySelector('.programme-preview');
        if (preview) {
            preview.remove();
        }
    }
    // ==================== 键盘事件处理函数 ====================
    function handleKeyDown(e) {
        // 如果播放列表可见，优先处理播放列表相关快捷键
        if (!UI.playlistContainer.classList.contains("hidden")) {
            // ESC键：关闭播放列表和节目预览
            if (e.code === 'Escape' || e.key === 'Escape' || e.keyCode === 27) {
                e.preventDefault();
                hideChannelProgrammePreview(); // 先隐藏节目预览
                closePlaylist();
                return;
            }
            // 回车键：播放当前选中的项目
            if ((e.code === 'Enter' || e.key === 'Enter' || e.keyCode === 13)) {
                e.preventDefault();
                // 隐藏节目预览
                hideChannelProgrammePreview();
                playSelectedSearchResult();
                return;
            }
            // 上下箭头：在搜索结果中导航
            if (e.code === 'ArrowUp' || e.code === 'ArrowDown') {
                e.preventDefault();
                navigateSearchResults(e.code === 'ArrowUp' ? -1 : 1);
                return;
            }
            // 搜索框特殊处理
            if (e.target === UI.playlistSearchInput) {
                return;
            }
            // 其他按键在播放列表可见时不处理全局快捷键
            if (e.code === 'ArrowUp' || e.code === 'ArrowDown') {
                e.preventDefault();
                return;
            }
            if (e.code === 'ArrowLeft' || e.code === 'ArrowRight') {
                e.preventDefault();
                return;
            }
        }
        // 全局快捷键处理（仅当播放列表不可见时）
        // / 键：调出播放列表并定位搜索框
        if (e.key === '/' || e.code === 'Slash') {
            e.preventDefault();
            focusPlaylistSearch();
            showKeyFeedback('搜索播放列表');
        }
        // E键：显示节目指南
        else if (e.code === 'KeyE' || e.key === 'e') {
            e.preventDefault();
            if (CONFIG.SHOW_EPG) {
				toggleEpgPanel();
				showKeyFeedback('节目指南');
			} else { 
               	showNotification("⚠ EPG未启用", 1500);		
            }
            showControls();
        }
        // 空格键：播放/暂停
        else if (e.code === 'Space' || e.key === ' ' || e.keyCode === 32) {
            e.preventDefault();
            togglePlayPause();
            showControls();
            showKeyFeedback('空格键: ' + (UI.videoPlayer.paused ? '播放' : '暂停'));
        }
        // 上箭头键：增加音量（仅当播放列表不可见时）
        else if (e.code === 'ArrowUp') {
            e.preventDefault();
            const result = adjustVolumeByArrow(0.05);
            if (result.changed) {
                showKeyFeedback(`音量: ${result.newVolume}%`);
                showControls();
            } else {
                showKeyFeedback(`音量已达最大值: 100%`);
            }
        }
        // 下箭头键：减少音量（仅当播放列表不可见时）
        else if (e.code === 'ArrowDown') {
            e.preventDefault();
            const result = adjustVolumeByArrow(-0.05);
            if (result.changed) {
                showKeyFeedback(`音量: ${result.newVolume}%`);
                showControls();
            } else {
                showKeyFeedback(`音量已达最小值: 0%`);
            }
        }
        // 左箭头键：快退5秒（仅当播放列表不可见时）
        else if (e.code === 'ArrowLeft') {
            e.preventDefault();
            if (UI.videoPlayer.duration && !isNaN(UI.videoPlayer.duration)) {
                UI.videoPlayer.currentTime = Math.max(0, UI.videoPlayer.currentTime - 5);
                showKeyFeedback('快退: 5秒');
                showControls();
            }
        }
        // 右箭头键：快进5秒（仅当播放列表不可见时）
        else if (e.code === 'ArrowRight') {
            e.preventDefault();
            if (UI.videoPlayer.duration && !isNaN(UI.videoPlayer.duration)) {
                UI.videoPlayer.currentTime = Math.min(UI.videoPlayer.duration, UI.videoPlayer.currentTime + 5);
                showKeyFeedback('快进: 5秒');
                showControls();
            }
        }
        // F键：全屏切换
        else if (e.code === 'KeyF' || e.key === 'f') {
            e.preventDefault();
            toggleFullscreen();
            showKeyFeedback('全屏切换');
            showControls();
        }
        // M键：静音切换
        else if (e.code === 'KeyM' || e.key === 'm') {
            e.preventDefault();
            toggleMute();
            showKeyFeedback('静音: ' + (UI.videoPlayer.muted ? '关闭' : '开启'));
            showControls();
        }
        // P键：播放列表切换
        else if (e.code === 'KeyP' || e.key === 'p') {
            e.preventDefault();
            togglePlaylistUI();
            showKeyFeedback('播放列表');
            showControls();
        }
        // 左方括号键：上一个频道
        else if (e.code === 'BracketLeft' || e.key === '[') {
            e.preventDefault();
            switchToPrevChannel();
            //showKeyFeedback('上一个频道');
            showControls();
        }
        // 右方括号键：下一个频道
        else if (e.code === 'BracketRight' || e.key === ']') {
            e.preventDefault();
            switchToNextChannel();
            //showKeyFeedback('下一个频道');
            showControls();
        }
        // S键：手动换源
        else if (e.code === 'KeyS' || e.key === 's') {
            e.preventDefault();
            manualSwitchToNextSource();
            showKeyFeedback('手动换源');
            showControls();
        }
        // I键：显示/隐藏信息面板
        else if (e.code === 'KeyI' || e.key === 'i') {
            e.preventDefault();
            toggleVideoInfo();
            showKeyFeedback('信息面板');
            showControls();
        }
    }
    // 新增：关闭播放列表
    function closePlaylist() {
        // 隐藏所有节目预览
        hideChannelProgrammePreview();
        UI.playlistContainer.classList.add("hidden");
        UI.playlistSearchInput.blur();
        UI.playlistSearchInput.style.border = "";
        UI.playlistSearchInput.style.boxShadow = "";
        const selectedItem = UI.playlistItems.querySelector('.selected');
        if (selectedItem) {
            selectedItem.classList.remove('selected');
        }
        showKeyFeedback('关闭列表');
        showControls();
    }
    // 新增：在搜索结果中导航
    function navigateSearchResults(direction) {
        const searchTerm = UI.playlistSearchInput.value;
        const filteredItems = Array.from(UI.playlistItems.children)
            .filter(item => item.style.display !== 'none');
        if (filteredItems.length === 0) return;
        let currentIndex = -1;
        for (let i = 0; i < filteredItems.length; i++) {
            if (filteredItems[i].classList.contains('selected')) {
                currentIndex = i;
                break;
            }
        }
        let newIndex;
        if (currentIndex === -1) {
            newIndex = direction > 0 ? 0 : filteredItems.length - 1;
        } else {
            newIndex = currentIndex + direction;
            if (newIndex < 0) newIndex = filteredItems.length - 1;
            if (newIndex >= filteredItems.length) newIndex = 0;
        }
        // 移除之前选中项的样式和隐藏预览
        filteredItems.forEach(item => {
            item.classList.remove('selected');
        });
        // 隐藏当前预览
        hideChannelProgrammePreview();
        // 添加新选中项样式
        filteredItems[newIndex].classList.add('selected');
        // 滚动到选中项
        filteredItems[newIndex].scrollIntoView({
            behavior: 'smooth',
            block: 'nearest'
        });
        const itemText = filteredItems[newIndex].textContent;
        showKeyFeedback(`选中: ${itemText}`);
        maintainPlaylistFocus();
        // 为选中项显示节目预告
        const selectedItem = filteredItems[newIndex];
        const channelName = selectedItem.dataset.channelName;
        if (channelName) {
			if (CONFIG.SHOW_EPG) {
                // 延迟300ms显示，避免键盘快速导航时的频繁刷新
                setTimeout(() => {
                    showChannelProgrammePreview(channelName, selectedItem);
                    // 设置定时关闭预览（3秒后自动关闭）
                    if (state.timers.epgPreview) {
                        clearTimeout(state.timers.epgPreview);
                    }
                    state.timers.epgPreview = setTimeout(() => {
                        hideChannelProgrammePreview();
                    }, 3000);
                }, 300);
			}  
        }
    }
    // 新增：保持播放列表焦点状态
    function maintainPlaylistFocus() {
        if (!UI.playlistContainer.classList.contains("hidden") && 
            document.activeElement !== UI.playlistSearchInput &&
            !document.activeElement.classList.contains('playlist-item')) {
            UI.playlistContainer.classList.add('has-focus');
            const selectedItem = UI.playlistItems.querySelector('.selected');
            if (selectedItem) {
                selectedItem.focus();
            }
        }
    }
    // 新增：播放选中的搜索结果
    function playSelectedSearchResult() {
        const selectedItem = UI.playlistItems.querySelector('.selected');
        if (selectedItem) {
            const index = parseInt(selectedItem.dataset.index);
            if (!isNaN(index)) {
                playPlaylistItem(index);
                setTimeout(() => {
                    maintainPlaylistFocus();
                }, 100);
            }
        } else {
            showKeyFeedback('请先用上下箭头选择一个频道');
        }
    }
    // 新增：聚焦到播放列表搜索框
    function focusPlaylistSearch() {
        if (UI.playlistContainer.classList.contains("hidden")) {
            togglePlaylistUI(true);
        }
        setTimeout(() => {
            UI.playlistSearchInput.focus();
            UI.playlistSearchInput.select();
            UI.playlistSearchInput.style.border = "2px solid #4dabf7";
            UI.playlistSearchInput.style.boxShadow = "0 0 0 3px rgba(77, 171, 247, 0.3)";
            const selectedItem = UI.playlistItems.querySelector('.selected');
            if (selectedItem) {
                selectedItem.classList.remove('selected');
            }
            // 隐藏节目预览
            hideChannelProgrammePreview();
        }, 50);
    }
    // 修改：使用箭头键调整音量，返回调整结果
    function adjustVolumeByArrow(delta) {
        const oldVolume = UI.videoPlayer.volume;
        let newVolume = oldVolume + delta;
        newVolume = Math.max(0, Math.min(1, newVolume));
        const changed = Math.abs(newVolume - oldVolume) > 0.001;
        if (changed) {
            UI.videoPlayer.volume = newVolume;
            UI.videoPlayer.muted = (newVolume === 0);
            UI.volumeProgress.style.width = newVolume * 100 + "%";
            updateVolumeIcon();
            chrome.storage.local.set({
                volume: newVolume
            });
        }
        return {
            changed: changed,
            oldVolume: oldVolume * 100,
            newVolume: Math.round(newVolume * 100)
        };
    }
    // 新增：键盘操作视觉反馈
    function showKeyFeedback(message) {
        const existingFeedback = document.querySelector('.key-feedback');
        if (existingFeedback) {
            existingFeedback.remove();
        }
        const feedback = document.createElement('div');
        feedback.className = 'key-feedback';
        feedback.textContent = message;
        feedback.style.cssText = `
            position: fixed;
            bottom: 100px;
            left: 50%;
            transform: translateX(-50%);
            background: rgba(0, 100, 200, 0.9);
            color: white;
            padding: 10px 20px;
            border-radius: 25px;
            font-size: 14px;
            font-weight: bold;
            z-index: 1001;
            pointer-events: none;
            opacity: 1;
            box-shadow: 0 4px 12px rgba(0, 100, 200, 0.3);
            min-width: 120px;
            text-align: center;
        `;
        document.body.appendChild(feedback);
        setTimeout(() => {
            feedback.style.opacity = '0';
            feedback.style.transition = 'opacity 0.3s ease';
            setTimeout(() => {
                if (feedback.parentNode) {
                    feedback.parentNode.removeChild(feedback);
                }
            }, 300);
        }, 1000);
    }
    // ==================== 初始化函数 ====================
    function init() {
        addStyles();
        createDynamicUI();
        loadVolumeSettings();
        loadSettings();          // 必须先加载设置，以便获取EPG配置
        loadBlacklist();
        parseInitialUrl();
        initGlobalEvents();
        addButtonHoverEffects();
        initEPGManager();        // 然后初始化EPG管理器
        if (state.videoUrl) {
            UI.videoInfo.textContent = decodeURIComponent(state.videoUrl);
        }
        // 启动EPG状态定期检查
        if (CONFIG.SHOW_EPG) {
            state.timers.epgCheck = setInterval(() => {
                checkAndFixEPGState();
            }, 60000); // 每分钟检查一次
        }
    }
    function addStyles() {
        const style = document.createElement('style');
        style.textContent = `
            /* 原有样式 */
            .switch-source-btn:hover {
                background: rgba(255, 255, 255, 0.2);
                border-radius: 3px;
                transform: scale(1);
                transition: all 0.2s ease;
            }
            .switch-source-btn:active {
                transform: scale(1);
                transition: all 0.1s ease;
            }
            /* info-panel 样式 */
            .info-panel {
                display: none;
                position: absolute;
                bottom: 60px;
                right: 10px;
                background: rgba(0, 0, 0, 0.85);
                padding: 12px;
                border-radius: 6px;
                font-size: 12px;
                line-height: 1.5;
                z-index: 20;
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.5);
                backdrop-filter: blur(10px);
                border: 1px solid rgba(255, 255, 255, 0.1);
            }
            
            .info-label {
                color: #4dabf7 !important;
                font-weight: normal;
            }
            
            .info-maohao {
                color: #20c997 !important;
            }
			
            .info-value {
                color: white !important;
            }
            
            .info-line {
                margin-bottom: 3px;
            }
            @keyframes fadeInOut {
                0% { opacity: 0; transform: translate(-50%, -10px); }
                15% { opacity: 1; transform: translate(-50%, 0); }
                85% { opacity: 1; transform: translate(-50%, 0); }
                100% { opacity: 0; transform: translate(-50%, -10px); }
            }
            .blacklist-error {
                background: linear-gradient(135deg, #ff6b6b, #c92a2a) !important;
                border: 2px solid #ff6b6b !important;
                color: white !important;
                font-weight: bold !important;
                padding: 15px !important;
                border-radius: 8px !important;
            }
            /* 键盘反馈动画 */
            @keyframes keyFeedbackFlash {
                0% { transform: translateX(-50%) scale(0.9); opacity: 0; }
                15% { transform: translateX(-50%) scale(1.1); opacity: 1; }
                30% { transform: translateX(-50%) scale(1); opacity: 1; }
                85% { transform: translateX(-50%) scale(1); opacity: 1; }
                100% { transform: translateX(-50%) scale(0.9); opacity: 0; }
            }
            .key-feedback {
                animation: keyFeedbackFlash 1s ease;
            }
            /* 快捷键提示样式 */
            .shortcut-hint {
                position: absolute;
                top: 5px;
                right: 10px;
                background: rgba(0, 0, 0, 0.7);
                color: #aaa;
                padding: 6px 12px;
                border-radius: 6px;
                font-size: 11px;
                z-index: 10;
                cursor: help;
                transition: all 0.3s ease;
            }
            .shortcut-hint:hover {
                background: rgba(0, 0, 0, 0.9);
                color: white;
                transform: scale(1.05);
            }
            /* 快捷键提示更新 */
            .shortcut-hint table tr td:first-child b {
                color: #4dabf7;
            }
            /* 搜索框聚焦样式 */
            .playlist-search:focus {
                border-color: #4dabf7 !important;
                box-shadow: 0 0 0 3px rgba(77, 171, 247, 0.3) !important;
                outline: none !important;
            }
            /* 搜索结果选中样式 */
            .playlist-item.selected {
                background: linear-gradient(180deg, #000000, #000000) !important;
                color: white !important;
                font-weight: bold !important;
                border-left: 4px solid #f59f00 !important;
                outline: 2px solid #37b24d;
                outline-offset: -2px;
            }
            .playlist-item.selected:hover {
                background: linear-gradient(135deg, #339af0, #1864ab) !important;
            }
            /* 播放列表焦点状态 */
            #playlist-container:focus-within {
                border-color: #4dabf7;
            }
            .playlist-item:focus {
                outline: 2px solid #4dabf7;
                outline-offset: -2px;
            }
            /* 音量极限状态提示 */
            @keyframes limitFlash {
                0% { transform: translateX(-50%) scale(1); }
                50% { transform: translateX(-50%) scale(1.1); background: rgba(255, 59, 48, 0.9); }
                100% { transform: translateX(-50%) scale(1); }
            }
            .volume-limit {
                animation: limitFlash 0.5s ease;
            }
            /* EPG相关样式 */
            .epg-btn {
                background: none;
                border: none;
                color: white;
                cursor: pointer;
                margin-left: 10px;
                font-size: 16px;
                opacity: 0.8;
                transition: opacity 0.2s;
            }
            .epg-btn:hover {
                opacity: 1;
                color: #4dabf7;
            }
            /* EPG面板样式 */
            .epg-panel::-webkit-scrollbar {
                width: 6px;
            }
            .epg-panel::-webkit-scrollbar-track {
                background: rgba(255, 255, 255, 0.1);
                border-radius: 3px;
            }
            .epg-panel::-webkit-scrollbar-thumb {
                background: rgba(77, 171, 247, 0.5);
                border-radius: 3px;
            }
            .epg-panel::-webkit-scrollbar-thumb:hover {
                background: rgba(77, 171, 247, 0.8);
            }
            /* 播放列表EPG样式 */
            .playlist-item {
                padding: 10px 15px !important;
                line-height: 1.4 !important;
                position: relative;
            }
            .channel-name {
                font-weight: bold;
                margin-bottom: 3px;
            }
            .epg-now-playing {
                font-size: 11px;
                color: #4dabf7;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
                background: rgba(77, 171, 247, 0.1);
                padding: 2px 5px;
                border-radius: 3px;
                margin-top: 2px;
            }
            .playlist-item.active .epg-now-playing {
                color: white;
                background: rgba(255, 255, 255, 0.2);
            }
            /* 节目预告优化样式 */
            .programme-preview {
                position: fixed;
                background: rgba(0, 0, 0, 0.95);
                color: white;
                padding: 15px;
                border-radius: 8px;
                z-index: 2000;
                width: 350px;
                max-height: 300px;
                overflow-y: auto;
                box-shadow: 0 5px 20px rgba(0, 0, 0, 0.7);
                backdrop-filter: blur(10px);
                border: 1px solid rgba(255, 255, 255, 0.1);
                animation: fadeIn 0.15s ease;
            }
            @keyframes fadeIn {
                from { opacity: 0; transform: translateY(-5px); }
                to { opacity: 1; transform: translateY(0); }
            }
            .programme-preview::-webkit-scrollbar {
                width: 6px;
            }
            .programme-preview::-webkit-scrollbar-track {
                background: rgba(255, 255, 255, 0.1);
                border-radius: 3px;
            }
            .programme-preview::-webkit-scrollbar-thumb {
                background: rgba(77, 171, 247, 0.5);
                border-radius: 3px;
            }
            .programme-preview::-webkit-scrollbar-thumb:hover {
                background: rgba(77, 171, 247, 0.8);
            }
            /* 播放列表项优化 */
            .playlist-item:hover {
                background: linear-gradient(135deg, rgba(77, 171, 247, 0.2), rgba(77, 171, 247, 0.1)) !important;
            }
            /* EPG状态提示 */
            .epg-status-warning {
                color: #ffa94d !important;
                font-weight: bold;
            }
            .epg-status-error {
                color: #ff6b6b !important;
                font-weight: bold;
            }
            .epg-status-success {
                color: #51cf66 !important;
            }
        `;
        document.head.appendChild(style);
    }
    function createDynamicUI() {
        UI.infoBtn = document.createElement("button");
        UI.infoBtn.className = "info-btn";
        UI.infoBtn.innerHTML = "ⓘ";
        UI.infoBtn.title = "播放信息(ｉ)";
        UI.infoBtn.style.cssText = "background:none; border:none; color:white; cursor:pointer; margin-left:10px;";
        UI.volumeContainer.insertAdjacentElement("afterend", UI.infoBtn);
        setupButtonHoverEffects(UI.infoBtn);
        // 创建EPG按钮
        const epgBtn = document.createElement("button");
        epgBtn.className = "epg-btn";
        epgBtn.innerHTML = "⏱";
        epgBtn.title = "节目指南(e)";
        epgBtn.style.cssText = "background:none; border:none; color:white; cursor:pointer; margin-left:10px; font-size:16px;";
        UI.infoBtn.insertAdjacentElement("beforebegin", epgBtn);
        setupButtonHoverEffects(epgBtn);
        epgBtn.onclick = (e) => {
            e.stopPropagation();
            if (CONFIG.SHOW_EPG) {
				toggleEpgPanel();
			} else {
                showNotification("⚠ EPG未启用", 1500);
            } 
        };
        UI.infoPanel = document.createElement("div");
        UI.infoPanel.className = "info-panel";
        UI.infoPanel.style.cssText = "display:none; position:absolute; bottom:60px; right:10px; background:rgba(0,0,0,0.8); padding:10px; border-radius:4px; font-size:12px; z-index: 20;";
        UI.videoContainer.appendChild(UI.infoPanel);
        UI.switchSourceBtn = document.createElement("button");
        UI.switchSourceBtn.className = "switch-source-btn";
        UI.switchSourceBtn.innerHTML = "⥮";
        UI.switchSourceBtn.title = "手动换源(ｓ)";
        UI.switchSourceBtn.style.cssText = "background:none; border:none; color:white; cursor:pointer; margin-left:10px; font-size:16px;";
        UI.infoBtn.insertAdjacentElement("afterend", UI.switchSourceBtn);
        setupButtonHoverEffects(UI.switchSourceBtn);
        // 添加快捷键提示
        const shortcutHint = document.createElement('div');
        shortcutHint.className = 'shortcut-hint';
        shortcutHint.innerHTML = '快捷键说明';
        shortcutHint.style.cssText = 'position:absolute; top:5px; right:10px; background:rgba(0,0,0,0.7); color:#aaa; padding:6px 12px; border-radius:6px; font-size:11px; z-index:10; cursor:help;';
        UI.videoContainer.appendChild(shortcutHint);
        shortcutHint.addEventListener('mouseenter', () => {
            shortcutHint.innerHTML = `
                <div style="font-weight:bold; margin-bottom:5px; border-bottom:1px solid #444; padding-bottom:3px;">快捷键列表</div>
                <table style="font-size:10px; line-height:1.6;">
                    <tr><td><b>/</b></td><td>搜索播放列表</td></tr>
                    <tr><td><b>↑↓</b></td><td>在播放列表中导航</td></tr>                    
					<tr><td><b>Enter</b></td><td>播放选中频道</td></tr>
                    <tr><td><b>空格</b></td><td>播放/暂停</td></tr>
                    <tr><td><b>↑↓</b></td><td>播放列表关闭时音量调节</td></tr>
                    <tr><td><b>←→</b></td><td>快退/快进5秒</td></tr>
                    <tr><td><b>F</b></td><td>全屏切换</td></tr>
                    <tr><td><b>M</b></td><td>静音切换</td></tr>
                    <tr><td><b>P</b></td><td>播放列表</td></tr>
                    <tr><td><b>ESC</b></td><td>关闭列表</td></tr>
                    <tr><td><b>[ ]</b></td><td>上/下一个频道</td></tr>
                    <tr><td><b>S</b></td><td>手动换源</td></tr>
                    <tr><td><b>I</b></td><td>信息面板</td></tr>
                    <tr><td><b>E</b></td><td>节目指南</td></tr>
                </table>
                <div style="margin-top:5px; font-size:9px; color:#aaa;">
                    提示：播放列表打开时，上下箭头用于导航
                </div>
            `;
            shortcutHint.style.width = '180px';
            shortcutHint.style.fontSize = '10px';
            shortcutHint.style.padding = '10px';
        });
        shortcutHint.addEventListener('mouseleave', () => {
            shortcutHint.innerHTML = '快捷键说明';
            shortcutHint.style.width = 'auto';
            shortcutHint.style.fontSize = '11px';
            shortcutHint.style.padding = '6px 12px';
        });
        UI.playlistSearchInput.classList.add('playlist-search');
        UI.playlistItems.addEventListener('DOMNodeInserted', function() {
            const items = UI.playlistItems.querySelectorAll('.playlist-item');
            items.forEach((item, index) => {
                item.setAttribute('tabindex', '-1');
            });
        });
    }
    // ==================== 修复的 togglePlaylistUI 函数 ====================
    function togglePlaylistUI(show) {
        const shouldShow = show !== undefined ? show : !UI.playlistContainer.classList.contains("hidden") === false;
        const currentlyVisible = !UI.playlistContainer.classList.contains("hidden");
        if (shouldShow === currentlyVisible) return;
        // 切换时隐藏所有节目预览
        hideChannelProgrammePreview();
        UI.playlistContainer.classList.toggle("hidden", !shouldShow);
        if (shouldShow) {
            UI.playlistContainer.setAttribute('tabindex', '-1');
            UI.playlistContainer.classList.add('has-focus');
            setTimeout(() => {
                const selectedItem = UI.playlistItems.querySelector('.selected');
                if (selectedItem) {
                    selectedItem.focus();
                }
            }, 50);
        } else {
            UI.playlistSearchInput.blur();
            UI.playlistSearchInput.style.border = "";
            UI.playlistSearchInput.style.boxShadow = "";
            const selectedItem = UI.playlistItems.querySelector('.selected');
            if (selectedItem) {
                selectedItem.classList.remove('selected');
            }
        }
    }
    function loadVolumeSettings() {
        chrome.storage.local.get(["volume"], function(result) {
            if (result.volume !== undefined) {
                UI.videoPlayer.volume = result.volume;
                UI.volumeProgress.style.width = result.volume * 100 + "%";
                updateVolumeIcon();
            }
        });
    }
    // ==================== 新增：从 storage 加载用户设置（包含EPG配置） ====================
    function loadSettings() {
        chrome.storage.local.get([
            'loadTimeout',
            'stallTimeout',
            'maxRetryRounds',
            'searchDebounce',
            'playlistRefreshInterval',
            'autoRefreshEnabled',
            'showEPG',
            'epgUpdateInterval',
            'epgUrls',           // EPG URL数组
            'activeEpgUrl'       // 当前活动的EPG URL
        ], function(result) {
            // 更新 CONFIG（将用户友好的单位转换为毫秒）
            if (result.loadTimeout !== undefined) {
                CONFIG.LOAD_TIMEOUT_MS = result.loadTimeout;
            }
            if (result.stallTimeout !== undefined) {
                CONFIG.STALL_TIMEOUT_MS = result.stallTimeout;
            }
            if (result.maxRetryRounds !== undefined) {
                CONFIG.MAX_RETRY_ROUNDS = result.maxRetryRounds;
            }
            if (result.searchDebounce !== undefined) {
                CONFIG.SEARCH_DEBOUNCE_MS = result.searchDebounce;
            }
            if (result.playlistRefreshInterval !== undefined) {
                CONFIG.PLAYLIST_REFRESH_INTERVAL = result.playlistRefreshInterval;
            }
            if (result.autoRefreshEnabled !== undefined) {
                CONFIG.AUTO_REFRESH_ENABLED = result.autoRefreshEnabled;
            }
            if (result.showEPG !== undefined) {
                CONFIG.SHOW_EPG = result.showEPG;
                console.log('[设置] EPG显示:', CONFIG.SHOW_EPG ? '启用' : '禁用');
            }
            if (result.epgUpdateInterval !== undefined) {
                CONFIG.EPG_UPDATE_INTERVAL = result.epgUpdateInterval;
                console.log('[设置] EPG更新间隔:', CONFIG.EPG_UPDATE_INTERVAL, 'ms');
            }
            // 加载EPG URL配置
            if (result.activeEpgUrl) {
                state.currentEpgUrl = result.activeEpgUrl;
                console.log('[设置] 加载EPG URL:', state.currentEpgUrl);
            }
            console.log('[设置] 配置已从 storage 加载');
        });
    }
    // ==================== 修改的设置更新监听 ====================
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        if (message.action === 'settingsUpdated') {
            console.log('[设置] 收到设置更新通知');
            // 更新 CONFIG
            if (message.config.loadTimeout) {
                CONFIG.LOAD_TIMEOUT_MS = message.config.loadTimeout;
                console.log('[设置] 更新加载超时:', CONFIG.LOAD_TIMEOUT_MS, 'ms');
            }
            if (message.config.stallTimeout) {
                CONFIG.STALL_TIMEOUT_MS = message.config.stallTimeout;
                console.log('[设置] 更新卡顿超时:', CONFIG.STALL_TIMEOUT_MS, 'ms');
            }
            if (message.config.maxRetryRounds) {
                CONFIG.MAX_RETRY_ROUNDS = message.config.maxRetryRounds;
                console.log('[设置] 更新最大重试轮次:', CONFIG.MAX_RETRY_ROUNDS);
            }
            if (message.config.searchDebounce) {
                CONFIG.SEARCH_DEBOUNCE_MS = message.config.searchDebounce;
                console.log('[设置] 更新搜索防抖:', CONFIG.SEARCH_DEBOUNCE_MS, 'ms');
            }
            if (message.config.playlistRefreshInterval) {
                CONFIG.PLAYLIST_REFRESH_INTERVAL = message.config.playlistRefreshInterval;
                console.log('[设置] 更新列表刷新间隔:', CONFIG.PLAYLIST_REFRESH_INTERVAL, 'ms');
                if (state.isM3UPlaylist && CONFIG.AUTO_REFRESH_ENABLED) {
                    if (state.timers.refreshPlaylist) {
                        clearTimeout(state.timers.refreshPlaylist);
                    }
                    startPlaylistRefreshTimer();
                }
            }
            if (message.config.autoRefreshEnabled !== undefined) {
                CONFIG.AUTO_REFRESH_ENABLED = message.config.autoRefreshEnabled;
                console.log('[设置] 更新自动刷新:', CONFIG.AUTO_REFRESH_ENABLED);
                if (!CONFIG.AUTO_REFRESH_ENABLED && state.timers.refreshPlaylist) {
                    clearTimeout(state.timers.refreshPlaylist);
                    state.timers.refreshPlaylist = null;
                } else if (CONFIG.AUTO_REFRESH_ENABLED && state.isM3UPlaylist) {
                    startPlaylistRefreshTimer();
                }
            }
            if (message.config.showEPG !== undefined) {
                CONFIG.SHOW_EPG = message.config.showEPG;
                console.log('[设置] 更新EPG显示:', CONFIG.SHOW_EPG ? '启用' : '禁用');
                updateVideoInfoWithEPG();
                // 如果EPG功能被启用且有EPG URL，加载EPG数据
                if (CONFIG.SHOW_EPG && state.currentEpgUrl && state.epgManager) {
                    loadEPG(state.currentEpgUrl);
                }
                // 启动或停止EPG状态检查
                if (CONFIG.SHOW_EPG && !state.timers.epgCheck) {
                    state.timers.epgCheck = setInterval(() => {
                        checkAndFixEPGState();
                    }, 60000);
                } else if (!CONFIG.SHOW_EPG && state.timers.epgCheck) {
                    clearInterval(state.timers.epgCheck);
                    state.timers.epgCheck = null;
                }
            }
            if (message.config.epgUpdateInterval !== undefined) {
                CONFIG.EPG_UPDATE_INTERVAL = message.config.epgUpdateInterval;
                console.log('[设置] 更新EPG更新间隔:', CONFIG.EPG_UPDATE_INTERVAL, 'ms');
                if (state.epgManager && state.epgManager.isLoaded) {
                    startEPGUpdateTimer();
                }
            }
            // 新增：处理EPG URL更新
            if (message.config.activeEpgUrl !== undefined) {
                const newEpgUrl = message.config.activeEpgUrl;
                if (newEpgUrl !== state.currentEpgUrl) {
                    state.currentEpgUrl = newEpgUrl;
                    console.log('[设置] 更新EPG URL:', newEpgUrl);
                    // 如果EPG显示已启用且EPG管理器已初始化，重新加载EPG数据
                    if (state.epgManager && CONFIG.SHOW_EPG && newEpgUrl) {
                        setTimeout(() => {
                            loadEPG(newEpgUrl);
                        }, 500);
                    }
                }
            }
            if (message.config.blacklist) {
                state.blacklist = message.config.blacklist;
                state.isBlacklistLoaded = true;
                console.log(`[设置] 黑名单已更新，${state.blacklist.length} 个关键词`);
            }
            updateInfoPanel();
            showNotification('设置已更新', 2000);
        }
    });
    function switchToPrevChannel() {
        if (!state.isM3UPlaylist || state.currentPlaylist.length === 0) {
            showNotification("当前不是播放列表模式或列表为空", 1500);
            return;
        }
        if (state.currentPlaylistIndex === -1) {
            state.currentPlaylistIndex = 0;
        }
        let prevIndex = state.currentPlaylistIndex - 1;
        if (prevIndex < 0) {
            prevIndex = state.currentPlaylist.length - 1;
        }
        console.log(`[频道切换] 切换到上一个频道: ${state.currentPlaylistIndex} → ${prevIndex}`);
        const item = state.currentPlaylist[prevIndex];
        if (item) {
            showNotification(`切换到上一个频道: ${item.title || `频道 ${prevIndex + 1}`}`, 1500);
        }
        playPlaylistItem(prevIndex);
    }
    function switchToNextChannel() {
        if (!state.isM3UPlaylist || state.currentPlaylist.length === 0) {
            showNotification("当前不是播放列表模式或列表为空", 1500);
            return;
        }
        if (state.currentPlaylistIndex === -1) {
            state.currentPlaylistIndex = 0;
        }
        let nextIndex = state.currentPlaylistIndex + 1;
        if (nextIndex >= state.currentPlaylist.length) {
            nextIndex = 0;
        }
        console.log(`[频道切换] 切换到下一个频道: ${state.currentPlaylistIndex} → ${nextIndex}`);
        const item = state.currentPlaylist[nextIndex];
        if (item) {
            showNotification(`切换到下一个频道: ${item.title || `频道 ${nextIndex + 1}`}`, 1500);
        }
        playPlaylistItem(nextIndex);
    }
    function parseInitialUrl() {
        const urlParams = new URLSearchParams(window.location.search);
        const queryUrl = urlParams.get("url");
        const hashUrl = window.location.hash.substring(1);
        state.videoUrl = queryUrl || hashUrl;
        if (state.videoUrl) {
            UI.videoInfo.textContent = decodeURIComponent(state.videoUrl);
            try {
                const urlObj = new URL(state.videoUrl);
                state.baseUrl = urlObj.href.substring(0, urlObj.href.lastIndexOf("/") + 1);
                state.originalPlaylistUrl = state.videoUrl;
            } catch (e) {
                console.warn("基础URL解析失败:", e);
                state.baseUrl = "";
                state.originalPlaylistUrl = state.videoUrl;
            }
        }
    }
    function clearTimers(keys = []) {
        const targets = keys.length > 0 ? keys : ["load", "stall"];
        targets.forEach(key => {
            if (state.timers[key]) {
                clearTimeout(state.timers[key]);
                state.timers[key] = null;
            }
        });
    }
    function showLoading(show) {
        UI.loading.style.display = show ? "block" : "none";
    }
    function showError(message) {
        showLoading(false);
        UI.errorMessage.textContent = message;
        UI.errorMessage.style.display = "block";
        if (message.includes("黑名单") || message.includes("拦截") || message.includes("禁止")) {
            UI.errorMessage.classList.add("blacklist-error");
        } else {
            UI.errorMessage.classList.remove("blacklist-error");
        }
    }
    function formatTime(seconds) {
        if (seconds === Infinity || isNaN(seconds)) return "Live";
        const m = Math.floor(seconds / 60);
        const s = Math.floor(seconds % 60);
        return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
    }
    function startVideoLoadProcess() {
        showLoading(true);
        UI.errorMessage.style.display = "none";
        UI.errorMessage.classList.remove("blacklist-error");
        checkAndInitPlayer(state.videoUrl);
    }
    // 修改后的 loadBlacklist 函数：优先从 storage，没有则从文件
    function loadBlacklist() {
        state.blacklist = [];
        state.isBlacklistLoaded = false;
        console.log('[黑名单] 开始加载黑名单...');
        chrome.storage.local.get(['blacklist', 'blacklistContent'], function(result) {
            if (result.blacklist && Array.isArray(result.blacklist) && result.blacklist.length > 0) {
                state.blacklist = result.blacklist;
                console.log(`[黑名单] 从 storage 加载 ${state.blacklist.length} 个关键词`);
                state.isBlacklistLoaded = true;
                if (state.videoUrl) startVideoLoadProcess();
            } else if (result.blacklistContent) {
                state.blacklist = result.blacklistContent.split('\n')
                    .map(line => line.trim())
                    .filter(line => line && !line.startsWith('#') && !line.startsWith('//'))
                    .filter(keyword => keyword.length > 0);
                console.log(`[黑名单] 从 storage 内容加载 ${state.blacklist.length} 个关键词`);
                state.isBlacklistLoaded = true;
                if (state.videoUrl) startVideoLoadProcess();
            } else {
                console.log('[黑名单] storage 中无黑名单，尝试从文件加载');
                fetch(CONFIG.BLACKLIST_URL)
                    .then(response => {
                        if (!response.ok) {
                            throw new Error(`HTTP ${response.status}`);
                        }
                        return response.text();
                    })
                    .then(text => {
                        state.blacklist = text.split('\n')
                            .map(line => line.trim())
                            .filter(line => line && !line.startsWith('#') && !line.startsWith('//'))
                            .filter(keyword => keyword.length > 0);
                        console.log(`[黑名单] 从文件加载 ${state.blacklist.length} 个关键词`);
                        state.isBlacklistLoaded = true;
                        if (state.videoUrl) startVideoLoadProcess();
                    })
                    .catch(error => {
                        console.warn('[黑名单] 文件加载失败，使用空黑名单:', error);
                        state.blacklist = [];
                        state.isBlacklistLoaded = true;
                        if (state.videoUrl) startVideoLoadProcess();
                    });
            }
        });
    }
    // 新增：为所有控制按钮添加统一的鼠标效果
    function addButtonHoverEffects() {
        const staticButtons = [
            UI.backBtn,
            UI.playPauseBtn,
            UI.prevChannelBtn,
            UI.nextChannelBtn,
            UI.volumeBtn,
            UI.fullscreenBtn,
            UI.playlistBtn,
            UI.closePlaylistBtn,
            UI.clearSearchBtn
        ];
        staticButtons.forEach(button => {
            if (!button) return;
            setupButtonHoverEffects(button);
        });
    }
    function setupButtonHoverEffects(button) {
        if (!button) return;
        button.style.opacity = '1';
        button.style.transition = 'opacity 0.2s ease';
        button.addEventListener('mouseenter', () => {
            button.style.opacity = '0.8';
        });
        button.addEventListener('mouseleave', () => {
            button.style.opacity = '1';
        });
        button.addEventListener('mousedown', () => {
            button.style.opacity = '0.6';
        });
        button.addEventListener('mouseup', () => {
            button.style.opacity = '0.8';
        });
    }
    function checkUrlInBlacklist(url, urlType = "URL") {
        if (!url || typeof url !== 'string') {
            return false;
        }
        if (!state.isBlacklistLoaded) {
            console.log(`[黑名单] 等待黑名单加载完成...`);
            setTimeout(() => {
                checkUrlInBlacklist(url, urlType);
            }, 100);
            return false;
        }
        const lowerUrl = url.toLowerCase();
        for (const keyword of state.blacklist) {
            if (!keyword) continue;
            const lowerKeyword = keyword.toLowerCase();
            if (lowerKeyword.includes('*')) {
                const pattern = lowerKeyword
                    .replace(/\./g, '\\.')
                    .replace(/\*/g, '.*');
                const regex = new RegExp(`^${pattern}$`);
                if (regex.test(lowerUrl)) {
                    console.warn(`[黑名单拦截] ${urlType} 匹配通配符模式: "${keyword}"`);
                    console.warn(`[黑名单拦截] 被拦截的URL: ${url}`);
                    showError(
                        `播放被拦截：链接匹配黑名单规则\n\n` +
                        `规则: ${keyword}\n` +
                        `URL: ${url.substring(0, 80)}${url.length > 80 ? '...' : ''}`
                    );
                    handleBlacklistedInPlaylist(url, keyword);
                    return true;
                }
            } else if (lowerUrl.includes(lowerKeyword)) {
                console.warn(`[黑名单拦截] ${urlType} 包含黑名单关键词: "${keyword}"`);
                console.warn(`[黑名单拦截] 被拦截的URL: ${url}`);
                showError(
                    `播放被拦截：链接包含黑名单关键词\n\n` +
                    `关键词: ${keyword}\n` +
                    `URL: ${url.substring(0, 80)}${url.length > 80 ? '...' : ''}`
                );
                handleBlacklistedInPlaylist(url, keyword);
                return true;
            }
        }
        return false;
    }
    // 新增：处理播放列表中被黑名单拦截的项目
    function handleBlacklistedInPlaylist(blockedUrl, keyword) {
        if (!state.isM3UPlaylist || state.currentPlaylistIndex === -1) {
            return;
        }
        const item = state.currentPlaylist[state.currentPlaylistIndex];
        if (!item) return;
        if (item.urls && item.urls.length > 0) {
            const originalLength = item.urls.length;
            item.urls = item.urls.filter(url => url !== blockedUrl);
            if (item.urls.length < originalLength) {
                console.warn(`[黑名单] 从频道 "${item.title}" 中移除 ${originalLength - item.urls.length} 个被拦截的源`);
                if (state.currentChannelInfo.urls) {
                    state.currentChannelInfo.urls = state.currentChannelInfo.urls.filter(url => url !== blockedUrl);
                }
                if (item.currentUrlIndex !== undefined && 
                    item.urls.length > 0 && 
                    item.currentUrlIndex >= item.urls.length) {
                    item.currentUrlIndex = 0;
                    showNotification(`源被黑名单拦截，自动切换`, 2000);
                    const nextUrl = item.urls[0];
                    setTimeout(() => {
                        if (checkUrlInBlacklist(nextUrl, "下一个源")) {
                            return;
                        }
                        destroyPlayer();
                        showLoading(true);
                        UI.errorMessage.style.display = "none";
                        UI.videoInfo.textContent = item.title || decodeURIComponent(nextUrl);
                        checkAndInitPlayer(nextUrl);
                    }, 1500);
                }
            }
            if (item.urls.length === 0) {
                console.warn(`[黑名单] 频道 "${item.title}" 所有源均被拦截，将跳过`);
                showNotification(`频道 "${item.title}" 已被屏蔽`, 3000);
                setTimeout(() => {
                    let nextIndex = state.currentPlaylistIndex + 1;
                    while (nextIndex < state.currentPlaylist.length) {
                        const nextItem = state.currentPlaylist[nextIndex];
                        if (nextItem && nextItem.urls && nextItem.urls.length > 0) {
                            const firstUrl = nextItem.urls[0];
                            if (!checkUrlInBlacklist(firstUrl, "下一个频道URL")) {
                                playPlaylistItem(nextIndex);
                                return;
                            }
                        }
                        nextIndex++;
                    }
                    showError("所有频道均被黑名单拦截，无法播放");
                }, 1500);
            }
        }
    }
    function checkAndInitPlayer(url) {
        const thisRequestId = ++state.loadRequestId;
        if (!state.isBlacklistLoaded) {
            console.log(`[Req #${thisRequestId}] 等待黑名单加载...`);
            setTimeout(() => {
                if (thisRequestId === state.loadRequestId) {
                    checkAndInitPlayer(url);
                }
            }, 100);
            return;
        }
        if (checkUrlInBlacklist(url, "原始URL")) {
            return;
        }
        const lowerUrl = url.toLowerCase();
        if (/(?:#m3u8|#m3u)([?#].*)?$/.test(lowerUrl)) {   
            if (thisRequestId === state.loadRequestId) {
                initPlayerWithUrl(url);
            }
        } else {
            console.log(`[Req #${thisRequestId}] 检测重定向及 Content-Type:`, url);
            new Promise(resolve => {
                chrome.runtime.sendMessage({
                    action: "checkRedirect",
                    url: url
                }, response => resolve(response));
            }).then(response => {
                if (thisRequestId !== state.loadRequestId) {
                    console.warn(`[Req #${thisRequestId}] 请求已过期 (当前ID: ${state.loadRequestId})，丢弃结果。`);
                    return;
                }
                if (response && response.success) {
                    console.log(`[Req #${thisRequestId}] 重定向成功: ${response.finalUrl}`);
                    if (checkUrlInBlacklist(response.finalUrl, "重定向URL")) {
                        return;
                    }
                    initPlayerWithUrl(response.finalUrl, response.contentType || "");
                } else {
                    console.warn(`[Req #${thisRequestId}] 重定向检测无响应或失败，尝试直连`);
                    initPlayerWithUrl(url);
                }
            });
        }
    }
    function destroyPlayer() {
        if (state.player) {
            if (typeof state.player.destroy === "function") {
                state.player.destroy();
            } else if (state.player instanceof Hls) {
                state.player.destroy();
            }
            state.player = null;
        }
        UI.videoPlayer.removeAttribute("src");
        UI.videoPlayer.load();
        state.isPlaying = false;
        clearTimers();
        state.streamInfo = {
            resolution: "未知",
            type: "未知"
        };
    }
    function initPlayerWithUrl(url, contentType = "") {
        if (checkUrlInBlacklist(url, "播放URL")) {
            return;
        }
        const lowerUrl = url.toLowerCase();
        const ct = contentType.toLowerCase();
        const isHlsContent = ct.includes("mpegurl") || ct.includes("hls") || ct.includes("text/html") || ct.includes("text/plain") || ct.includes("application/octet-stream");
        if (/(?:[.]m3u|#m3u)([?#].*)?$/.test(lowerUrl)) {
            initM3UPlaylist(url);
        } else if (isHlsContent || /(?:[.]m3u8|#m3u8)([?#].*)?$/.test(lowerUrl)) {
            initHlsPlayer(url);
        } else if (/\.flv([?#].*)?$/.test(lowerUrl)) {
            initFlvPlayer(url);
        } else {
            initNativePlayer(url);
        }
    }
    function initFlvPlayer(url) {
        if (!flvjs.isSupported()) {
            return handleError("您的浏览器不支持FLV播放");
        }
        destroyPlayer();
        state.streamInfo.type = "FLV";
        const player = flvjs.createPlayer({
            type: "flv",
            url: url
        });
        player.attachMediaElement(UI.videoPlayer);
        player.load();
        player.on(flvjs.Events.METADATA_ARRIVED, metadata => {
            clearTimers(["load"]);
            if (metadata?.onMetaData) {
                const { width, height } = metadata.onMetaData;
                if (width && height) state.streamInfo.resolution = `${width}x${height}`;
                updateInfoPanel();
            }
        });
        player.on(flvjs.Events.ERROR, (type, detail) => {
            console.error("FLV Error:", type, detail);
            handleError(`FLV播放错误: ${type}`);
        });
        state.player = player;
        attachCommonVideoEvents();
    }
    function initHlsPlayer(url) {
        if (Hls.isSupported()) {
            destroyPlayer();
            state.streamInfo.type = "HLS";
            const player = new Hls({
                debug: false,
                capLevelToPlayerSize: true,
                autoLevelEnabled: true,
                fragLoadingMaxRetry: 1,
                fragLoadingRetryDelay: 500
            });
            player.loadSource(url);
            player.attachMedia(UI.videoPlayer);
            player.on(Hls.Events.MANIFEST_PARSED, (event, data) => {
                clearTimers(["load"]);
                console.log("HLS Manifest Parsed");
                showLoading(false);
                updateResolutionFromHls(player, data);
                attemptPlay();
            });
            player.on(Hls.Events.ERROR, (event, data) => {
                if (data.fatal) {
                    console.error("HLS Fatal Error:", data.type, data.details);
                    handleError(`HLS播放错误: ${data.details}`);
                }
            });
            state.player = player;
            attachCommonVideoEvents();
        } else if (UI.videoPlayer.canPlayType("application/vnd.apple.mpegurl")) {
            destroyPlayer();
            UI.videoPlayer.src = url;
            attachCommonVideoEvents();
        } else {
            handleError("您的浏览器不支持HLS播放");
        }
    }
    function initNativePlayer(url) {
        destroyPlayer();
        state.streamInfo.type = "原生";
        const lower = url.toLowerCase();
        if (lower.includes(".mp4")) state.streamInfo.type = "MP4";
        else if (lower.includes(".webm")) state.streamInfo.type = "WebM";
        else if (lower.includes(".ogg") || lower.includes(".ogv")) state.streamInfo.type = "OGG";
        UI.videoPlayer.src = url;
        attachCommonVideoEvents();
    }
    function attachCommonVideoEvents() {
        UI.videoPlayer.onloadedmetadata = function() {
            clearTimers(["load"]);
            showLoading(false);
            updateVideoInfoFromElement();
            attemptPlay();
        };
        UI.videoPlayer.onloadeddata = function() {
            updateVideoInfoFromElement();
        };
        UI.videoPlayer.onerror = function() {
            if (!UI.videoPlayer.getAttribute("src") && !UI.videoPlayer.currentSrc) return;
            handleError("视频加载失败或格式不支持");
        };
        UI.videoPlayer.onplay = () => {
            state.isPlaying = true;
            UI.playPauseBtn.textContent = "❚❚";
            UI.playPauseBtn.title = "暂停(空格键)";
        };
        UI.videoPlayer.onpause = () => {
            state.isPlaying = false;
            UI.playPauseBtn.textContent = "▶";
            UI.playPauseBtn.title = "播放(空格键)";
        };
        UI.videoPlayer.ontimeupdate = updateProgress;
        UI.videoPlayer.onvolumechange = updateVolumeIcon;
        UI.videoPlayer.onended = () => {
            if (state.isM3UPlaylist) {
                const item = state.currentPlaylist[state.currentPlaylistIndex];
                if (item && item.urls && item.currentUrlIndex < item.urls.length - 1) {
                    item.currentUrlIndex++;
                    console.log(`当前源播放结束，切换至本频道下一个源: ${item.currentUrlIndex + 1}/${item.urls.length}`);
                    showNotification(`播放结束，切换到源 ${item.currentUrlIndex + 1}/${item.urls.length}`, 1500);
                    const nextUrl = item.urls[item.currentUrlIndex];
                    destroyPlayer();
                    showLoading(true);
                    UI.errorMessage.style.display = "none";
                    UI.videoInfo.textContent = item.title || decodeURIComponent(nextUrl);
                    checkAndInitPlayer(nextUrl);
                    if (state.timers.load) clearTimeout(state.timers.load);
                    state.timers.load = setTimeout(() => {
                        console.error(`加载超时 (${CONFIG.LOAD_TIMEOUT_MS}ms)，切换线路。`);
                        tryNextRedundantUrl();
                    }, CONFIG.LOAD_TIMEOUT_MS);
                    return;
                }
                if (state.currentPlaylistIndex < state.currentPlaylist.length - 1) {
                    playPlaylistItem(state.currentPlaylistIndex + 1);
                }
            }
        };
        UI.videoPlayer.onwaiting = () => {
            if (state.isM3UPlaylist && state.isPlaying) {
                console.warn(`卡顿检测: 启动超时计时器 (${CONFIG.STALL_TIMEOUT_MS}ms)`);
                if (state.timers.stall) clearTimeout(state.timers.stall);
                state.timers.stall = setTimeout(() => {
                    console.error("播放停滞超时，尝试切换线路。");
                    showNotification("卡顿超时，自动换源", 1500);
                    tryNextRedundantUrl();
                }, CONFIG.STALL_TIMEOUT_MS);
            }
        };
        UI.videoPlayer.onplaying = () => {
            if (state.timers.stall) {
                clearTimeout(state.timers.stall);
                state.timers.stall = null;
            }
        };
    }
    function handleError(msg) {
        if (state.isM3UPlaylist) {
            console.warn(`捕获错误: ${msg} -> 尝试下一个源`);
            tryNextRedundantUrl();
        } else {
            showError(msg);
        }
    }
    let isFirstPlay = true;
    function attemptPlay() {
        const promise = UI.videoPlayer.play();
        if (promise !== undefined) {
            promise.then(() => {
                state.isPlaying = true;
                UI.playPauseBtn.textContent = "❚❚";
                UI.playPauseBtn.title = "暂停(空格键)";
                if (isFirstPlay && !document.fullscreenElement) {
                    isFirstPlay = false;
                }
                // 播放成功时更新EPG信息
                if (state.isM3UPlaylist) {
                    updateCurrentProgrammeInfo();
                }
            }).catch(error => {
                console.error("自动播放被阻止或失败:", error);
                state.isPlaying = false;
                UI.playPauseBtn.textContent = "▶";
                UI.playPauseBtn.title = "播放(空格键)";
            });
        }
    }
    // ==================== 修改的渲染播放列表函数 ====================
    function renderPlaylist(searchTerm = "") {
        UI.playlistItems.innerHTML = "";
        const lowerTerm = searchTerm.toLowerCase();
        const fragment = document.createDocumentFragment();
        state.currentPlaylist.forEach((item, index) => {
            const channelName = item.title || `项目 ${index + 1}`;
            const tvgName = item.tvgName || channelName;
            if (searchTerm && !channelName.toLowerCase().includes(lowerTerm)) {
                return;
            }
            const el = document.createElement("div");
            el.className = "playlist-item";
            if (index === state.currentPlaylistIndex) el.classList.add("active");
            el.dataset.index = index;
            el.dataset.channelName = tvgName; // 添加频道名称到dataset
            // 获取当前节目的EPG信息
            let epgInfo = "";
            if (state.channelProgrammes[tvgName]) {
                const programmes = state.channelProgrammes[tvgName];
                const now = new Date();
                const currentProgramme = programmes.find(p => p.start <= now && p.stop > now);
                if (currentProgramme) {
                    const remainingMinutes = Math.floor((currentProgramme.stop - now) / 60000);
                    epgInfo = `<div class="epg-now-playing">${currentProgramme.title} (${remainingMinutes}分钟)</div>`;
                }
            }
            el.innerHTML = `
                <div class="channel-name">${channelName}</div>
                ${epgInfo}
            `;
            el.onclick = () => {
                playPlaylistItem(index);
                maintainPlaylistFocus();
            };
            // 添加鼠标悬停事件 - 显示节目预告
            let hoverTimer = null;
            let isPreviewVisible = false;
            el.addEventListener('mouseenter', (e) => {
				if (CONFIG.SHOW_EPG) {
                    // 延迟200ms显示，避免快速移动时频繁显示
                    hoverTimer = setTimeout(() => {
                        showChannelProgrammePreview(tvgName, el);
                        isPreviewVisible = true;
                    }, 200);
				}
            });
            el.addEventListener('mouseleave', (e) => {
                // 清除延迟定时器
                if (hoverTimer) {
                    clearTimeout(hoverTimer);
                    hoverTimer = null;
                }
                // 如果预览已显示，延迟100ms关闭（避免快速切换时的闪烁）
                if (isPreviewVisible) {
                    setTimeout(() => {
                        hideChannelProgrammePreview();
                    }, 100);
                }
                isPreviewVisible = false;
            });
            setupButtonHoverEffects(el);
            fragment.appendChild(el);
        });
        UI.playlistItems.appendChild(fragment);
    }
    /**
     * 播放播放列表项目（修复EPG显示问题）
     */
    function playPlaylistItem(index) {
        if (index < 0 || index >= state.currentPlaylist.length) return;
        const item = state.currentPlaylist[index];
        const itemUrl = item.urls[0];
        if (checkUrlInBlacklist(itemUrl, "播放列表URL")) {
            return;
        }
        state.currentPlaylistIndex = index;
        item.currentUrlIndex = 0;
        item.currentRound = 1;
        state.currentChannelInfo = {
            title: item.title || "",
            originalIndex: index,
            urls: [...item.urls]
        };
        updatePlaylistHighlight();
        // 确保EPG信息在切换频道前更新
        if (state.epgManager && state.epgManager.isLoaded) {
            const channelName = item.tvgName || item.title;
            console.log(`[EPG预热] 频道: ${channelName}`);
            // 预热：先调用getProgrammes获取节目列表
            setTimeout(() => {
                const programmes = state.epgManager.getProgrammes(channelName, {
                    maxResults: 5,
                    includeCurrent: true,
                    includePast: false,
                    includeFuture: true
                });
                console.log(`[EPG预热] 获取到 ${programmes.length} 个节目`);
                // 然后更新当前节目信息
                updateCurrentProgrammeInfo();
                updateVideoInfoWithEPG();
            }, 50);
        } else {
            updateCurrentProgrammeInfo();
            updateVideoInfoWithEPG();
        }
        if (CONFIG.SHOW_EPG) {
            checkAndFixEPGState();
        }
        updateCurrentProgrammeInfo();
        updateVideoInfoWithEPG();
        destroyPlayer();
        showLoading(true);
        UI.errorMessage.style.display = "none";
        // 延迟一点确保UI更新完成
        setTimeout(() => {
            checkAndInitPlayer(itemUrl);
        }, 100);
        // 重新启动EPG更新定时器，确保后续更新
        if (state.epgManager && state.epgManager.isLoaded) {
            startEPGUpdateTimer();
        }
        // 清除旧的加载定时器
        if (state.timers.load) clearTimeout(state.timers.load);
        state.timers.load = setTimeout(() => {
            console.error(`加载超时 (${CONFIG.LOAD_TIMEOUT_MS}ms)，切换线路。`);
            tryNextRedundantUrl();
        }, CONFIG.LOAD_TIMEOUT_MS);
    }
    function updatePlaylistHighlight() {
        const items = UI.playlistItems.children;
        for (let el of items) {
            if (parseInt(el.dataset.index) === state.currentPlaylistIndex) {
                el.classList.add("active");
                el.scrollIntoView({
                    behavior: "smooth",
                    block: "nearest"
                });
            } else {
                el.classList.remove("active");
            }
        }
    }
    function handlePlaylistSearch(e) {
        const term = e.target.value;
        if (term) UI.clearSearchBtn.classList.add("visible");
        else UI.clearSearchBtn.classList.remove("visible");
        if (state.timers.searchDebounce) clearTimeout(state.timers.searchDebounce);
        state.timers.searchDebounce = setTimeout(() => {
            renderPlaylist(term);
            const selectedItem = UI.playlistItems.querySelector('.selected');
            if (selectedItem) {
                selectedItem.classList.remove('selected');
            }
            // 搜索时隐藏节目预览
            hideChannelProgrammePreview();
        }, CONFIG.SEARCH_DEBOUNCE_MS);
    }
    function clearSearch() {
        UI.playlistSearchInput.value = "";
        UI.clearSearchBtn.classList.remove("visible");
        renderPlaylist("");
        const selectedItem = UI.playlistItems.querySelector('.selected');
        if (selectedItem) {
            selectedItem.classList.remove('selected');
        }
        // 清除搜索时隐藏节目预览
        hideChannelProgrammePreview();
    }
    function updateVideoInfoFromElement() {
        if (UI.videoPlayer.videoWidth && UI.videoPlayer.videoHeight) {
            state.streamInfo.resolution = `${UI.videoPlayer.videoWidth}x${UI.videoPlayer.videoHeight}`;
        }
        updateInfoPanel();
    }
    function updateResolutionFromHls(hlsPlayer, data) {
        if (data && data.levels && data.levels.length > 0) {
            const currentLevel = hlsPlayer.currentLevel >= 0 ? hlsPlayer.currentLevel : hlsPlayer.autoLevelEnabled ? hlsPlayer.autoLevelLast : 0;
            const levelData = data.levels[currentLevel];
            if (levelData && levelData.width) {
                state.streamInfo.resolution = `${levelData.width}x${levelData.height}`;
            }
        }
        updateInfoPanel();
    }
    /**
     * 更新信息面板（添加EPG信息）
     */
    function updateInfoPanel() {
        const lines = [
            `类型: ${state.streamInfo.type}`,
            `分辨率: ${state.streamInfo.resolution}`
        ];
        if (state.isM3UPlaylist && state.currentPlaylistIndex >= 0) {
            const item = state.currentPlaylist[state.currentPlaylistIndex];
            if (item) {
                const totalUrls = item.urls ? item.urls.length : 0;
                const currentIndex = (item.currentUrlIndex || 0) + 1;
                const round = item.currentRound || 1;
                lines.push(`频道列表: ${state.currentPlaylistIndex + 1}/${state.currentPlaylist.length}`);
                if (totalUrls > 1) {
                    lines.push(`源: ${currentIndex}/${totalUrls}`);
                    lines.push(`轮次: ${round}/${CONFIG.MAX_RETRY_ROUNDS}`);
                }
                if (CONFIG.AUTO_REFRESH_ENABLED && state.timers.refreshPlaylist) {
                    lines.push(`列表刷新: ${Math.round(CONFIG.PLAYLIST_REFRESH_INTERVAL/60000)}分钟`);
                }
                if (item.title && item.title.includes("(旧列表)")) {
                    lines.push(`状态: 来自旧列表`);
                }
                // 添加EPG信息
                if (state.currentProgramme) {
                    const programme = state.currentProgramme;
                    const now = new Date();
                    const remainingMinutes = Math.floor((programme.stop - now) / 60000);
                    lines.push(`当前节目: ${programme.title}`);
                    lines.push(`节目剩余: ${remainingMinutes}分钟`);
                }
                if (state.epgManager) {
                    const stats = state.epgManager.getStats();
                    if (stats.isLoaded) {
                        lines.push(`EPG: ${stats.channelCount}频道/${stats.totalProgrammes}节目`);
                        if (state.epgLastUpdate) {
                            const minutesAgo = Math.floor((new Date() - state.epgLastUpdate) / 60000);
                            lines.push(`EPG更新: ${minutesAgo}分钟前`);
                        }
                    } else if (state.currentEpgUrl) {
                        lines.push(`EPG: 加载中...`);
                    } else if (state.epgLoadingError) {
                        lines.push(`EPG: 加载失败`);
                    } else {
                        lines.push(`EPG: 未配置`);
                    }
                }
                if (state.currentEpgUrl) {
                    try {
                        const url = new URL(state.currentEpgUrl);
                        lines.push(`EPG源: ${url.hostname}`);
                    } catch (e) {
                        lines.push(`EPG源: 已配置`);
                    }
                }
            }
        }
        if (state.blacklist.length > 0) {
            lines.push(`黑名单: ${state.blacklist.length}个规则`);
        }
        //UI.infoPanel.innerHTML = lines.join("<br>");
        // 创建带颜色分类的HTML内容
        const coloredLines = lines.map(line => {
            if (line.includes(':')) {
                const parts = line.split(':');
                const label = parts[0];
                const value = parts.slice(1).join(':').trim();
                return `<div class="info-line"><span class="info-label">${label}</span> <span class="info-maohao">:</span> <span class="info-value">${value}</span></div>`;
            }
            return `<div class="info-line"><span class="info-label">${line}</span></div>`;
        });
        
        UI.infoPanel.innerHTML = coloredLines.join('');
    }
    function toggleVideoInfo() {
        updateInfoPanel();
        const currentDisplay = UI.infoPanel.style.display;
        UI.infoPanel.style.display = currentDisplay === "none" ? "block" : "none";
    }
    function updateProgress() {
        const { currentTime, duration } = UI.videoPlayer;
        if (duration && !isNaN(duration) && duration !== Infinity) {
            const percent = currentTime / duration * 100;
            UI.progressBar.style.width = percent + "%";
            UI.timeDisplay.textContent = `${formatTime(currentTime)} / ${formatTime(duration)}`;
        } else {
            UI.progressBar.style.width = "100%";
            UI.timeDisplay.textContent = `${formatTime(currentTime)} / Live`;
        }
    }
    function seek(e) {
        if (!UI.videoPlayer.duration || UI.videoPlayer.duration === Infinity) return;
        const rect = UI.progress.getBoundingClientRect();
        const pos = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
        UI.videoPlayer.currentTime = pos * UI.videoPlayer.duration;
    }
    function adjustVolume(e) {
        const rect = UI.volumeSlider.getBoundingClientRect();
        let volume = (e.clientX - rect.left) / rect.width;
        volume = Math.max(0, Math.min(1, volume));
        UI.videoPlayer.volume = volume;
        UI.volumeProgress.style.width = volume * 100 + "%";
        updateVolumeIcon();
        chrome.storage.local.set({
            volume: volume
        });
    }
    function updateVolumeIcon() {
        const v = UI.videoPlayer.volume;
        if (UI.videoPlayer.muted || v === 0) UI.volumeBtn.textContent = "🔇";
        else if (v < .5) UI.volumeBtn.textContent = "🔉";
        else UI.volumeBtn.textContent = "🔊";
    }
    function toggleMute() {
        UI.videoPlayer.muted = !UI.videoPlayer.muted;
        updateVolumeIcon();
    }
    function toggleFullscreen() {
        const container = document.querySelector(".player-container");
        if (!document.fullscreenElement) {
            (container.requestFullscreen || container.webkitRequestFullscreen || container.msRequestFullscreen).call(container);
        } else {
            (document.exitFullscreen || document.webkitExitFullscreen || document.msExitFullscreen).call(document);
        }
    }
    function togglePlayPause() {
        if (UI.videoPlayer.paused) attemptPlay();
        else UI.videoPlayer.pause();
    }
    function showControls() {
        UI.controls.classList.remove("hidden");
        if (state.timers.controls) clearTimeout(state.timers.controls);
        state.timers.controls = setTimeout(() => {
            if (state.isPlaying) {
                UI.controls.classList.add("hidden");
            }
        }, 30000);
    }
    function initGlobalEvents() {
        document.addEventListener("mousemove", showControls);
        document.addEventListener("keydown", handleKeyDown);
        UI.playPauseBtn.onclick = togglePlayPause;
        UI.prevChannelBtn.onclick = function(e) {
            e.stopPropagation();
            switchToPrevChannel();
        };
        UI.nextChannelBtn.onclick = function(e) {
            e.stopPropagation();
            switchToNextChannel();
        };
        UI.volumeBtn.onclick = toggleMute;
        UI.volumeSlider.onclick = adjustVolume;
        UI.fullscreenBtn.onclick = toggleFullscreen;
        UI.backBtn.onclick = () => window.close();
        UI.infoBtn.onclick = toggleVideoInfo;
        UI.playlistBtn.onclick = () => togglePlaylistUI();
        UI.closePlaylistBtn.onclick = () => togglePlaylistUI(false);
        UI.progress.onclick = seek;
        UI.playlistSearchInput.oninput = handlePlaylistSearch;
        UI.clearSearchBtn.onclick = clearSearch;
        UI.switchSourceBtn.onclick = function(e) {
            e.stopPropagation();
            manualSwitchToNextSource();
        };
        UI.playlistContainer.onmouseleave = () => {
            if (document.activeElement !== UI.playlistSearchInput) {
                state.timers.hidePlaylist = setTimeout(() => togglePlaylistUI(false), 300);
            }
        };
        UI.playlistContainer.onmouseenter = () => {
            if (state.timers.hidePlaylist) clearTimeout(state.timers.hidePlaylist);
        };
    }
    // ==================== 清理函数 ====================
    function cleanup() {
        stopEPGUpdateTimer();
        if (state.timers.epgPreview) {
            clearTimeout(state.timers.epgPreview);
        }
        if (state.timers.epgCheck) {
            clearInterval(state.timers.epgCheck);
            state.timers.epgCheck = null;
        }
        if (state.epgManager) {
            state.epgManager.stopAutoRefresh();
        }
    }
    window.addEventListener('beforeunload', function() {
        cleanup();
        if (state.timers.refreshPlaylist) {
            clearTimeout(state.timers.refreshPlaylist);
            console.log('[清理] 播放列表刷新定时器已清理');
        }
        if (state.timers.load) {
            clearTimeout(state.timers.load);
            console.log('[清理] 加载定时器已清理');
        }
        if (state.timers.stall) {
            clearTimeout(state.timers.stall);
            console.log('[清理] 卡顿定时器已清理');
        }
    });
    // ==================== 修改的initM3UPlaylist函数 ====================
    function initM3UPlaylist(url) {
        state.isM3UPlaylist = true;
        state.streamInfo.type = "M3U";
        const parser = new M3UParser;
        parser.parseFromUrl(url).then(playlist => {
            if (!playlist || playlist.length === 0) {
                throw new Error("播放列表为空");
            }
            const processedPlaylist = playlist.map(item => {
                const rawUrls = item.urls && item.urls.length > 0 ? item.urls : [item.url];
                const validUrls = rawUrls.filter(u => u).map(u => {
                    if (!u.startsWith("http") && !u.startsWith("//")) {
                        return M3UParser.resolveUrl(state.baseUrl, u);
                    }
                    return u;
                });
                item.urls = validUrls;
                return item;
            }).filter(item => item.urls.length > 0);
            if (processedPlaylist.length === 0) {
                throw new Error("解析后无有效项目");
            }
            if (state.currentPlaylist.length === 0) {
                state.currentPlaylist = processedPlaylist;
                renderPlaylist();
                playPlaylistItem(0);
                togglePlaylistUI(true);
                // 初始化EPG
                initEPGManager();
                // 优先使用配置的EPG URL，如果没有再使用M3U中的EPG URL
                if (state.currentEpgUrl && CONFIG.SHOW_EPG) {
                    console.log('[EPG] 使用配置的EPG URL:', state.currentEpgUrl);
                    loadEPG(state.currentEpgUrl);
                } else if (parser.globalEpgUrl && CONFIG.SHOW_EPG) {
                    console.log('[EPG] 使用M3U中的EPG URL:', parser.globalEpgUrl);
                    state.currentEpgUrl = parser.globalEpgUrl;
                    loadEPG(parser.globalEpgUrl);
                } else if (CONFIG.SHOW_EPG) {
                    console.log('[EPG] 未配置EPG URL，无法加载节目指南');
                    showNotification('未配置EPG源，无法显示节目指南', 3000);
                }
                if (CONFIG.AUTO_REFRESH_ENABLED) {
                    startPlaylistRefreshTimer();
                }
            } else {
                refreshPlaylist(processedPlaylist);
            }
        }).catch(err => {
            console.error("M3U解析失败:", err);
            showError("解析播放列表失败: " + err.message);
        });
    }
    function startPlaylistRefreshTimer() {
        if (state.timers.refreshPlaylist) {
            clearTimeout(state.timers.refreshPlaylist);
            state.timers.refreshPlaylist = null;
        }
        if (!CONFIG.AUTO_REFRESH_ENABLED) {
            console.log('[定时刷新] 自动刷新已禁用');
            return;
        }
        if (CONFIG.PLAYLIST_REFRESH_INTERVAL <= 0) {
            console.log('[定时刷新] 刷新间隔为0，不启用定时刷新');
            return;
        }
        state.timers.refreshPlaylist = setTimeout(() => {
            console.log(`[定时刷新] 开始刷新播放列表...`);
            refreshM3UPlaylist();
        }, CONFIG.PLAYLIST_REFRESH_INTERVAL);
        console.log(`[定时刷新] 已设置定时器，${Math.round(CONFIG.PLAYLIST_REFRESH_INTERVAL/1000)}秒后刷新`);
    }
    function refreshM3UPlaylist() {
        if (!state.isM3UPlaylist || !state.originalPlaylistUrl) {
            console.warn("[定时刷新] 当前不是M3U播放列表或缺少原始URL");
            startPlaylistRefreshTimer();
            return;
        }
        console.log(`[定时刷新] 刷新播放列表: ${state.originalPlaylistUrl}`);
        const parser = new M3UParser;
        parser.parseFromUrl(state.originalPlaylistUrl).then(playlist => {
            if (!playlist || playlist.length === 0) {
                console.warn("[定时刷新] 刷新的播放列表为空");
                startPlaylistRefreshTimer();
                return;
            }
            const processedPlaylist = playlist.map(item => {
                const rawUrls = item.urls && item.urls.length > 0 ? item.urls : [item.url];
                const validUrls = rawUrls.filter(u => u).map(u => {
                    if (!u.startsWith("http") && !u.startsWith("//")) {
                        return M3UParser.resolveUrl(state.baseUrl, u);
                    }
                    return u;
                });
                item.urls = validUrls;
                return item;
            }).filter(item => item.urls.length > 0);
            if (processedPlaylist.length === 0) {
                console.warn("[定时刷新] 解析后无有效项目");
                startPlaylistRefreshTimer();
                return;
            }
            refreshPlaylist(processedPlaylist);
            startPlaylistRefreshTimer();
            // 播放列表刷新后，也刷新EPG信息
            if (state.epgManager && state.epgManager.isLoaded) {
                console.log('[EPG] 播放列表刷新后更新EPG信息');
                setTimeout(() => {
                    updateAllChannelEPG();
                }, 2000);
            }
        }).catch(err => {
            console.error("[定时刷新] M3U解析失败:", err);
            startPlaylistRefreshTimer();
        });
    }
    function refreshPlaylist(newPlaylist) {
        console.log('[定时刷新] 开始刷新播放列表...');
        const oldIndex = state.currentPlaylistIndex;
        const oldItem = oldIndex >= 0 ? state.currentPlaylist[oldIndex] : null;
        if (oldItem) {
            state.currentChannelInfo = {
                title: oldItem.title || "",
                originalIndex: oldIndex,
                urls: [...oldItem.urls],
                currentUrlIndex: oldItem.currentUrlIndex || 0,
                currentRound: oldItem.currentRound || 1
            };
            console.log(`[定时刷新] 保存当前频道: "${state.currentChannelInfo.title}"`);
        }
        const oldPlaylist = [...state.currentPlaylist];
        state.currentPlaylist = newPlaylist;
        let newIndex = -1;
        if (state.currentChannelInfo.title) {
            newIndex = state.currentPlaylist.findIndex(item =>
                item.title === state.currentChannelInfo.title
            );
            if (newIndex === -1 && state.currentChannelInfo.urls.length > 0) {
                newIndex = state.currentPlaylist.findIndex(item =>
                    item.urls && item.urls.some(url =>
                        state.currentChannelInfo.urls.includes(url)
                    )
                );
            }
        }
        if (newIndex === -1) {
            console.log(`[定时刷新] 当前频道在新列表中不存在，继续播放原频道`);
            if (oldItem) {
                const preservedItem = {
                    ...oldItem,
                    title: oldItem.title ? `${oldItem.title} (旧列表)` : "旧列表频道"
                };
                state.currentPlaylist.push(preservedItem);
                newIndex = state.currentPlaylist.length - 1;
                state.currentPlaylistIndex = newIndex;
            }
        } else {
            console.log(`[定时刷新] 在新列表中找到当前频道，位置: ${newIndex}`);
            state.currentPlaylistIndex = newIndex;
            const newItem = state.currentPlaylist[newIndex];
            if (newItem.urls && newItem.urls.length > 0) {
                newItem.currentUrlIndex = oldItem ? oldItem.currentUrlIndex || 0 : 0;
                newItem.currentRound = oldItem ? oldItem.currentRound || 1 : 1;
            }
        }
        renderPlaylist(UI.playlistSearchInput.value);
        updatePlaylistHighlight();
        // 更新EPG信息
        if (state.epgManager && state.epgManager.isLoaded) {
            updateAllChannelEPG();
        }
        if (!UI.playlistContainer.classList.contains("hidden")) {
            const currentSearch = UI.playlistSearchInput.value;
            if (currentSearch) {
                renderPlaylist(currentSearch);
            }
            addRefreshIndicator();
        }
        showRefreshNotification(`播放列表已刷新: ${oldPlaylist.length} → ${newPlaylist.length} 个频道`);
        console.log(`[定时刷新] 播放列表刷新完成: ${oldPlaylist.length} → ${newPlaylist.length} 个频道`);
    }
    function addRefreshIndicator() {
        const oldIndicator = UI.playlistContainer.querySelector('.refresh-indicator');
        if (oldIndicator) {
            oldIndicator.remove();
        }
        const indicator = document.createElement('div');
        indicator.className = 'refresh-indicator';
        indicator.textContent = '刷新中...';
        indicator.style.cssText = `
            position: absolute;
            top: 10px;
            right: 10px;
            background: rgba(0, 100, 0, 0.8);
            color: white;
            padding: 5px 10px;
            border-radius: 3px;
            font-size: 12px;
            z-index: 1002;
        `;
        UI.playlistContainer.appendChild(indicator);
        setTimeout(() => {
            if (indicator.parentNode) {
                indicator.parentNode.removeChild(indicator);
            }
        }, 1500);
    }
    function showRefreshNotification(message) {
        const oldNotifications = document.querySelectorAll('.refresh-notification');
        oldNotifications.forEach(n => n.remove());
        const notification = document.createElement("div");
        notification.className = "refresh-notification";
        notification.textContent = message;
        if (!document.querySelector('#refresh-notification-style')) {
            const style = document.createElement('style');
            style.id = 'refresh-notification-style';
            style.textContent = `
                @keyframes fadeInOut {
                    0% { opacity: 0; transform: translateY(-10px); }
                    10% { opacity: 1; transform: translateY(0); }
                    90% { opacity: 1; transform: translateY(0); }
                    100% { opacity: 0; transform: translateY(-10px); }
                }
                .refresh-notification {
                    pointer-events: none;
                }
            `;
            document.head.appendChild(style);
        }
        document.body.appendChild(notification);
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 3000);
    }
    function manualSwitchToNextSource() {
        if (state.currentPlaylistIndex === -1) return;
        const item = state.currentPlaylist[state.currentPlaylistIndex];
        if (!item || !item.urls || item.urls.length === 0) {
            showError("当前频道没有可用的源");
            return;
        }
        if (item.urls.length <= 1) {
            showNotification("当前频道只有一个源", 1500);
            return;
        }
        if (item.currentUrlIndex === undefined) item.currentUrlIndex = 0;
        if (item.currentRound === undefined) item.currentRound = 1;
        const nextIndex = (item.currentUrlIndex + 1) % item.urls.length;
        if (nextIndex === 0) {
            if (item.currentRound < CONFIG.MAX_RETRY_ROUNDS) {
                item.currentRound++;
            }
        }
        console.log(`[手动换源] 从源 ${item.currentUrlIndex + 1} 切换到源 ${nextIndex + 1} (轮次: ${item.currentRound}/${CONFIG.MAX_RETRY_ROUNDS})`);
        item.currentUrlIndex = nextIndex;
        const nextUrl = item.urls[nextIndex];
        if (checkUrlInBlacklist(nextUrl, "手动换源URL")) {
            setTimeout(() => manualSwitchToNextSource(), 500);
            return;
        }
        showLoading(true);
        UI.errorMessage.style.display = "none";
        showNotification(`切换到源 ${nextIndex + 1}/${item.urls.length}`, 2000);
        destroyPlayer();
        checkAndInitPlayer(nextUrl);
        if (state.timers.load) clearTimeout(state.timers.load);
        state.timers.load = setTimeout(() => {
            console.error(`[手动换源] 加载超时 (${CONFIG.LOAD_TIMEOUT_MS}ms)，触发自动换源逻辑。`);
            tryNextRedundantUrl();
        }, CONFIG.LOAD_TIMEOUT_MS);
        setTimeout(updateInfoPanel, 500);
    }
    function showNotification(message, duration = 2000) {
        const oldNotification = document.querySelector('.source-notification');
        if (oldNotification) {
            oldNotification.remove();
        }
        const notification = document.createElement("div");
        notification.className = "source-notification";
        notification.textContent = message;
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            left: 50%;
            transform: translateX(-50%);
            background: rgba(0, 100, 200, 0.9);
            color: white;
            padding: 10px 15px;
            border-radius: 5px;
            z-index: 1000;
            font-size: 14px;
            animation: fadeInOut ${duration/1000}s ease-in-out;
        `;
        document.body.appendChild(notification);
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, duration);
    }
    function tryNextRedundantUrl() {
        if (state.currentPlaylistIndex === -1) return;
        const item = state.currentPlaylist[state.currentPlaylistIndex];
        if (!item || !item.urls || item.urls.length === 0) {
            showError("播放列表数据错误");
            return;
        }
        if (item.currentRound === undefined) item.currentRound = 1;
        if (item.currentUrlIndex === undefined) item.currentUrlIndex = 0;
        const nextIndex = item.currentUrlIndex + 1;
        if (nextIndex < item.urls.length) {
            item.currentUrlIndex = nextIndex;
        } else if (item.currentRound < CONFIG.MAX_RETRY_ROUNDS) {
            item.currentUrlIndex = 0;
            item.currentRound++;
            console.warn(`频道 [${item.title}] 开启第 ${item.currentRound}/${CONFIG.MAX_RETRY_ROUNDS} 轮尝试...`);
            showNotification(`第 ${item.currentRound} 轮尝试 (共 ${CONFIG.MAX_RETRY_ROUNDS} 轮)`, 2000);
        } else {
            if (state.timers.load) {
                clearTimeout(state.timers.load);
                state.timers.load = null;
            }
            destroyPlayer();
            state.isPlaying = false;
            UI.playPauseBtn.textContent = "▶";
            UI.playPauseBtn.title = "播放";
            showError(`频道 [${item.title || "未知"}] 无法播放或太过卡顿，请尝试其他频道。`);
            return;
        }
        const nextUrl = item.urls[item.currentUrlIndex];
        if (checkUrlInBlacklist(nextUrl, "自动换源URL")) {
            setTimeout(() => tryNextRedundantUrl(), 500);
            return;
        }
        console.warn(`自动换源 (轮次:${item.currentRound}, 索引:${item.currentUrlIndex}): ${nextUrl}`);
        showNotification(`自动切换到源 ${item.currentUrlIndex + 1}/${item.urls.length}`, 1500);
        destroyPlayer();
        showLoading(true);
        UI.errorMessage.style.display = "none";
        checkAndInitPlayer(nextUrl);
        state.timers.load = setTimeout(() => {
            console.error(`加载超时 (${CONFIG.LOAD_TIMEOUT_MS}ms)，切换线路。`);
            tryNextRedundantUrl();
        }, CONFIG.LOAD_TIMEOUT_MS);
    }
    init();
});