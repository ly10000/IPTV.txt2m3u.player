// 屏蔽普通日志和信息
console.log = function() {};
console.info = function() {};
/**
 * EPGManager - 电子节目指南管理器
 * 支持XMLTV格式EPG数据，为播放器提供节目信息
 * 新增：支持 .gz 压缩格式
 */
class EPGManager {
    constructor() {
        this.channelMap = {};      // 清洗后的频道名称 -> XMLTV ID 映射
        this.epgData = {};         // 频道ID -> 节目列表 映射
        this.epgCache = {};        // 查询结果缓存
        this.isLoaded = false;     // 加载状态标志
        this.currentEpgUrl = null; // 当前EPG源URL
        this.refreshTimer = null;  // 自动刷新定时器
        this.loadingCallbacks = []; // 加载完成回调函数
        // 新增：检查浏览器是否支持压缩流API
        this.isGzipSupported = typeof DecompressionStream !== 'undefined';
    }
    /**
     * 检查是否为压缩格式
     * @private
     */
    _isCompressedFormat(response, url) {
        // 检查 Content-Encoding 头
        const contentEncoding = response.headers.get('Content-Encoding');
        if (contentEncoding && (contentEncoding.includes('gzip') || contentEncoding.includes('deflate'))) {
            return true;
        }
        // 检查文件扩展名
        const urlLower = url.toLowerCase();
        if (urlLower.endsWith('.gz') || urlLower.endsWith('.gzip')) {
            return true;
        }
        // 检查 Content-Type
        const contentType = response.headers.get('Content-Type');
        if (contentType && contentType.includes('gzip')) {
            return true;
        }
        return false;
    }
    /**
     * 解压缩响应数据（如果被压缩）
     * @private
     */
    async _decompressIfNeeded(response, url) {
        const isCompressed = this._isCompressedFormat(response, url);
        if (!isCompressed) {
            // 不是压缩格式，直接返回文本
            return await response.text();
        }
        // 检查浏览器支持
        if (!this.isGzipSupported) {
            throw new Error('浏览器不支持压缩格式解压。请使用Chrome 80+、Firefox 113+、Edge 80+或Safari 16.4+版本。');
        }
        console.log('[EPG] 检测到压缩格式，正在解压...');
        try {
            let decompressedStream;
            // 方法1：使用响应体流式解压
            if (response.body) {
                decompressedStream = response.body.pipeThrough(new DecompressionStream('gzip'));
            } 
            // 方法2：使用ArrayBuffer解压（备用）
            else {
                const arrayBuffer = await response.arrayBuffer();
                decompressedStream = new Blob([arrayBuffer]).stream()
                    .pipeThrough(new DecompressionStream('gzip'));
            }
            // 将解压后的流转换为文本
            const decompressedResponse = new Response(decompressedStream);
            const text = await decompressedResponse.text();
            console.log('[EPG] 解压成功');
            return text;
        } catch (error) {
            console.error('[EPG] 解压失败:', error);
            // 尝试回退方案：如果可能，直接读取文本
            try {
                const fallbackText = await response.text();
                // 检查是否是乱码（压缩数据）
                if (fallbackText.charCodeAt(0) === 0x1F && fallbackText.charCodeAt(1) === 0x8B) {
                    throw new Error('检测到gzip格式但解压失败');
                }
                return fallbackText;
            } catch (fallbackError) {
                throw new Error(`无法解压EPG数据: ${error.message}`);
            }
        }
    }
    /**
     * 精准清洗频道名称（修复CCTV10科教频道匹配问题）
     * @param {string} name - 原始频道名称
     * @returns {string} 清洗后的名称
     */
    cleanName(name) {
        if (!name || typeof name !== 'string') return "";
        let cleaned = name
            .toLowerCase()
            .replace(/\s+/g, "")
            .replace(/[^\w\+\-\u4e00-\u9fa5]/g, "")
            .trim();
        // 统一符号
        cleaned = cleaned.replace(/plus/g, '+');
        console.log(`[EPG调试] 清洗: "${name}" -> "${cleaned}"`);
        // ========== 特殊频道映射表 ==========
        const specialChannels = {
            // 4K/8K超高清频道
            'cctv4k': 'cctv4k',
            'cctv8k': 'cctv8k',
            'cctv4k超高清': 'cctv4k',
            'cctv8k超高清': 'cctv8k',
            'cctv-4k': 'cctv4k',
            'cctv-8k': 'cctv8k',
            // 错误名称修正
            'cctv-': 'cctv',
            'cctv_': 'cctv',
            'cctv ': 'cctv',
            // 其他特殊处理
            'cctv4k+': 'cctv4k+',
            'cctv8k+': 'cctv8k+'
        };
        // 先检查特殊频道映射
        if (specialChannels[cleaned]) {
            console.log(`[EPG调试] 特殊频道映射: "${cleaned}" -> "${specialChannels[cleaned]}"`);
            return specialChannels[cleaned];
        }
        // ========== 正则匹配 ==========
        // 1. 4K/8K频道（优先于数字频道）
        const hdMatch = cleaned.match(/^(cctv|channel|tv)[\-_]?(4k|8k)(\+)?$/i);
        if (hdMatch) {
            const result = hdMatch[1] + hdMatch[2] + (hdMatch[3] || '');
            console.log(`[EPG调试] 4K/8K频道: "${cleaned}" -> "${result}"`);
            return result;
        }
        // 2. 带+号的数字频道
        const plusMatch = cleaned.match(/^(cctv|channel|tv)[\-_]?(\d+)\+$/i);
        if (plusMatch) {
            const result = plusMatch[1] + plusMatch[2] + '+';
            console.log(`[EPG调试] 带+号频道: "${cleaned}" -> "${result}"`);
            return result;
        }
        // 3. 普通数字频道
        const numberMatch = cleaned.match(/^(cctv|channel|tv)[\-_]?(\d+)/i);
        if (numberMatch) {
            const result = numberMatch[1] + numberMatch[2];
            console.log(`[EPG调试] 数字频道: "${cleaned}" -> "${result}"`);
            return result;
        }
        // 4. CCTV+中文
        if (cleaned.startsWith('cctv')) {
            const withoutCctv = cleaned.substring(4);
            if (withoutCctv && /^[\u4e00-\u9fa5]+$/.test(withoutCctv)) {
                console.log(`[EPG调试] CCTV+中文: "${cleaned}" -> "${withoutCctv}"`);
                return withoutCctv;
            }
        }
        // 5. 后缀处理
        const suffixes = [
            '超高清', '高清', '标清', 'hd', 'sd', 'fhd', 'uhd',
            '卫视', '卫视+', '卫视高清', '卫视标清',
            '台', '频道', 'channel', 'tv'
        ];
        for (const suffix of suffixes) {
            if (cleaned.endsWith(suffix)) {
                const result = cleaned.slice(0, -suffix.length);
                console.log(`[EPG调试] 去除后缀: "${cleaned}" -> "${result}"`);
                // 如果去除后缀后是空字符串，返回原始
                if (!result) {
                    console.log(`[EPG调试] 警告: 去除后缀后为空，返回原始: "${cleaned}"`);
                    return cleaned;
                }
                return result;
            }
        }
        console.log(`[EPG调试] 最终结果: "${cleaned}"`);
        return cleaned;
    }
    /**
     * 解析XMLTV时间字符串（支持全球时区）
     * @param {string} dateStr - XMLTV格式时间字符串
     * @returns {Date} 解析后的Date对象
     */
    parseXMLTVDate(dateStr) {
        if (!dateStr) return null;
        try {
            // 提取日期部分（前14位）
            const datePart = dateStr.substring(0, 14);
            if (datePart.length < 14) {
                console.warn('时间格式不完整:', dateStr);
                return null;
            }
            // 解析基本时间
            const year = parseInt(datePart.substring(0, 4), 10);
            const month = parseInt(datePart.substring(4, 6), 10) - 1; // 月份从0开始
            const day = parseInt(datePart.substring(6, 8), 10);
            const hour = parseInt(datePart.substring(8, 10), 10);
            const minute = parseInt(datePart.substring(10, 12), 10);
            const second = parseInt(datePart.substring(12, 14), 10);
            // 验证日期有效性
            if (isNaN(year) || isNaN(month) || isNaN(day) || 
                isNaN(hour) || isNaN(minute) || isNaN(second)) {
                console.warn('时间解析失败:', dateStr);
                return null;
            }
            // 解析时区偏移
            const tzMatch = dateStr.match(/\s?([\+\-]\d{4})$/);
            if (!tzMatch) {
                // 没有时区信息，假设是本地时间
                return new Date(year, month, day, hour, minute, second);
            }
            // 有时区信息
            const tzOffsetStr = tzMatch[1];
            const tzSign = tzOffsetStr[0] === '+' ? 1 : -1;
            const tzHours = parseInt(tzOffsetStr.substring(1, 3), 10);
            const tzMinutes = parseInt(tzOffsetStr.substring(3, 5), 10);
            const tzOffsetMinutes = (tzHours * 60 + tzMinutes) * tzSign;
            // 创建UTC时间
            const utcDate = new Date(Date.UTC(year, month, day, hour, minute, second));
            // 重要：EPG中的时间已经是该时区的本地时间
            // 例如：EPG时间 "20260112010400 +0800" 表示北京时间01:04
            // 对应的UTC时间是 2026-01-11 17:04:00
            // 所以需要减去时区偏移来得到正确的UTC时间
            const adjustedDate = new Date(utcDate.getTime() - (tzOffsetMinutes * 60000));
            // 调试信息（可选）
            // console.log(`时间解析: ${dateStr} -> UTC: ${utcDate.toISOString()} -> 调整后: ${adjustedDate.toISOString()}`);
            // 最终验证
            if (isNaN(adjustedDate.getTime())) {
                console.warn('生成的时间无效:', dateStr);
                return null;
            }
            return adjustedDate;
        } catch (error) {
            console.error('时间解析异常:', error, '原始字符串:', dateStr);
            return null;
        }
    }
    /**
     * 获取本地时区信息
     * @returns {Object} 时区信息
     */
    getTimezoneInfo() {
        const now = new Date();
        const timezoneOffset = now.getTimezoneOffset();
        const offsetHours = Math.floor(Math.abs(timezoneOffset) / 60);
        const offsetMinutes = Math.abs(timezoneOffset) % 60;
        const sign = timezoneOffset <= 0 ? '+' : '-';
        return {
            timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'Unknown',
            offset: timezoneOffset,
            offsetHours: -timezoneOffset / 60,
            offsetString: `UTC${sign}${offsetHours.toString().padStart(2, '0')}:${offsetMinutes.toString().padStart(2, '0')}`,
            localTime: now.toLocaleString(),
            utcTime: now.toUTCString()
        };
    }
    /**
     * 测试时间解析功能
     */
    testTimeParsing() {
        const testData = [
            '20260112010400 +0800',  // 北京时间
            '20260112010400',         // 无时区
            '20260112010400 +0000',   // UTC时间
            '20260112010400 -0500',   // 美国东部时间
            '20260112010400 +0100',   // 欧洲中部时间
            '20260112010400 +0900'    // 日本时间
        ];
        console.log('=== EPG时间解析测试 ===');
        const timezoneInfo = this.getTimezoneInfo();
        console.log('浏览器时区:', timezoneInfo.timeZone);
        console.log('时区偏移:', timezoneInfo.offsetString);
        console.log('当前本地时间:', timezoneInfo.localTime);
        console.log('当前UTC时间:', timezoneInfo.utcTime);
        testData.forEach(str => {
            const parsed = this.parseXMLTVDate(str);
            console.log(`\n原始字符串: ${str}`);
            console.log(`解析结果: ${parsed ? parsed.toString() : '解析失败'}`);
            if (parsed) {
                console.log(`本地显示: ${parsed.toLocaleString('zh-CN')}`);
                console.log(`ISO格式: ${parsed.toISOString()}`);
                console.log(`本地小时: ${parsed.getHours()}:${parsed.getMinutes()}`);
                console.log(`UTC小时: ${parsed.getUTCHours()}:${parsed.getUTCMinutes()}`);
            }
        });
    }
    /**
     * 从指定URL加载EPG数据（完整修复版，支持压缩格式）
     * @param {string} url - EPG数据源URL
     * @param {Object} options - 加载选项
     * @returns {Promise<Object>} 加载结果
     */
    async fetchEPG(url, options = {}) {
        const {
            timeout = 10000,        // 超时时间
            retry = 2,              // 重试次数
            autoRefresh = true,     // 是否自动刷新
            refreshInterval = 3600000 // 刷新间隔(1小时)
        } = options;
        // 新增：强制格式选项（可选）
        const forceFormat = options.forceFormat || 'auto'; // 'auto', 'xml', 'gzip'
        this.currentEpgUrl = url;
        try {
            console.log(`[EPG] 开始加载EPG数据: ${url}`);
            console.log(`[EPG] 浏览器支持压缩: ${this.isGzipSupported ? '是' : '否'}`);
            showNotification('正在加载节目指南...', 2000);
            // 设置超时
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), timeout);
            let response;
            let attempt = 0;
            // 重试机制
            while (attempt <= retry) {
                try {
                    response = await fetch(url, { 
                        signal: controller.signal,
                        cache: 'no-cache',
                        headers: {
                            'Accept': 'application/xml, text/xml, */*'
                        }
                    });
                    break;
                } catch (fetchError) {
                    attempt++;
                    if (attempt > retry) {
                        throw new Error(`EPG加载失败，重试${retry}次后仍无法连接`);
                    }
                    console.warn(`[EPG] 第${attempt}次重试...`);
                    await new Promise(resolve => setTimeout(resolve, 1000 * attempt));
                }
            }
            clearTimeout(timeoutId);
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            // 修改点：使用新的解压方法
            let xmlText;
            try {
                xmlText = await this._decompressIfNeeded(response, url);
            } catch (decompressError) {
                // 解压失败，尝试直接读取文本（可能是未压缩格式）
                console.warn('[EPG] 解压失败，尝试直接读取:', decompressError.message);
                xmlText = await response.text();
            }
            // 检查XML格式
            if (xmlText.includes('<parsererror>')) {
                throw new Error('EPG数据格式错误，无效的XML');
            }
            // 解析XML
            const parser = new DOMParser();
            const xmlDoc = parser.parseFromString(xmlText, "text/xml");
            // 清空现有数据
            this.channelMap = {};
            this.epgData = {};
            this.epgCache = {};
            // ==================== 1. 扫描所有频道，建立名称索引 ====================
            const channels = xmlDoc.getElementsByTagName("channel");
            console.log(`[EPG] 发现 ${channels.length} 个频道`);
            // 统计频道类型
            const channelStats = {
                total: channels.length,
                numberChannels: 0,
                plusChannels: 0,
                chineseChannels: 0,
                otherChannels: 0
            };
            for (let ch of channels) {
                const id = ch.getAttribute("id");
                if (!id) continue;
                const displayNames = ch.getElementsByTagName("display-name");
                const processedNames = new Set(); // 避免重复添加相同的清洗名称
                // 在 fetchEPG() 的频道处理部分添加：
                for (let dn of displayNames) {
                    if (dn.textContent) {
                        const originalName = dn.textContent.trim();
                        const normalized = this.cleanName(originalName);
                        if (normalized) {
                            // 基础映射
                            if (!this.channelMap[normalized]) {
                                this.channelMap[normalized] = [];
                            }
                            if (!this.channelMap[normalized].includes(id)) {
                                this.channelMap[normalized].push(id);
                            }
                            // 统计频道类型
                            if (normalized.match(/^cctv\d+$/)) {
                                channelStats.numberChannels++;
                            } else if (normalized.match(/^cctv\d+\+$/)) {
                                channelStats.plusChannels++;
                            } else if (/^[\u4e00-\u9fa5]+$/.test(normalized)) {
                                channelStats.chineseChannels++;
                            } else {
                                channelStats.otherChannels++;
                            }
                            // ========== 特殊频道的别名映射 ==========
                            // 1. 4K/8K频道的别名
                            if (normalized === 'cctv4k') {
                                // 添加常见变体
                                const variants = ['cctv4k', 'cctv-4k', 'cctv_4k', 'cctv 4k', 'cctv4k超高清'];
                                for (const variant of variants) {
                                    if (!this.channelMap[variant]) {
                                        this.channelMap[variant] = [];
                                    }
                                    if (!this.channelMap[variant].includes(id)) {
                                        this.channelMap[variant].push(id);
                                    }
                                }
                            }
                            if (normalized === 'cctv8k') {
                                const variants = ['cctv8k', 'cctv-8k', 'cctv_8k', 'cctv 8k', 'cctv8k超高清'];
                                for (const variant of variants) {
                                    if (!this.channelMap[variant]) {
                                        this.channelMap[variant] = [];
                                    }
                                    if (!this.channelMap[variant].includes(id)) {
                                        this.channelMap[variant].push(id);
                                    }
                                }
                            }
                            // 2. 错误名称的修正
                            if (normalized === 'cctv') {
                                // 如果有人错误输入"cctv-"，也能匹配到CCTV
                                const errorVariants = ['cctv-', 'cctv_', 'cctv '];
                                for (const variant of errorVariants) {
                                    if (!this.channelMap[variant]) {
                                        this.channelMap[variant] = [];
                                    }
                                    if (!this.channelMap[variant].includes(id)) {
                                        this.channelMap[variant].push(id);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            console.log(`[EPG] 频道统计: 数字频道${channelStats.numberChannels}个, ` +
                       `+号频道${channelStats.plusChannels}个, ` +
                       `中文频道${channelStats.chineseChannels}个, ` +
                       `其他${channelStats.otherChannels}个`);
            // ==================== 2. 扫描所有节目 ====================
            const programmes = xmlDoc.getElementsByTagName("programme");
            console.log(`[EPG] 发现 ${programmes.length} 个节目`);
            let validPrograms = 0;
            let skippedPrograms = 0;
            for (let prog of programmes) {
                const channelId = prog.getAttribute("channel");
                if (!channelId) {
                    skippedPrograms++;
                    continue;
                }
                if (!this.epgData[channelId]) {
                    this.epgData[channelId] = [];
                }
                const startTime = this.parseXMLTVDate(prog.getAttribute("start"));
                const stopTime = this.parseXMLTVDate(prog.getAttribute("stop"));
                // 验证时间有效性
                if (!startTime || !stopTime || stopTime <= startTime) {
                    skippedPrograms++;
                    continue;
                }
                const titleElement = prog.getElementsByTagName("title")[0];
                const descElement = prog.getElementsByTagName("desc")[0];
                const categoryElement = prog.getElementsByTagName("category")[0];
                this.epgData[channelId].push({
                    start: startTime,
                    stop: stopTime,
                    title: titleElement?.textContent?.trim() || "无题节目",
                    desc: descElement?.textContent?.trim() || "",
                    category: categoryElement?.textContent?.trim() || "",
                    duration: Math.floor((stopTime - startTime) / 60000) // 分钟数
                });
                validPrograms++;
            }
            this.isLoaded = true;
            console.log(`[EPG] 加载成功: ${validPrograms}个有效节目，${skippedPrograms}个被跳过`);
            console.log(`[EPG] 频道映射表: ${Object.keys(this.channelMap).length}个唯一名称`);
            // 显示重要的频道映射示例
            const sampleChannels = Object.entries(this.channelMap)
                .filter(([name]) => name.includes('cctv') || name.includes('CCTV'))
                .slice(0, 15);
            console.log('[EPG] CCTV相关频道映射示例:');
            sampleChannels.forEach(([name, ids]) => {
                console.log(`  ${name} -> ${ids[0]}${ids.length > 1 ? `(+${ids.length-1}备选)` : ''}`);
            });
            // 特别显示cctv5相关的映射
            const cctv5Channels = Object.keys(this.channelMap)
                .filter(name => name.includes('cctv5') || name.includes('cctv5+') || name.includes('cctv5plus'))
                .sort();
            if (cctv5Channels.length > 0) {
                console.log('[EPG] CCTV5相关频道映射:');
                cctv5Channels.forEach(name => {
                    const ids = this.channelMap[name];
                    console.log(`  ${name} -> ${ids[0]}`);
                });
            }
            // 触发加载完成回调
            this.notifyLoadingComplete();
            // 启动自动刷新
            if (autoRefresh && refreshInterval > 0) {
                this.startAutoRefresh(refreshInterval);
            }
            // 显示成功通知
            showNotification(`节目指南加载完成 (${validPrograms}个节目)`, 3000);
            return {
                success: true,
                channels: Object.keys(this.channelMap).length,
                programs: validPrograms,
                skipped: skippedPrograms,
                stats: channelStats
            };
        } catch (error) {
            console.error('[EPG] 加载失败:', error);
            this.isLoaded = false;
            // 提供更友好的错误信息
            let errorMsg = error.message;
            if (error.message.includes('不支持压缩格式解压')) {
                errorMsg = '浏览器不支持 .gz 文件解压。请使用Chrome 80+、Firefox 113+、Edge 80+或Safari 16.4+版本，或者使用未压缩的EPG文件。';
            } else if (error.message.includes('无法解压EPG数据')) {
                errorMsg = 'EPG文件解压失败。可能文件已损坏或不是有效的压缩文件。';
            }
            // 显示错误通知
            showNotification(`节目指南加载失败: ${errorMsg}`, 5000);
            return {
                success: false,
                error: error.message,
                friendlyError: errorMsg
            };
        }
    }
    /**
     * 根据频道名称获取节目列表（修复模糊匹配问题）
     * @param {string} channelName - 频道名称（通常来自tvg-name）
     * @param {Object} options - 查询选项
     * @returns {Array} 节目列表
     */
    getProgrammes(channelName, options = {}) {
        const {
            maxResults = 10,
            includeCurrent = true,
            includePast = false,
            cacheDuration = 300000
        } = options;
        // 检查EPG是否已加载
        if (!this.isLoaded) {
            console.warn(`[EPG] EPG数据未加载，无法查询: ${channelName}`);
            return [];
        }
        // 生成缓存键
        const cacheKey = `epg_${this.cleanName(channelName)}_${options.cacheKey || ''}`;
        const now = Date.now();
        // 检查缓存
        if (this.epgCache[cacheKey] && 
            (now - this.epgCache[cacheKey].timestamp < cacheDuration)) {
            return this.epgCache[cacheKey].data;
        }
        const cleanedName = this.cleanName(channelName);
        if (!cleanedName) {
            console.warn(`[EPG] 频道名称无效: ${channelName}`);
            return [];
        }
        // console.log(`[EPG] 查询频道: "${channelName}" -> 清洗后: "${cleanedName}"`);
        // 查找频道ID（精确匹配）
        const channelIds = this.channelMap[cleanedName];
        if (channelIds && channelIds.length > 0) {
            // console.log(`[EPG] 找到精确匹配: ${cleanedName} -> ${channelIds[0]}`);
            const result = this.getProgrammesByChannelId(channelIds[0], options);
            // 缓存结果
            this.epgCache[cacheKey] = {
                timestamp: now,
                data: result
            };
            return result;
        }
        // 尝试安全模糊匹配（修复CCTV10科教频道匹配到CCTV1的问题）
        const matchedKey = this.findSafeChannelMatch(cleanedName);
        if (matchedKey) {
            console.log(`[EPG] 使用安全模糊匹配: ${cleanedName} -> ${matchedKey}`);
            const result = this.getProgrammesByChannelId(this.channelMap[matchedKey][0], options);
            // 缓存结果
            this.epgCache[cacheKey] = {
                timestamp: now,
                data: result
            };
            return result;
        }
        //console.warn(`[EPG] 未找到频道 [${channelName}] 的EPG数据 (清洗后: ${cleanedName})`);
        return [];
    }
    /**
     * 安全频道匹配（避免cctv10匹配到cctv1）
     * @private
     */
    findSafeChannelMatch(cleanedName) {
        const candidateKeys = Object.keys(this.channelMap);
        // 策略1：尝试部分匹配，但要求匹配度足够高
        let bestMatch = null;
        let bestScore = 0;
        for (const key of candidateKeys) {
            let score = 0;
            // 完全匹配（最高分）
            if (key === cleanedName) {
                return key; // 立即返回
            }
            // 数字频道匹配（CCTV10, CCTV1等）
            const cleanedNumberMatch = cleanedName.match(/(cctv|channel|tv)(\d+)/);
            const keyNumberMatch = key.match(/(cctv|channel|tv)(\d+)/);
            if (cleanedNumberMatch && keyNumberMatch) {
                // 如果都是数字频道
                const cleanedPrefix = cleanedNumberMatch[1];
                const cleanedNumber = cleanedNumberMatch[2];
                const keyPrefix = keyNumberMatch[1];
                const keyNumber = keyNumberMatch[2];
                // 数字相同的情况下
                if (cleanedNumber === keyNumber) {
                    // 前缀相同：高分数
                    if (cleanedPrefix === keyPrefix) {
                        score = 90;
                    } 
                    // 前缀相似（如cctv和tv）：中分数
                    else if (cleanedPrefix.includes(keyPrefix) || keyPrefix.includes(cleanedPrefix)) {
                        score = 70;
                    }
                    // 数字相同但前缀不同：低分数
                    else {
                        score = 50;
                    }
                }
                // 数字不同：避免匹配（如CCTV10不匹配CCTV1）
                else {
                    continue; // 跳过这个匹配
                }
            }
            // 非数字频道的包含匹配
            if (cleanedName.includes(key) || key.includes(cleanedName)) {
                // 计算匹配长度比例
                const longerLength = Math.max(cleanedName.length, key.length);
                const shorterLength = Math.min(cleanedName.length, key.length);
                const lengthRatio = shorterLength / longerLength;
                // 要求匹配度足够高（至少70%）
                if (lengthRatio >= 0.7) {
                    // 基础分数 + 长度比例加成
                    const baseScore = Math.max(score, 60);
                    score = baseScore + (lengthRatio * 20);
                }
            }
            // 更新最佳匹配
            if (score > bestScore) {
                bestScore = score;
                bestMatch = key;
            }
        }
        // 只有分数足够高才返回匹配
        return bestScore >= 70 ? bestMatch : null;
    }
    /**
     * 根据频道ID获取节目列表
     * @private
     */
    getProgrammesByChannelId(channelId, options) {
        const programmes = this.epgData[channelId];
        if (!programmes || programmes.length === 0) {
            return [];
        }
        const now = new Date();
        let filtered = programmes;
        // 过滤已结束的节目
        if (!options.includePast) {
            filtered = filtered.filter(p => p.stop > now);
        }
        // 查找当前正在播放的节目
        const currentProgramme = filtered.find(p => 
            p.start <= now && p.stop > now
        );
        // 如果只需要当前节目
        if (options.currentOnly && currentProgramme) {
            return [currentProgramme];
        }
        // 排序并限制数量
        filtered.sort((a, b) => a.start - b.start);
        if (filtered.length > options.maxResults) {
            filtered = filtered.slice(0, options.maxResults);
        }
        // 标记当前节目
        if (currentProgramme) {
            filtered.forEach(p => {
                p.isCurrent = (p === currentProgramme);
                p.isNext = false;
            });
            // 标记下一个节目
            const nextIndex = filtered.indexOf(currentProgramme) + 1;
            if (nextIndex < filtered.length) {
                filtered[nextIndex].isNext = true;
            }
        }
        return filtered;
    }
    /**
     * 获取当前正在播放的节目
     * @param {string} channelName - 频道名称
     * @returns {Object|null} 当前节目信息
     */
    getCurrentProgramme(channelName) {
        const programmes = this.getProgrammes(channelName, { 
            maxResults: 1, 
            includePast: true 
        });
        if (programmes.length > 0) {
            const now = new Date();
            return programmes.find(p => p.start <= now && p.stop > now) || null;
        }
        return null;
    }
    /**
     * 获取下一个节目
     * @param {string} channelName - 频道名称
     * @returns {Object|null} 下一个节目信息
     */
    getNextProgramme(channelName) {
        const programmes = this.getProgrammes(channelName, { 
            maxResults: 5, 
            includePast: true 
        });
        if (programmes.length > 0) {
            const now = new Date();
            const futureProgrammes = programmes.filter(p => p.start > now);
            return futureProgrammes.length > 0 ? futureProgrammes[0] : null;
        }
        return null;
    }
    /**
     * 获取当前时段及后续几个时段的节目预告
     * @param {string} channelName - 频道名称
     * @param {Object} options - 配置选项
     * @returns {Object} 节目预告信息
     */
    getProgrammeSchedule(channelName, options = {}) {
        const defaultOptions = {
            currentWindow: 30,      // 当前时段窗口（分钟），默认30分钟
            futureSlots: 4,         // 后续时段数量
            slotDuration: 120,      // 每个时段时长（分钟），默认2小时
            includeCurrent: true,   // 是否包含当前正在播放的节目
            maxProgrammes: 50       // 最大查询节目数
        };
        const config = { ...defaultOptions, ...options };
        const now = new Date();
        // 1. 获取当前频道所有相关节目
        const allProgrammes = this.getProgrammes(channelName, {
            maxResults: config.maxProgrammes,
            includePast: true
        });
        if (allProgrammes.length === 0) {
            return {
                channel: channelName,
                currentSlot: null,
                futureSlots: [],
                timeWindows: []
            };
        }
        // 2. 计算时间窗口
        const timeWindows = [];
        // 当前时段窗口
        const currentWindowEnd = new Date(now.getTime() + config.currentWindow * 60000);
        timeWindows.push({
            type: 'current',
            start: now,
            end: currentWindowEnd,
            programmes: []
        });
        // 未来时段窗口
        for (let i = 0; i < config.futureSlots; i++) {
            const start = i === 0 ? currentWindowEnd : timeWindows[i].end;
            const end = new Date(start.getTime() + config.slotDuration * 60000);
            timeWindows.push({
                type: 'future',
                index: i,
                start: start,
                end: end,
                programmes: []
            });
        }
        // 3. 将节目分配到对应的时间窗口
        allProgrammes.forEach(programme => {
            for (const window of timeWindows) {
                // 节目与时间窗口有重叠
                if (programme.start < window.end && programme.stop > window.start) {
                    // 计算节目在窗口中的时间段
                    const segmentStart = programme.start < window.start ? window.start : programme.start;
                    const segmentEnd = programme.stop > window.end ? window.end : programme.stop;
                    const segment = {
                        ...programme,
                        segmentStart: segmentStart,
                        segmentEnd: segmentEnd,
                        segmentDuration: (segmentEnd - segmentStart) / 60000, // 分钟
                        windowCoverage: (segmentEnd - segmentStart) / (window.end - window.start) * 100 // 覆盖率百分比
                    };
                    window.programmes.push(segment);
                    // 如果一个节目跨多个窗口，继续处理剩余部分
                    if (programme.stop > window.end) {
                        // 这里简化处理，实际可能需要递归处理跨窗口节目
                        break;
                    }
                }
            }
        });
        // 4. 整理返回结果
        const currentSlot = timeWindows[0];
        const futureSlots = timeWindows.slice(1);
        // 查找当前正在播放的节目
        let currentPlaying = null;
        for (const programme of allProgrammes) {
            if (programme.start <= now && programme.stop > now) {
                currentPlaying = programme;
                break;
            }
        }
        return {
            channel: channelName,
            currentTime: now,
            currentPlaying: currentPlaying,
            currentSlot: {
                ...currentSlot,
                programmes: this._mergeAdjacentProgrammes(currentSlot.programmes)
            },
            futureSlots: futureSlots.map(slot => ({
                ...slot,
                programmes: this._mergeAdjacentProgrammes(slot.programmes)
            })),
            allWindows: timeWindows
        };
    }
    /**
     * 合并相邻的同一节目片段（辅助方法）
     * @private
     */
    _mergeAdjacentProgrammes(programmes) {
        if (programmes.length === 0) return [];
        const merged = [];
        let current = { ...programmes[0] };
        for (let i = 1; i < programmes.length; i++) {
            const next = programmes[i];
            // 如果是同一个节目且时间连续
            if (current.title === next.title && 
                Math.abs(current.segmentEnd - next.segmentStart) < 60000) { // 1分钟内
                // 合并时间段
                current.segmentEnd = next.segmentEnd;
                current.segmentDuration = (current.segmentEnd - current.segmentStart) / 60000;
            } else {
                merged.push(current);
                current = { ...next };
            }
        }
        merged.push(current);
        return merged;
    }
    /**
     * 获取简化的节目预告（更适合界面显示）
     * @param {string} channelName - 频道名称
     * @param {Object} options - 配置选项
     * @returns {Array} 简化的节目列表
     */
    getSimplifiedSchedule(channelName, options = {}) {
        const defaultOptions = {
            hours: 6,           // 显示多少小时的节目
            maxItems: 8,        // 最多显示多少个节目
            groupByHour: true   // 是否按小时分组
        };
        const config = { ...defaultOptions, ...options };
        const now = new Date();
        const endTime = new Date(now.getTime() + config.hours * 3600000);
        // 获取节目
        const programmes = this.getProgrammes(channelName, {
            maxResults: config.maxItems * 2, // 多取一些用于过滤
            includePast: false
        });
        // 过滤出时间范围内的节目
        const filtered = programmes.filter(p => p.start < endTime);
        if (!config.groupByHour) {
            return filtered.slice(0, config.maxItems);
        }
        // 按小时分组
        const hourlyGroups = {};
        filtered.forEach(programme => {
            const hour = programme.start.getHours();
            if (!hourlyGroups[hour]) {
                hourlyGroups[hour] = [];
            }
            hourlyGroups[hour].push(programme);
        });
        // 转换为数组并限制数量
        return Object.entries(hourlyGroups)
            .sort(([hourA], [hourB]) => hourA - hourB)
            .slice(0, config.maxItems / 2) // 每组显示2个节目
            .flatMap(([hour, programmes]) => 
                programmes.slice(0, 2).map(p => ({
                    ...p,
                    hourLabel: `${hour}:00`
                }))
            )
            .slice(0, config.maxItems);
    }
    /**
     * 获取当前节目的下一时段节目
     * @param {string} channelName - 频道名称
     * @param {number} count - 获取数量
     * @returns {Array} 下一时段节目列表
     */
    getNextTimeSlotProgrammes(channelName, count = 3) {
        const now = new Date();
        const current = this.getCurrentProgramme(channelName);
        if (!current) {
            // 如果没有当前节目，获取即将开始的节目
            return this.getProgrammes(channelName, {
                maxResults: count,
                includePast: false
            });
        }
        // 获取当前节目结束后的节目
        const allProgrammes = this.getProgrammes(channelName, {
            maxResults: 20,
            includePast: true
        });
        return allProgrammes
            .filter(p => p.start >= current.stop) // 在当前节目结束后开始
            .sort((a, b) => a.start - b.start)
            .slice(0, count);
    }
    /**
     * 获取频道今日节目表
     * @param {string} channelName - 频道名称
     * @returns {Array} 今日节目列表
     */
    getTodaySchedule(channelName) {
        const programmes = this.getProgrammes(channelName, { 
            maxResults: 100, 
            includePast: true 
        });
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const tomorrow = new Date(today);
        tomorrow.setDate(tomorrow.getDate() + 1);
        return programmes.filter(p => 
            p.start >= today && p.start < tomorrow
        );
    }
    /**
     * 获取今日剩余节目（从当前时间到今晚23:59）
     * @param {string} channelName - 频道名称
     * @returns {Array} 节目列表
     */
    getTodayRemainingProgrammes(channelName) {
        const now = new Date();
        const endOfToday = new Date();
        endOfToday.setHours(23, 59, 59, 999);
        const programmes = this.getProgrammes(channelName, {
            maxResults: 100,
            includePast: false
        });
        // 过滤出今天剩余的节目
        return programmes.filter(p => 
            p.start >= now && 
            p.start <= endOfToday
        );
    }
    /**
     * 验证EPG时间是否正确
     * @param {string} channelName - 频道名称
     */
    validateEPGTime(channelName) {
        if (!this.isLoaded) {
            console.warn('EPG数据未加载');
            return;
        }
        const programmes = this.getProgrammes(channelName, {
            maxResults: 3,
            includePast: true
        });
        const now = new Date();
        console.log('\n=== EPG时间验证 ===');
        console.log('当前时间:', now.toLocaleString('zh-CN'));
        console.log('UTC时间:', now.toISOString());
        programmes.forEach((program, index) => {
            console.log(`\n节目 ${index + 1}: ${program.title}`);
            console.log(`开始时间: ${program.start.toLocaleString('zh-CN')}`);
            console.log(`结束时间: ${program.stop.toLocaleString('zh-CN')}`);
            console.log(`ISO格式: ${program.start.toISOString()}`);
            const status = program.start > now ? '未开始' : 
                          (program.stop > now ? '进行中' : '已结束');
            console.log(`状态: ${status}`);
            // 检查时间是否合理（应该在今天或未来几天内）
            const daysDiff = Math.floor((program.start - now) / (1000 * 60 * 60 * 24));
            console.log(`距现在: ${daysDiff} 天`);
        });
    }
    /**
     * 启动自动刷新
     * @param {number} interval - 刷新间隔(毫秒)
     */
    startAutoRefresh(interval = 3600000) {
        this.stopAutoRefresh();
        console.log(`[EPG] 启动自动刷新，间隔: ${interval/60000}分钟`);
        this.refreshTimer = setInterval(async () => {
            if (this.currentEpgUrl) {
                console.log('[EPG] 自动刷新EPG数据...');
                await this.fetchEPG(this.currentEpgUrl, { autoRefresh: false });
            }
        }, interval);
    }
    /**
     * 停止自动刷新
     */
    stopAutoRefresh() {
        if (this.refreshTimer) {
            clearInterval(this.refreshTimer);
            this.refreshTimer = null;
            console.log('[EPG] 停止自动刷新');
        }
    }
    /**
     * 添加加载完成回调
     * @param {Function} callback - 回调函数
     */
    onLoaded(callback) {
        if (typeof callback === 'function') {
            this.loadingCallbacks.push(callback);
        }
    }
    /**
     * 通知加载完成
     * @private
     */
    notifyLoadingComplete() {
        this.loadingCallbacks.forEach(callback => {
            try {
                callback();
            } catch (error) {
                console.error('[EPG] 加载完成回调执行失败:', error);
            }
        });
    }
    /**
     * 清除所有EPG数据
     */
    clear() {
        this.channelMap = {};
        this.epgData = {};
        this.epgCache = {};
        this.isLoaded = false;
        this.stopAutoRefresh();
        console.log('[EPG] 数据已清除');
    }
    /**
     * 获取统计信息
     * @returns {Object} 统计信息
     */
    getStats() {
        return {
            isLoaded: this.isLoaded,
            channelCount: Object.keys(this.channelMap).length,
            epgCount: Object.keys(this.epgData).length,
            totalProgrammes: Object.values(this.epgData).reduce((sum, arr) => sum + arr.length, 0),
            hasAutoRefresh: !!this.refreshTimer,
            currentEpgUrl: this.currentEpgUrl,
            isGzipSupported: this.isGzipSupported  // 新增：压缩支持状态
        };
    }
}
// 全局辅助函数（如果不存在）
if (typeof showNotification !== 'function') {
    function showNotification(message, duration = 3000) {
        console.log('[通知]', message);
        // 在实际使用中，这里可以调用播放器的通知函数
    }
}
// 使EPGManager在全局可用
window.EPGManager = EPGManager;