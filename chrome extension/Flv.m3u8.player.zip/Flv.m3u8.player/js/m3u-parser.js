// 屏蔽普通日志和信息
console.log = function() {};
console.info = function() {};
class M3UParser {
    constructor() {
        this.playlist = [];
        this.globalEpgUrl = "";
    }
    parse(content) {
        this.playlist = [];
        this.globalEpgUrl = "";
        const lines = content.split(/\r?\n/);
        let currentItem = null;
        for (let i = 0; i < lines.length; i++) {
            const line = lines[i].trim();
            if (!line) continue;
            if (line.startsWith("#EXTM3U")) {
                const epgMatch = line.match(/x-tvg-url="([^"]+)"/);
                if (epgMatch) {
                    this.globalEpgUrl = epgMatch[1].trim();
                }
                continue;
            }
            if (line.startsWith("#EXTINF:")) {
                if (currentItem && currentItem.urls.length > 0) {
                    this.playlist.push(currentItem);
                }
                currentItem = {
                    duration: -1,
                    title: "",
                    tvgName: "",
                    groupTitle: "",
                    tvgLogo: "",
                    urls: []
                };
                const tvgNameMatch = line.match(/tvg-name="([^"]+)"/);
                if (tvgNameMatch) {
                    currentItem.tvgName = tvgNameMatch[1].trim();
                }
                const groupTitleMatch = line.match(/group-title="([^"]+)"/);
                if (groupTitleMatch) {
                    currentItem.groupTitle = groupTitleMatch[1].trim();
                }
                const tvgLogoMatch = line.match(/tvg-logo="([^"]+)"/);
                if (tvgLogoMatch) {
                    currentItem.tvgLogo = tvgLogoMatch[1].trim();
                }
                const durationMatch = line.match(/#EXTINF:(-?\d+(\.\d+)?)/);
                if (durationMatch) {
                    currentItem.duration = parseFloat(durationMatch[1]);
                }
                const lastCommaIndex = line.lastIndexOf(",");
                if (lastCommaIndex !== -1) {
                    currentItem.title = line.substring(lastCommaIndex + 1).trim();
                } else {
                    currentItem.title = `项目 ${this.playlist.length + 1}`;
                }
                if (currentItem.tvgName) {
                    currentItem.title = currentItem.tvgName;
                }
            } else if (!line.startsWith("#") && line) {
                if (!currentItem) {
                    currentItem = {
                        duration: -1,
                        title: `项目 ${this.playlist.length + 1}`,
                        tvgName: "",
                        groupTitle: "",
                        tvgLogo: "",
                        urls: []
                    };
                }
                currentItem.urls.push(line);
            }
        }
        if (currentItem && currentItem.urls.length > 0) {
            this.playlist.push(currentItem);
        }
        return this.playlist;
    }
    async parseFromUrl(url) {
        try {
            const response = await fetch(url);
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const content = await response.text();
            return this.parse(content);
        } catch (error) {
            console.error("解析 M3U 文件失败:", error);
            throw error;
        }
    }
    static resolveUrl(baseUrl, relativeUrl) {
        if (/^(https?:)?\/\//i.test(relativeUrl)) {
            return relativeUrl;
        }
        try {
            return new URL(relativeUrl, baseUrl).href;
        } catch (e) {
            console.error("URL 解析错误:", e);
            return relativeUrl;
        }
    }
}