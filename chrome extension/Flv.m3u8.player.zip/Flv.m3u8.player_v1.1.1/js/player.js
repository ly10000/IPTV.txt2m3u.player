// 屏蔽普通日志和信息
console.log = function() {};
console.info = function() {};
document.addEventListener("DOMContentLoaded", function() {
    // 默认配置（使用毫秒）
    const DEFAULT_CONFIG = {
        LOAD_TIMEOUT_MS: 10000, // 10秒
        STALL_TIMEOUT_MS: 10000, // 10秒
        MAX_RETRY_ROUNDS: 2, // 2轮
        SEARCH_DEBOUNCE_MS: 300, // 300毫秒
        PLAYLIST_REFRESH_INTERVAL: 1000 * 60 * 30, // 30分钟
        AUTO_REFRESH_ENABLED: true, // 启用自动刷新
        BLACKLIST_URL: chrome.runtime.getURL('blacklist.txt'), // 黑名单文件URL
        EPG_ENABLED: false, // 默认关闭EPG
        EPG_URL: '', // 默认EPG URL
        RULES: [], //Headers设置 示例：[{ pattern: '*.abc.com', headers: { Auth: 'xxx', Referer: 'xxx' } },...]
        MARQUEE_SPEED: 100, // 跑马灯速度 (像素/秒)
        MARQUEE_COLOR: '#ffd700', // 跑马灯字体颜色
        MARQUEE_FONT_SIZE: '18' // 跑马灯字体大小(px)
    };
    // 实际使用的配置（会被用户设置覆盖）
    const CONFIG = { ...DEFAULT_CONFIG };
    const MIN_EPG_REFRESH_INTERVAL = 10 * 60 * 1000; // 最小EPG刷新间隔: 10分钟
    const state = {
        player: null,
        isPlaying: false,
        videoUrl: "",
        baseUrl: "",
        currentPlaylist: [],
        originalPlaylistUrl: "",
        currentPlaylistIndex: -1,
        isM3UPlaylist: false,
        streamInfo: {
            resolution: "未知",
            type: "未知",
            codec: "未知",
            bitrate: "未知",
            bandwidthEstimate: 0
        },
        loadRequestId: 0,
        timers: {
            load: null,
            stall: null,
            controls: null,
            hidePlaylist: null,
            searchDebounce: null,
            refreshPlaylist: null,
            epgRefresh: null // 新增: EPG刷新定时器
        },
        currentChannelInfo: {
            title: "",
            originalIndex: -1,
            urls: []
        },
        blacklist: [], // 黑名单关键词数组
        isBlacklistLoaded: false, // 黑名单是否已加载
        epgData: {}, // EPG数据: {channelId: [{start, stop, title}]}
        channelMap: {}, // name.lower -> id
        epgExpiryTime: 0, // EPG到期时间戳
        lastEpgRefreshTime: 0, // 上次EPG刷新时间戳
        isMarqueeActive: false, // 新增: 跑马灯是否活跃标志
        isLoudnessEnabled: false, // 新增: 响度均衡是否开启
        audioContext: null, // 新增: Web Audio Context
        sourceNode: null, // 新增: Audio Source Node
        dynamicsCompressor: null // 新增: 动态压缩器节点
    };
    const UI = {
        videoPlayer: document.getElementById("videoPlayer"),
        videoInfo: document.getElementById("videoInfo"),
        videoContainer: document.querySelector(".video-container"),
        controls: document.getElementById("controls"),
        playPauseBtn: document.getElementById("playPauseBtn"),
        backBtn: document.getElementById("backBtn"),
        prevChannelBtn: document.getElementById("prevChannelBtn"),
        nextChannelBtn: document.getElementById("nextChannelBtn"),
        volumeBtn: document.getElementById("volumeBtn"),
        fullscreenBtn: document.getElementById("fullscreenBtn"),
        playlistBtn: document.getElementById("playlistBtn"),
        closePlaylistBtn: document.getElementById("closePlaylistBtn"),
        clearSearchBtn: document.getElementById("clearSearchBtn"),
        infoBtn: null,
        progress: document.getElementById("progress"),
        progressBar: document.getElementById("progressBar"),
        timeDisplay: document.getElementById("time"),
        volumeSlider: document.getElementById("volumeSlider"),
        volumeProgress: document.getElementById("volumeProgress"),
        volumeContainer: document.querySelector(".volume-container"),
        playlistContainer: document.getElementById("playlist-container"),
        playlistItems: document.getElementById("playlist-items"),
        playlistSearchInput: document.getElementById("playlist-search-input"),
        loading: document.getElementById("loading"),
        errorMessage: document.getElementById("errorMessage"),
        infoPanel: null,
        switchSourceBtn: null,
        epgBtn: null,
        // 新增：进阶设置相关
        advancedBtn: null,
        advancedPanel: null,
        loudnessBtn: null
    };
    let epgPopup = null;
    // ==================== 新增：键盘事件处理函数 ====================
    function handleKeyDown(e) {
        // 如果频道列表可见，优先处理频道列表相关快捷键
        if (!UI.playlistContainer.classList.contains("hidden")) {
            // ESC键：关闭频道列表
            if (e.code === 'Escape' || e.key === 'Escape' || e.keyCode === 27) {
                e.preventDefault();
                closePlaylist();
                return;
            }
            // 回车键：播放当前选中的项目
            if ((e.code === 'Enter' || e.key === 'Enter' || e.keyCode === 13)) {
                e.preventDefault();
                playSelectedSearchResult();
                // 不移除焦点，保持频道列表控制状态
                return;
            }
            // 上下箭头：在搜索结果中导航
            if (e.code === 'ArrowUp' || e.code === 'ArrowDown') {
                e.preventDefault();
                hideEpgPopup(); // 隐藏旧的
                navigateSearchResults(e.code === 'ArrowUp' ? -1 : 1);
                const selected = UI.playlistItems.querySelector('.selected');
                if (selected) {
                    const index = parseInt(selected.dataset.index);
                    const item = state.currentPlaylist[index];
                    showEpgPopup(selected, item);
                }
                return;
            }
            // 搜索框特殊处理
            if (e.target === UI.playlistSearchInput) {
                // 允许在搜索框中正常输入
                return;
            }
            // 其他按键在频道列表可见时不处理全局快捷键
            // 防止上下箭头变成音量调节
            if (e.code === 'ArrowUp' || e.code === 'ArrowDown') {
                e.preventDefault();
                return;
            }
            // 左右箭头：在频道列表打开时不处理，保持静默
            if (e.code === 'ArrowLeft' || e.code === 'ArrowRight') {
                e.preventDefault();
                return;
            }
        }
        // 全局快捷键处理（仅当频道列表不可见时）
        // / 键：调出频道列表并定位搜索框
        if (e.key === '/' || e.code === 'Slash') {
            e.preventDefault(); // 防止浏览器搜索功能
            focusPlaylistSearch();
            showKeyFeedback('搜索频道列表');
        }
        // 空格键：播放/暂停
        else if (e.code === 'Space' || e.key === ' ' || e.keyCode === 32) {
            e.preventDefault(); // 防止空格键滚动页面
            togglePlayPause();
            // 显示控制栏反馈
            showControls();
            // 短暂显示一个视觉反馈
            showKeyFeedback('空格键: ' + (UI.videoPlayer.paused ? '播放' : '暂停'));
        }
        // 上箭头键：增加音量（仅当频道列表不可见时）
        else if (e.code === 'ArrowUp') {
            e.preventDefault();
            const result = adjustVolumeByArrow(0.05); // 每次增加5%
            if (result.changed) {
                showKeyFeedback(`音量: ${result.newVolume}%`);
                showControls();
            } else {
                showKeyFeedback(`音量已达最大值: 100%`);
            }
        }
        // 下箭头键：减少音量（仅当频道列表不可见时）
        else if (e.code === 'ArrowDown') {
            e.preventDefault();
            const result = adjustVolumeByArrow(-0.05); // 每次减少5%
            if (result.changed) {
                showKeyFeedback(`音量: ${result.newVolume}%`);
                showControls();
            } else {
                showKeyFeedback(`音量已达最小值: 0%`);
            }
        }
        // 左箭头键：快退5秒（仅当频道列表不可见时）
        else if (e.code === 'ArrowLeft') {
            e.preventDefault();
            if (UI.videoPlayer.duration && !isNaN(UI.videoPlayer.duration)) {
                UI.videoPlayer.currentTime = Math.max(0, UI.videoPlayer.currentTime - 5);
                showKeyFeedback('快退: 5秒');
                showControls();
            }
        }
        // 右箭头键：快进5秒（仅当频道列表不可见时）
        else if (e.code === 'ArrowRight') {
            e.preventDefault();
            if (UI.videoPlayer.duration && !isNaN(UI.videoPlayer.duration)) {
                UI.videoPlayer.currentTime = Math.min(UI.videoPlayer.duration, UI.videoPlayer.currentTime + 5);
                showKeyFeedback('快进: 5秒');
                showControls();
            }
        }
        // F键：全屏切换
        else if (e.code === 'KeyF' || e.key === 'f') {
            e.preventDefault();
            toggleFullscreen();
            showKeyFeedback('全屏切换');
            showControls();
        }
        // M键：静音切换
        else if (e.code === 'KeyM' || e.key === 'm') {
            e.preventDefault();
            toggleMute();
            showKeyFeedback('静音: ' + (UI.videoPlayer.muted ? '关闭' : '开启'));
            showControls();
        }
        // P键：频道列表切换
        else if (e.code === 'KeyP' || e.key === 'p') {
            e.preventDefault();
            togglePlaylistUI();
            showKeyFeedback('频道列表');
            showControls();
        }
        // 左方括号键：上一个频道
        else if (e.code === 'BracketLeft' || e.key === '[') {
            e.preventDefault();
            switchToPrevChannel();
            //showKeyFeedback('上一个频道');
            showControls();
        }
        // 右方括号键：下一个频道
        else if (e.code === 'BracketRight' || e.key === ']') {
            e.preventDefault();
            switchToNextChannel();
            //showKeyFeedback('下一个频道');
            showControls();
        }
        // S键：手动换源
        else if (e.code === 'KeyS' || e.key === 's') {
            e.preventDefault();
            manualSwitchToNextSource();
            showKeyFeedback('手动换源');
            showControls();
        }
        // I键：显示/隐藏信息面板
        else if (e.code === 'KeyI' || e.key === 'i') {
            e.preventDefault();
            toggleVideoInfo();
            showKeyFeedback('信息面板');
            showControls();
        }
        // E键：显示EPG跑马灯
        else if (e.code === 'KeyE' || e.key === 'e') {
            e.preventDefault();
            showEpgMarquee();
            showKeyFeedback('节目信息');
            showControls();
        }
        // L键：响度均衡切换
        else if (e.code === 'KeyL' || e.key === 'l') {
            e.preventDefault();
            toggleLoudnessEqualizer();
            showKeyFeedback('响度均衡: ' + (state.isLoudnessEnabled ? '开启' : '关闭'));
            showControls();
        }
    }
    // 新增：关闭频道列表
    function closePlaylist() {
        // 直接关闭频道列表，不通过 togglePlaylistUI 递归
        UI.playlistContainer.classList.add("hidden");
        UI.playlistSearchInput.blur();
        UI.playlistSearchInput.style.border = "";
        UI.playlistSearchInput.style.boxShadow = "";
        // 清除选中项
        const selectedItem = UI.playlistItems.querySelector('.selected');
        if (selectedItem) {
            selectedItem.classList.remove('selected');
        }
        hideEpgPopup(); // 关闭EPG弹出框
        showKeyFeedback('关闭列表');
        showControls();
    }
    // 新增：在搜索结果中导航
    function navigateSearchResults(direction) {
        const searchTerm = UI.playlistSearchInput.value;
        const filteredItems = Array.from(UI.playlistItems.children)
            .filter(item => item.style.display !== 'none');
        if (filteredItems.length === 0) return;
        // 查找当前选中的项目
        let currentIndex = -1;
        for (let i = 0; i < filteredItems.length; i++) {
            if (filteredItems[i].classList.contains('selected')) {
                currentIndex = i;
                break;
            }
        }
        // 计算新的选中索引
        let newIndex;
        if (currentIndex === -1) {
            // 没有选中项，选择第一个或最后一个
            newIndex = direction > 0 ? 0 : filteredItems.length - 1;
        } else {
            newIndex = currentIndex + direction;
            if (newIndex < 0) newIndex = filteredItems.length - 1;
            if (newIndex >= filteredItems.length) newIndex = 0;
        }
        // 移除旧的选中样式
        filteredItems.forEach(item => item.classList.remove('selected'));
        // 添加新的选中样式
        filteredItems[newIndex].classList.add('selected');
        // 滚动到选中项
        filteredItems[newIndex].scrollIntoView({
            behavior: 'smooth',
            block: 'nearest'
        });
        // 显示反馈
        const itemText = filteredItems[newIndex].textContent;
        showKeyFeedback(`选中: ${itemText}`);
        // 确保焦点不在搜索框时，频道列表仍然保持键盘控制
        maintainPlaylistFocus();
    }
    // 新增：保持频道列表焦点状态
    function maintainPlaylistFocus() {
        // 如果频道列表可见但焦点不在任何可输入元素上，给频道列表一个虚拟焦点
        if (!UI.playlistContainer.classList.contains("hidden") &&
            document.activeElement !== UI.playlistSearchInput &&
            !document.activeElement.classList.contains('playlist-item')) {
            // 可以给频道列表容器添加一个焦点状态样式
            UI.playlistContainer.classList.add('has-focus');
            // 或者给选中的频道列表项添加焦点
            const selectedItem = UI.playlistItems.querySelector('.selected');
            if (selectedItem) {
                selectedItem.focus();
            }
        }
    }
    // 新增：播放选中的搜索结果
    function playSelectedSearchResult() {
        const selectedItem = UI.playlistItems.querySelector('.selected');
        if (selectedItem) {
            const index = parseInt(selectedItem.dataset.index);
            if (!isNaN(index)) {
                // 播放选中的项目
                playPlaylistItem(index);
                // 播放后保持选中状态，以便继续使用上下箭头导航
                setTimeout(() => {
                    maintainPlaylistFocus();
                }, 100);
            }
        } else {
            // 如果没有选中项，提示用户
            showKeyFeedback('请先用上下箭头选择一个频道');
        }
    }
    // 新增：聚焦到频道列表搜索框
    function focusPlaylistSearch() {
        // 首先确保频道列表是可见的
        if (UI.playlistContainer.classList.contains("hidden")) {
            togglePlaylistUI(true);
        }
        // 等待一小段时间确保DOM已更新
        setTimeout(() => {
            // 聚焦到搜索框
            UI.playlistSearchInput.focus();
            // 选中所有文本以便直接输入
            UI.playlistSearchInput.select();
            // 添加一个聚焦样式
            UI.playlistSearchInput.style.border = "2px solid #4dabf7";
            UI.playlistSearchInput.style.boxShadow = "0 0 0 3px rgba(77, 171, 247, 0.3)";
            // 显示搜索框位置提示
            //highlightSearchBox();
            // 清除任何现有的选中项
            const selectedItem = UI.playlistItems.querySelector('.selected');
            if (selectedItem) {
                selectedItem.classList.remove('selected');
            }
        }, 50);
    }
    // 新增：高亮显示搜索框
    function highlightSearchBox() {
        // 移除现有的高亮元素
        const existingHighlight = document.querySelector('.search-highlight');
        if (existingHighlight) {
            existingHighlight.remove();
        }
        // 创建高亮元素
        const highlight = document.createElement('div');
        highlight.className = 'search-highlight';
        highlight.innerHTML = '✨ 搜索框已激活，输入关键词搜索频道';
        // 定位在搜索框旁边
        const rect = UI.playlistSearchInput.getBoundingClientRect();
        highlight.style.cssText = `
            position: fixed;
            top: ${rect.top - 40}px;
            left: ${rect.left}px;
            background: linear-gradient(135deg, #4dabf7, #339af0);
            color: white;
            padding: 8px 16px;
            border-radius: 6px;
            font-size: 13px;
            font-weight: bold;
            z-index: 2000;
            pointer-events: none;
            opacity: 1;
            transition: opacity 0.3s ease;
            box-shadow: 0 4px 12px rgba(77, 171, 247, 0.4);
        `;
        // 添加一个箭头指向搜索框
        highlight.innerHTML += `
            <div style="position: absolute; bottom: -8px; left: 20px; width: 0; height: 0; border-left: 8px solid transparent; border-right: 8px solid transparent; border-top: 8px solid #339af0;"></div>
        `;
        document.body.appendChild(highlight);
        // 2秒后淡出并移除
        setTimeout(() => {
            highlight.style.opacity = '0';
            setTimeout(() => {
                if (highlight.parentNode) {
                    highlight.parentNode.removeChild(highlight);
                }
            }, 300);
        }, 2000);
    }
    // 修改：使用箭头键调整音量，返回调整结果
    function adjustVolumeByArrow(delta) {
        const oldVolume = UI.videoPlayer.volume;
        let newVolume = oldVolume + delta;
        // 限制在0-1之间
        newVolume = Math.max(0, Math.min(1, newVolume));
        // 检查是否实际发生了变化
        const changed = Math.abs(newVolume - oldVolume) > 0.001;
        if (changed) {
            UI.videoPlayer.volume = newVolume;
            UI.videoPlayer.muted = (newVolume === 0); // 如果音量为0，则静音
            // 更新音量条
            UI.volumeProgress.style.width = newVolume * 100 + "%";
            updateVolumeIcon();
            // 保存音量设置
            chrome.storage.local.set({
                volume: newVolume
            });
        }
        // 返回调整结果
        return {
            changed: changed,
            oldVolume: oldVolume * 100,
            newVolume: Math.round(newVolume * 100)
        };
    }
    // 新增：键盘操作视觉反馈
    function showKeyFeedback(message) {
        const existingFeedback = document.querySelector('.key-feedback');
        if (existingFeedback) {
            // 优化：如果已存在，直接更新文字并重置计时器，避免 DOM 频繁重建的开销
            existingFeedback.textContent = message;
            // 清除旧的定时器（需要将 timerId 挂载到元素上或外部变量）
            clearTimeout(existingFeedback.timer);
            clearTimeout(existingFeedback.removeTimer);
            // 重置透明度
            existingFeedback.style.opacity = '1';
            setupCleanup(existingFeedback);
            return;
        }
    
        const feedback = document.createElement('div');
        feedback.className = 'key-feedback';
        feedback.textContent = message;
        feedback.style.cssText = `
            position: fixed;
            bottom: 100px;
            left: 50%;
            transform: translateX(-50%);
            background: rgba(0, 100, 200, 0.9);
            color: white;
            padding: 10px 20px;
            border-radius: 25px;
            font-size: 14px;
            font-weight: bold;
            z-index: 1001;
            pointer-events: none;
            opacity: 1;
            box-shadow: 0 4px 12px rgba(0, 100, 200, 0.3);
            min-width: 120px;
            text-align: center;
            transition: opacity 0.3s ease; /* 预设过渡 */
        `;
        document.body.appendChild(feedback);
        setupCleanup(feedback);
    
        function setupCleanup(el) {
            el.timer = setTimeout(() => {
                el.style.opacity = '0';
                el.removeTimer = setTimeout(() => {
                    if (el.parentNode) el.parentNode.removeChild(el);
                }, 300);
            }, 1000);
        }
    }
    // ==================== 键盘事件处理结束 ====================
    // 新增：加载EPG数据
    async function loadEPG() {
        if (!CONFIG.EPG_ENABLED) return;
        try {
            state.lastEpgRefreshTime = Date.now(); // 更新上次刷新时间
            console.log('[EPG] 开始加载:', CONFIG.EPG_URL);
            const response = await fetch(CONFIG.EPG_URL);
            if (!response.ok) {
                throw new Error(`HTTP ${response.status} - ${response.statusText}`);
            }
            let text;
            // 判断是否需要解压（根据 Content-Type 或文件后缀）
            const contentType = response.headers.get('content-type') || '';
            const isGzipped = 
                contentType.includes('gzip') || 
                contentType.includes('application/gzip') ||
                CONFIG.EPG_URL.toLowerCase().endsWith('.gz');
            if (isGzipped && 'DecompressionStream' in window) {
                console.log('[EPG] 检测到 gzip 压缩，使用 DecompressionStream 解压');
                const buffer = await response.arrayBuffer();
                const decompressedStream = new Response(
                    new Blob([buffer]).stream().pipeThrough(
                        new DecompressionStream('gzip')
                    )
                );
                text = await decompressedStream.text();
            } else {
                // 普通文本或已自动解压的情况
                text = await response.text();
            }
            const parser = new DOMParser();
            const xml = parser.parseFromString(text, 'text/xml');
            // 检查解析是否成功
            if (xml.getElementsByTagName('parsererror').length > 0) {
                throw new Error('XML 解析失败，可能文件格式错误或未正确解压');
            }
            // ==================== 原有解析逻辑 ====================
            const channels = xml.getElementsByTagName('channel');
            state.channelMap = {}; // name.lower -> id (备用匹配)
            for (let ch of channels) {
                const id = ch.getAttribute('id');
                const displayName = ch.querySelector('display-name')?.textContent?.trim();
                if (displayName && id) {
                    state.channelMap[displayName.toLowerCase()] = id;
                }
            }
            const programmes = xml.getElementsByTagName('programme');
            state.epgData = {};
            for (let prog of programmes) {
                const channelId = prog.getAttribute('channel');
                if (!state.epgData[channelId]) state.epgData[channelId] = [];
                const startStr = prog.getAttribute('start');
                const stopStr = prog.getAttribute('stop');
                const start = parseEpgTime(startStr);
                const stop = parseEpgTime(stopStr);
                const titleElem = prog.querySelector('title');
                const title = titleElem?.textContent?.trim() || '未知节目';
                state.epgData[channelId].push({ start, stop, title });
            }
            // 按开始时间排序
            for (let id in state.epgData) {
                state.epgData[id].sort((a, b) => a.start - b.start);
            }
            console.log(`[EPG] 加载完成，共 ${Object.keys(state.epgData).length} 个频道节目表`);
            // 新增: 计算EPG到期时间（最晚节目结束时间）
            calculateEpgExpiry();
            // 新增: 启动到期前刷新定时器
            scheduleEpgRefresh();
        } catch (err) {
            console.error('[EPG] 加载失败:', err);
            // 可选：提示用户
            // showNotification('EPG数据加载失败，请检查网络或URL', 4000);
        }
    }
    // 新增：计算EPG到期时间
    function calculateEpgExpiry() {
        let maxStop = 0;
        for (let id in state.epgData) {
            const programs = state.epgData[id];
            if (programs.length > 0) {
                const lastStop = programs[programs.length - 1].stop;
                if (lastStop > maxStop) maxStop = lastStop;
            }
        }
        state.epgExpiryTime = maxStop;
        console.log(`[EPG] 计算到期时间: ${new Date(maxStop).toLocaleString()}`);
    }
    // 新增：调度EPG刷新（到期前1小时刷新）
    function scheduleEpgRefresh() {
        // 1. 清理现有定时器，确保不重叠
        if (state.timers.epgRefresh) {
            clearTimeout(state.timers.epgRefresh);
            state.timers.epgRefresh = null;
        }
        // 2. 前置检查
        if (!CONFIG.EPG_ENABLED || state.epgExpiryTime <= 0) return;
        const now = Date.now();
        const timeToExpiry = state.epgExpiryTime - now;
        // 计算触发更新的目标时间点：过期前1小时 (3600000 ms)
        // 如果现在已经进入了过期前1小时，则目标延迟为 0
        const targetTriggerDelay = Math.max(timeToExpiry - 3600000, 0);
        // 设置触发器
        state.timers.epgRefresh = setTimeout(() => {
            const currentTime = Date.now();
            const timeSinceLastRefresh = currentTime - state.lastEpgRefreshTime;
            // 3. 触发时检查：是否满足最小刷新间隔
            if (timeSinceLastRefresh >= MIN_EPG_REFRESH_INTERVAL) {
                console.log('[EPG] 满足刷新条件（进入过期预警期且已过最小间隔），开始更新...');
                loadEPG();
            } else {
                // 4. 不满足间隔：计算还需等待多久并安排补跳
                const remainingWait = MIN_EPG_REFRESH_INTERVAL - timeSinceLastRefresh;
                console.log(`[EPG] 触发太频繁，等待最小间隔：还需 ${Math.round(remainingWait / 1000)} 秒后补刷`);
                // 覆盖当前的 timer，确保最后一次补刷能执行
                state.timers.epgRefresh = setTimeout(() => {
                    console.log('[EPG] 最小间隔已满，执行补刷...');
                    loadEPG();
                }, remainingWait);
            }
        }, targetTriggerDelay);
        if (targetTriggerDelay > 0) {
            console.log(`[EPG] 调度成功：将于 ${Math.round(targetTriggerDelay / 3600000 * 10) / 10} 小时后尝试触发更新`);
        } else {
            console.log('[EPG] 处于过期预警期，尝试立即触发检查');
        }
    }
    // 新增：解析EPG时间字符串到时间戳
    function parseEpgTime(timeStr) {
        if (!timeStr) return 0;
        const year = timeStr.substring(0, 4);
        const month = timeStr.substring(4, 6);
        const day = timeStr.substring(6, 8);
        const hour = timeStr.substring(8, 10);
        const min = timeStr.substring(10, 12);
        const sec = timeStr.substring(12, 14);
        const tz = timeStr.substring(14).trim() || '+0000';
        const dateStr = `${year}-${month}-${day}T${hour}:${min}:${sec}${tz.replace(' ', '')}`;
        const ts = Date.parse(dateStr);
        return isNaN(ts) ? 0 : ts;
    }
    // 新增：格式化时间戳为本地时间字符串
    function formatEpgTime(ts) {
        if (!ts) return '未知';
        const date = new Date(ts);
        return date.toLocaleTimeString('zh-CN', {hour: '2-digit', minute: '2-digit'});
    }
    /**
     * 精准清洗频道名称（修复CCTV10科教频道匹配问题）
     * @param {string} name - 原始频道名称
     * @returns {string} 清洗后的名称
     */
    function cleanName(name) {
        if (!name || typeof name !== 'string') return "";
        let cleaned = name
            .toLowerCase()
            .replace(/\s+/g, "")
            .replace(/[^\w\+\-\u4e00-\u9fa5]/g, "")
            .trim();
        // 统一符号
        cleaned = cleaned.replace(/plus/g, '+');
        console.log(`[EPG调试] 清洗: "${name}" -> "${cleaned}"`);
        // ========== 特殊频道映射表 ==========
        const specialChannels = {
            // 4K/8K超高清频道
            'cctv4k': 'cctv4k',
            'cctv8k': 'cctv8k',
            'cctv4k超高清': 'cctv4k',
            'cctv8k超高清': 'cctv8k',
            'cctv-4k': 'cctv4k',
            'cctv-8k': 'cctv8k',
            // 错误名称修正
            'cctv-': 'cctv',
            'cctv_': 'cctv',
            'cctv ': 'cctv',
            // 其他特殊处理
            'cctv4k+': 'cctv4k+',
            'cctv8k+': 'cctv8k+',
            'cctv5+体育赛事': 'cctv5+',
            'cctv5+': 'cctv5+',
            'cctv4欧洲': 'cctv4欧洲',
            'cctv4美洲': 'cctv4美洲',
			'文化精品':'央视文化精品',
			'cctv文化精品':'央视文化精品'
        };
        // 先检查特殊频道映射
        if (specialChannels[cleaned]) {
            console.log(`[EPG调试] 特殊频道映射: "${cleaned}" -> "${specialChannels[cleaned]}"`);
            return specialChannels[cleaned];
        }
        // ========== 正则匹配 ==========
        // 1. 4K/8K频道（优先于数字频道）
        const hdMatch = cleaned.match(/^(cctv|channel|tv)[\-_]?(4k|8k)(\+)?$/i);
        if (hdMatch) {
            const result = hdMatch[1] + hdMatch[2] + (hdMatch[3] || '');
            console.log(`[EPG调试] 4K/8K频道: "${cleaned}" -> "${result}"`);
            return result;
        }
        // 2. 带+号的数字频道
        const plusMatch = cleaned.match(/^(cctv|channel|tv)[\-_]?(\d+)\+$/i);
        if (plusMatch) {
            const result = plusMatch[1] + plusMatch[2] + '+';
            console.log(`[EPG调试] 带+号频道: "${cleaned}" -> "${result}"`);
            return result;
        }
        // 3. 普通数字频道
        const numberMatch = cleaned.match(/^(cctv|channel|tv)[\-_]?(\d+)/i);
        if (numberMatch) {
            const result = numberMatch[1] + numberMatch[2];
            console.log(`[EPG调试] 数字频道: "${cleaned}" -> "${result}"`);
            return result;
        }
        // 4. CCTV+中文
        if (cleaned.startsWith('cctv')) {
            const withoutCctv = cleaned.substring(4);
            if (withoutCctv && /^[\u4e00-\u9fa5]+$/.test(withoutCctv)) {
                console.log(`[EPG调试] CCTV+中文: "${cleaned}" -> "${withoutCctv}"`);
                return withoutCctv;
            }
        }
        // 5. 后缀处理
        const suffixes = [
            '超高清', '高清', '标清', 'hd', 'sd', 'fhd', 'uhd',
            '台', '频道', 'channel', 'tv'
        ];
        for (const suffix of suffixes) {
            if (cleaned.endsWith(suffix)) {
                const result = cleaned.slice(0, -suffix.length);
                console.log(`[EPG调试] 去除后缀: "${cleaned}" -> "${result}"`);
                // 如果去除后缀后是空字符串，返回原始
                if (!result) {
                    console.log(`[EPG调试] 警告: 去除后缀后为空，返回原始: "${cleaned}"`);
                    return cleaned;
                }
                return result;
            }
        }
        console.log(`[EPG调试] 最终结果: "${cleaned}"`);
        return cleaned;
    }
    // 新增：获取频道ID
    function getChannelId(item) {
        let prechId = item.attributes ? item.attributes['tvg-id'] : '';
        let chId = cleanName(prechId);
        if (!chId) {
            const nameLower = cleanName(item.title || '');
            chId = state.channelMap[nameLower] || nameLower; // 如果没有匹配，用name作为fallback
        }
        return chId;
    }
    // 新增：获取当前节目
    function getCurrentProgram(programs) {
        const now = Date.now();
        return programs.find(p => now >= p.start && now < p.stop) || null;
    }
    // 新增：获取接下来几个节目
    function getNextPrograms(programs, num = 3) {
        const now = Date.now();
        const future = programs.filter(p => p.start > now).sort((a, b) => a.start - b.start);
        return future.slice(0, num);
    }
    // 新增：显示EPG弹出框（智能自适应位置，避免被边缘挡住）
    function showEpgPopup(itemEl, item) {
        if (!CONFIG.EPG_ENABLED) return;
        if (epgPopup) hideEpgPopup();
        const chId = getChannelId(item);
        const programs = state.epgData[chId] || [];
        const current = getCurrentProgram(programs);
        const next = getNextPrograms(programs, 3);
        if (!current && next.length === 0) return;
        epgPopup = document.createElement('div');
        epgPopup.className = 'epg-popup';
        let html = '';
        if (current) {
            html += `<span style="color: #4CAF50; font-weight: bold;">当前:</span> [${formatEpgTime(current.start)} - ${formatEpgTime(current.stop)}] ${current.title}<br>`;
        }
        next.forEach((p, i) => {
            html += `<span style="color: #FFA500; font-weight: bold;">稍后:</span> [${formatEpgTime(p.start)} - ${formatEpgTime(p.stop)}] ${p.title}<br>`;
        });
        epgPopup.innerHTML = html;
        // 先添加到 DOM 以获取尺寸（但先隐藏）
        epgPopup.style.visibility = 'hidden';
        document.body.appendChild(epgPopup);
        // 延迟一帧，确保布局稳定后再计算位置
        requestAnimationFrame(() => {
            const rect = itemEl.getBoundingClientRect();
            const popupRect = epgPopup.getBoundingClientRect();
            const viewportWidth = window.innerWidth;
            const viewportHeight = window.innerHeight;
            const margin = 12; // 更大一点的安全边距
            let left = rect.left - popupRect.width - margin;
            let top = rect.top;
            // 水平：左侧空间不够 → 移到右侧
            if (left < margin) {
                left = rect.right + margin;
                // 右侧也放不下？尽量靠右但不超
                if (left + popupRect.width > viewportWidth - margin) {
                    left = viewportWidth - popupRect.width - margin;
                }
            }
            // 垂直方向智能调整（最关键）
            const spaceBelow = viewportHeight - rect.bottom;     // 下方剩余空间
            const spaceAbove = rect.top;                          // 上方剩余空间
            // 如果下方空间足够放完整弹出框，保持原位置
            if (spaceBelow >= popupRect.height + margin) {
                top = rect.top;
            }
            // 下方不够，但上方空间足够 → 向上贴频道顶部
            else if (spaceAbove >= popupRect.height + margin) {
                top = rect.top - popupRect.height - margin;
            }
            // 上下都不够 → 尽量居中显示在频道附近，并允许滚动
            else {
                // 优先向上对齐频道顶部
                top = rect.top - popupRect.height - margin;
                // 如果还是超上界，强制贴顶
                if (top < margin) {
                    top = margin;
                }
            }
            // 最终边界保护
            top = Math.max(margin, Math.min(top, viewportHeight - popupRect.height - margin));
            // 应用位置并显示
            epgPopup.style.position = 'fixed';
            epgPopup.style.left = `${left}px`;
            epgPopup.style.top = `${top}px`;
            epgPopup.style.visibility = 'visible';
            // 增强样式：限制高度 + 可滚动
            epgPopup.style.maxHeight = `${viewportHeight * 0.75}px`; // 最多占视口 75%
            epgPopup.style.overflowY = 'auto';
            epgPopup.style.maxWidth = '340px';
            epgPopup.style.minWidth = '240px';
            epgPopup.style.background = 'rgba(0,0,0,0.88)';
            epgPopup.style.color = 'white';
            epgPopup.style.padding = '12px';
            epgPopup.style.borderRadius = '8px';
            epgPopup.style.zIndex = '1001';
            epgPopup.style.boxShadow = '0 6px 20px rgba(0,0,0,0.6)';
        });
    }
    // 新增：隐藏EPG弹出框
    function hideEpgPopup() {
        if (epgPopup) {
            epgPopup.remove();
            epgPopup = null;
        }
    }
    // 新增：显示EPG跑马灯
    function showEpgMarquee() {
        if (!CONFIG.EPG_ENABLED || state.currentPlaylistIndex === -1) {
            showNotification('EPG未启用或无当前频道', 'warning',2000);
            return;
        }
        // 防止重复触发
        if (state.isMarqueeActive) {
            showNotification('节目信息已在显示中', 1500);
            return;
        }
        state.isMarqueeActive = true;
        const item = state.currentPlaylist[state.currentPlaylistIndex];
        const chId = getChannelId(item);
        const programs = state.epgData[chId] || [];
        const current = getCurrentProgram(programs);
        const next = getNextPrograms(programs, 2);
        const chName = state.currentChannelInfo?.title || 
                       state.currentPlaylist[state.currentPlaylistIndex]?.title || 
                       "未知频道";
        const currentTime = getCurrentTimeStr('time');               
        // --- 1. 构建富文本内容 ---
        let htmlContent = '';
        const spacing = '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'; 
        if (current) {
            htmlContent += `
                <span style="color: #FFFFFF; font-size: 0.9em;">${currentTime} </span>
                <span style="color: #FFFFFF;">【${chName}】</span>
                <span style="color: #00FF7F;">正在播放:</span> 
                <span style="color: #00FF7F;">《${current.title}》</span> 
                <span style="color: #AAAAAA; font-size: 0.9em;">(${formatEpgTime(current.start)} - ${formatEpgTime(current.stop)})</span>${spacing}`;
        }
        next.forEach((p, i) => {
            let label, labelColor, labelOpacity;
            if (i === 0) {
                label = '下一个';
                labelColor = '#FFD700';
                labelOpacity = '0.9';
            } else {
                label = '稍后';
                labelColor = '#FFA500';
                labelOpacity = '0.8';
            }
            htmlContent += `
                <span style="color: ${labelColor}; opacity: ${labelOpacity};">${label}:</span> 
                <span style="color: ${labelColor}; opacity: ${labelOpacity};">《${p.title}》</span> 
                <span style="color: #AAAAAA; font-size: 0.9em;">(${formatEpgTime(p.start)} - ${formatEpgTime(p.stop)})</span>${spacing}`;
        });
        if (!htmlContent) {
            htmlContent = '<span style="color: #FFFFFF;">当前频道无节目信息</span>';
        }
        // --- 2. 测量文本实际像素宽度 (核心新逻辑) ---
        const measurer = document.createElement('span');
        measurer.style.cssText = `
            position: absolute;
            visibility: hidden;
            white-space: nowrap;
            font-size: ${CONFIG.MARQUEE_FONT_SIZE}px;
            font-weight: 500;
        `;
        measurer.innerHTML = htmlContent;
        document.body.appendChild(measurer);
        const textWidth = measurer.offsetWidth;
        document.body.removeChild(measurer);
        // --- 3. 计算动画时长 (基于恒定像素速度) ---
        const containerWidth = window.innerWidth;
        const totalDistance = containerWidth + textWidth; // 总滑行路程
        // 定义恒定速度：每秒移动多少像素
        // 建议：100 为中速，150 为快速，80 为慢速
        // 如果你想继续用 CONFIG，可以设为 CONFIG.MARQUEE_SPEED || 120
        const pixelsPerSecond = CONFIG.MARQUEE_SPEED || 120; 
        const scrollDuration = totalDistance / pixelsPerSecond;
        // --- 4. 创建跑马灯容器 ---
        const marquee = document.createElement('div');
        marquee.className = 'epg-marquee';
        // 使用 padding 代替固定 height
        // 建议上下 padding 设置为字号的 0.3 到 0.5 倍，视觉上会比较协调
        const verticalPadding = Math.round(CONFIG.MARQUEE_FONT_SIZE * 0.4);        
        marquee.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            /* 删除固定 height: 40px; */
            padding: ${verticalPadding}px 0; 
            background: rgba(20, 20, 20, 0.9);
            z-index: 1000;
            display: flex;
            align-items: center;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.5);
        `;
        const span = document.createElement('span');
        span.innerHTML = htmlContent; 
        span.style.cssText = `
            display: inline-block;
            white-space: nowrap;
            padding-left: 100%;
            will-change: transform;
            font-size: ${CONFIG.MARQUEE_FONT_SIZE}px;
            font-weight: 500;
        `;
        marquee.appendChild(span);
        document.body.appendChild(marquee);
        // 启动动画
        span.style.animation = `marquee ${scrollDuration}s linear forwards`;
        // --- 5. 清理 ---
        setTimeout(() => {
            if (marquee.parentNode) {
                span.style.animation = ''; 
                marquee.parentNode.removeChild(marquee);
            }
            state.isMarqueeActive = false;
        }, (scrollDuration * 1000) + 500);
        showKeyFeedback('节目信息开始滚动');
    }
    /**
     * 获取当前时间/日期字符串
     * @param {string} mode - 模式: 'datetime'(默认), 'date', 'time'
     * @param {string} separator - 日期和时间之间的分隔符，默认为空格
     * @returns {string} 格式化后的字符串
     */
    function getCurrentTimeStr(mode = 'datetime', separator = ' ') {
        const d = new Date();
        // 1. 获取并格式化日期部分 (YYYY-MM-DD)
        const year = d.getFullYear();
        const month = String(d.getMonth() + 1).padStart(2, '0');
        const day = String(d.getDate()).padStart(2, '0');
        const dateStr = `${year}-${month}-${day}`;
        // 2. 获取并格式化时间部分 (HH:mm)
        const hours = String(d.getHours()).padStart(2, '0');
        const minutes = String(d.getMinutes()).padStart(2, '0');
        const timeStr = `${hours}:${minutes}`;
        // 3. 根据模式返回对应格式
        switch (mode) {
            case 'date':
                return dateStr;
            case 'time':
                return timeStr;
            case 'datetime':
            default:
                return `${dateStr}${separator}${timeStr}`;
        }
    }
    function init() {
        addStyles();
        createDynamicUI();
        loadVolumeSettings();
        loadSettings(); // 从 storage 加载用户设置
        loadBlacklist(); // 加载黑名单
        parseInitialUrl();
        initGlobalEvents();
        addButtonHoverEffects();
        if (state.videoUrl) {
            UI.videoInfo.textContent = decodeURIComponent(state.videoUrl);
        }
        if (CONFIG.EPG_ENABLED) {
            loadEPG();
        }
    }
    function addStyles() {
        const style = document.createElement('style');
        style.textContent = `
            .control-btn {
                background: rgba(255,255,255,0.12);
                border: none;
                color: white;
                padding: 6px 10px;
                margin: 0 6px;
                border-radius: 4px;
                cursor: pointer;
                font-size: 15px;
            }
            .control-btn:disabled {
                opacity: 0.4;
                cursor: not-allowed;
            }
            .advanced-panel {
                position: absolute;
                bottom: 60px;
                right: 20px;
                background: rgba(20,20,30,0.95);
                border-radius: 8px;
                padding: 12px 16px;
                min-width: 240px;
                max-width: 320px;
                box-shadow: 0 6px 24px rgba(0,0,0,0.7);
                backdrop-filter: blur(8px);
                border: 1px solid rgba(255,255,255,0.12);
                z-index: 150;
                color: white;
                font-size: 13px;
            }
            /*进阶设置面板限高*/
            .advanced-panel {
                /* 设置最大高度，防止超出容器 */
                max-height: 80%; 
                /* 核心：内容过多时显示垂直滚动条 */
                overflow-y: auto; 
                /* 避免内容紧贴边缘 */
                padding-right: 5px; 
                /* 确保面板在容器内定位正确（如果需要） */
                position: absolute;
                z-index: 100;
            }            
            /* 优化滚动条样式（可选） */
            .advanced-panel::-webkit-scrollbar {
                width: 4px;
            }
            .advanced-panel::-webkit-scrollbar-thumb {
                background: rgba(255, 255, 255, 0.3);
                border-radius: 2px;
            }
            .section {
                margin: 12px 0;
            }
            .section-title {
                color: #4dabf7;
                font-weight: bold;
                margin-bottom: 6px;
                font-size: 14px;
            }
            .option-item {
                padding: 6px 10px;
                cursor: pointer;
                border-radius: 4px;
                margin: 2px 0;
                transition: all 0.15s;
            }
            .option-item:hover {
                background: rgba(77,171,247,0.25);
            }
            .option-item.active {
                background: rgba(77,171,247,0.45);
                font-weight: 500;
            }
            .option-item.disabled {
                color: #777;
                cursor: not-allowed;
                pointer-events: none;
            }
            .switch-source-btn:hover {
                background: rgba(255, 255, 255, 0.2);
                border-radius: 3px;
                transform: scale(1);
                transition: all 0.2s ease;
            }
            .switch-source-btn:active {
                transform: scale(1);
                transition: all 0.1s ease;
            }
            /* info-panel 样式 */
            .info-panel {
                display: none;
                position: absolute;                
                width: fit-content;                
                right: 350px !important;
                left: auto !important; 
                text-align: left;
                bottom: 60px;
                background: rgba(0, 0, 0, 0.85);
                padding: 12px;
                border-radius: 6px;
                font-size: 12px;
                line-height: 1.5;
                z-index: 20;
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.5);
                backdrop-filter: blur(10px);
                border: 1px solid rgba(255, 255, 255, 0.1);
            }
            .info-label {
                color: #4dabf7 !important;
                font-weight: normal;
            }
            .info-maohao {
                color: #20c997 !important;
            }
            .info-value {
                color: white !important;
            }
            .info-line {
                margin-bottom: 3px;
            }
            @keyframes fadeInOut {
                0% { opacity: 0; transform: translate(-50%, -10px); }
                15% { opacity: 1; transform: translate(-50%, 0); }
                85% { opacity: 1; transform: translate(-50%, 0); }
                100% { opacity: 0; transform: translate(-50%, -10px); }
            }
            .blacklist-error {
                background: linear-gradient(135deg, #ff6b6b, #c92a2a) !important;
                border: 2px solid #ff6b6b !important;
                color: white !important;
                font-weight: bold !important;
                padding: 15px !important;
                border-radius: 8px !important;
            }
            /* 新增：键盘反馈动画 */
            @keyframes keyFeedbackFlash {
                0% { transform: translateX(-50%) scale(0.9); opacity: 0; }
                15% { transform: translateX(-50%) scale(1.1); opacity: 1; }
                30% { transform: translateX(-50%) scale(1); opacity: 1; }
                85% { transform: translateX(-50%) scale(1); opacity: 1; }
                100% { transform: translateX(-50%) scale(0.9); opacity: 0; }
            }
            .key-feedback {
                animation: keyFeedbackFlash 1s ease;
            }
            /* 快捷键提示样式 */
            .shortcut-hint {
                position: absolute;
                top: 5px;
                right: 10px;
                background: rgba(0, 0, 0, 0.7);
                color: #aaa;
                padding: 6px 12px;
                border-radius: 6px;
                font-size: 11px;
                z-index: 10;
                cursor: help;
                transition: all 0.3s ease;
            }
            .shortcut-hint:hover {
                background: rgba(0, 0, 0, 0.9);
                color: white;
                transform: scale(1.05);
            }
            /* 快捷键提示更新 */
            .shortcut-hint table tr td:first-child b {
                color: #4dabf7;
            }
            /* 搜索框聚焦样式 */
            .playlist-search:focus {
                border-color: #4dabf7 !important;
                box-shadow: 0 0 0 3px rgba(77, 171, 247, 0.3) !important;
                outline: none !important;
            }
            /* 新增：搜索结果选中样式 */
            .playlist-item.selected {
                background: linear-gradient(180deg, #000000, #000000) !important;
                color: white !important;
                font-weight: bold !important;
                border-left: 4px solid #f59f00 !important;
                outline: 2px solid #37b24d;
                outline-offset: -2px;
            }
            .playlist-item.selected:hover {
                background: linear-gradient(135deg, #339af0, #1864ab) !important;
            }
            /* 频道列表焦点状态 */
            #playlist-container:focus-within {
                border-color: #4dabf7;
            }
            .playlist-item:focus {
                outline: 2px solid #4dabf7;
                outline-offset: -2px;
            }
            /* 音量极限状态提示 */
            @keyframes limitFlash {
                0% { transform: translateX(-50%) scale(1); }
                50% { transform: translateX(-50%) scale(1.1); background: rgba(255, 59, 48, 0.9); }
                100% { transform: translateX(-50%) scale(1); }
            }
            .volume-limit {
                animation: limitFlash 0.5s ease;
            }
            /* 新增：当前节目样式 */
            .current-program {
                display: block;
                font-size: 0.8em;
                color: #aaa;
                margin-top: 2px;
            }
            /* 新增：EPG弹出框样式 */
            .epg-popup {
                transition: all 0.2s ease;
                max-width: 300px;
                font-size: 12px;
                line-height: 1.4;
            }
            /* 新增：跑马灯动画 */
            @keyframes marquee {
                from { transform: translateX(0); }        /* 从右侧开始显示 */
                to   { transform: translateX(-100%); }    /* 滚到完全移出 */
            }
        `;
        document.head.appendChild(style);
    }
    function createDynamicUI() {
        UI.loudnessBtn = document.createElement("button");
        UI.loudnessBtn.className = "loudness-btn";
        UI.loudnessBtn.innerHTML = "<svg viewBox='0 0 24 24' width='18' height='18' fill='currentColor' style='vertical-align: middle;'><path d='M12 .99C5.92 .99 1 5.92 1 11.99C1 18.07 5.92 22.99 12 22.99C18.07 22.99 23 18.07 23 11.99C23 5.92 18.07 .99 12 .99ZM12 2.99C14.38 2.99 16.67 3.94 18.36 5.63C20.05 7.32 21 9.61 21 11.99C21 14.38 20.05 16.67 18.36 18.36C16.67 20.05 14.38 20.99 12 20.99C9.61 20.99 7.32 20.05 5.63 18.36C3.94 16.67 3 14.38 3 11.99C3 9.61 3.94 7.32 5.63 5.63C7.32 3.94 9.61 2.99 12 2.99ZM14 6.00C13.73 6.00 13.48 6.10 13.29 6.29C13.10 6.48 13 6.73 13 7.00V17.00C13 17.26 13.10 17.52 13.29 17.70C13.48 17.89 13.73 18.00 14 18.00C14.26 18.00 14.51 17.89 14.70 17.70C14.89 17.52 15 17.26 15 17.00V7.00C15 6.73 14.89 6.48 14.70 6.29C14.51 6.10 14.26 6.00 14 6.00ZM10 8.00C9.73 8.00 9.48 8.10 9.29 8.29C9.10 8.48 9 8.73 9 9.00V15.00C9 15.26 9.10 15.52 9.29 15.70C9.48 15.89 9.73 16.00 10 16.00C10.26 16.00 10.51 15.89 10.70 15.70C10.89 15.52 11 15.26 11 15.00V9.00C11 8.73 10.89 8.48 10.70 8.29C10.51 8.10 10.26 8.00 10 8.00ZM18 9.00C17.73 9.00 17.48 9.10 17.29 9.29C17.10 9.48 17 9.73 17 10.00V14.00C17 14.26 17.10 14.52 17.29 14.70C17.48 14.89 17.73 15.00 18 15.00C18.26 15.00 18.51 14.89 18.70 14.70C18.89 14.52 19 14.26 19 14.00V10.00C19 9.73 18.89 9.48 18.70 9.29C18.51 9.10 18.26 9.00 18 9.00ZM6 10.00C5.73 10.00 5.48 10.10 5.29 10.29C5.10 10.48 5 10.73 5 11.00V13.00C5 13.26 5.10 13.52 5.29 13.70C5.48 13.89 5.73 14.00 6 14.00C6.26 14.00 6.51 13.89 6.70 13.70C6.89 13.52 7 13.26 7 13.00V11.00C7 10.73 6.89 10.48 6.70 10.29C6.51 10.10 6.26 10.00 6 10.00Z'/></svg>";
        UI.loudnessBtn.title = "切换响度均衡(L)";
        UI.loudnessBtn.style.cssText = "background:none; border:none; color:white; cursor:pointer; margin-right:5px; display: flex; align-items: center; justify-content: center;";
        UI.volumeBtn.insertAdjacentElement("beforebegin", UI.loudnessBtn);
        setupButtonHoverEffects(UI.loudnessBtn);
        UI.loudnessBtn.onclick = toggleLoudnessEqualizer;
        UI.infoBtn = document.createElement("button");
        UI.infoBtn.className = "info-btn";
        UI.infoBtn.innerHTML = "ⓘ";
        UI.infoBtn.title = "播放信息(ｉ)";
        UI.infoBtn.style.cssText = "background:none; border:none; color:white; cursor:pointer; margin-left:10px;";
        UI.volumeContainer.insertAdjacentElement("afterend", UI.infoBtn);
        setupButtonHoverEffects(UI.infoBtn);
        UI.infoPanel = document.createElement("div");
        UI.infoPanel.className = "info-panel";
        UI.infoPanel.style.cssText = "display:none; position:absolute; bottom:60px; right:10px; background:rgba(0,0,0,0.8); padding:10px; border-radius:4px; font-size:12px; z-index: 20;";
        UI.videoContainer.appendChild(UI.infoPanel);
        UI.switchSourceBtn = document.createElement("button");
        UI.switchSourceBtn.className = "switch-source-btn";
        UI.switchSourceBtn.innerHTML = "⥮";
        UI.switchSourceBtn.title = "手动换源(ｓ)";
        UI.switchSourceBtn.style.cssText = "background:none; border:none; color:white; cursor:pointer; margin-left:10px; font-size:16px;";
        UI.infoBtn.insertAdjacentElement("afterend", UI.switchSourceBtn);
        setupButtonHoverEffects(UI.switchSourceBtn);
        // 新增：EPG按钮
        UI.epgBtn = document.createElement("button");
        UI.epgBtn.className = "epg-btn";
        UI.epgBtn.innerHTML = "📺";
        UI.epgBtn.title = "节目信息(e)";
        UI.epgBtn.style.cssText = "background:none; border:none; color:white; cursor:pointer; margin-left:10px;";
        UI.switchSourceBtn.insertAdjacentElement("afterend", UI.epgBtn);
        setupButtonHoverEffects(UI.epgBtn);
        UI.epgBtn.onclick = showEpgMarquee;
        // ─── 新增：进阶设置按钮 ───────────────────────────────
        UI.advancedBtn = document.createElement("button");
        UI.advancedBtn.innerHTML = "⚙️";
        UI.advancedBtn.title = "多码率/音轨/字幕";
        UI.advancedBtn.className = "control-btn advanced-btn";
        UI.advancedBtn.disabled = true;
        UI.switchSourceBtn.insertAdjacentElement("afterend", UI.advancedBtn);
        // 进阶设置面板
        UI.advancedPanel = document.createElement("div");
        UI.advancedPanel.className = "advanced-panel";
        UI.advancedPanel.style.display = "none";
        UI.advancedPanel.innerHTML = `
            <div class="section quality-section">
                <div class="section-title">码率</div>
                <div class="options" id="quality-options"></div>
            </div>
            <div class="section audio-section">
                <div class="section-title">音轨</div>
                <div class="options" id="audio-options"></div>
            </div>
            <div class="section subtitle-section">
                <div class="section-title">字幕</div>
                <div class="options" id="subtitle-options"></div>
            </div>
        `;
        UI.videoContainer.appendChild(UI.advancedPanel);
        // 添加快捷键提示
        const shortcutHint = document.createElement('div');
        shortcutHint.className = 'shortcut-hint';
        shortcutHint.innerHTML = '快捷键说明';
        shortcutHint.style.cssText = 'position:absolute; top:5px; right:10px; background:rgba(0,0,0,0.7); color:#aaa; padding:6px 12px; border-radius:6px; font-size:11px; z-index:10; cursor:help;';
        UI.videoContainer.appendChild(shortcutHint);
        // 鼠标悬停时显示完整快捷键列表
        shortcutHint.addEventListener('mouseenter', () => {
            shortcutHint.innerHTML = `
                <div style="font-weight:bold; margin-bottom:5px; border-bottom:1px solid #444; padding-bottom:3px;">快捷键列表</div>
                <table style="font-size:10px; line-height:1.6;">
                    <tr><td><b>/</b></td><td>搜索频道列表</td></tr>
                    <tr><td><b>Enter</b></td><td>播放选中频道</td></tr>
                    <tr><td><b>↑↓</b></td><td>在搜索结果中导航</td></tr>
                    <tr><td><b>空格</b></td><td>播放/暂停</td></tr>
                    <tr><td><b>↑↓</b></td><td>音量调节</td></tr>
                    <tr><td><b>←→</b></td><td>快退/快进5秒</td></tr>
                    <tr><td><b>f</b></td><td>全屏切换</td></tr>
                    <tr><td><b>m</b></td><td>静音切换</td></tr>
                    <tr><td><b>p</b></td><td>频道列表</td></tr>
                    <tr><td><b>ESC</b></td><td>关闭列表</td></tr>
                    <tr><td><b>[ ]</b></td><td>上/下一个频道</td></tr>
                    <tr><td><b>s</b></td><td>手动换源</td></tr>
                    <tr><td><b>i</b></td><td>信息面板</td></tr>
                    <tr><td><b>e</b></td><td>节目信息</td></tr>
                    <tr><td><b>L</b></td><td>响度均衡</td></tr>
                </table>
                <div style="margin-top:5px; font-size:9px; color:#aaa;">
                    提示：频道列表打开时，上下箭头用于导航
                </div>
            `;
            shortcutHint.style.width = '150px';
            shortcutHint.style.fontSize = '10px';
            shortcutHint.style.padding = '10px';
        });
        shortcutHint.addEventListener('mouseleave', () => {
            shortcutHint.innerHTML = '快捷键说明';
            shortcutHint.style.width = 'auto';
            shortcutHint.style.fontSize = '11px';
            shortcutHint.style.padding = '6px 12px';
        });
        // 给搜索框添加特殊类名以便CSS选择
        UI.playlistSearchInput.classList.add('playlist-search');
        // 给频道列表项目添加tabindex属性，使其可获得焦点
        UI.playlistItems.addEventListener('DOMNodeInserted', function() {
            const items = UI.playlistItems.querySelectorAll('.playlist-item');
            items.forEach((item, index) => {
                item.setAttribute('tabindex', '-1'); // 可通过脚本获取焦点，但不在Tab顺序中
            });
        });
    }
    // ==================== 修复的 togglePlaylistUI 函数 ====================
    function togglePlaylistUI(show) {
        const shouldShow = show !== undefined ? show : !UI.playlistContainer.classList.contains("hidden") === false;
        const currentlyVisible = !UI.playlistContainer.classList.contains("hidden");
        // 如果状态没有变化，直接返回
        if (shouldShow === currentlyVisible) return;
        UI.playlistContainer.classList.toggle("hidden", !shouldShow);
        if (shouldShow) {
            // 打开频道列表时，给频道列表容器添加一个焦点状态
            UI.playlistContainer.setAttribute('tabindex', '-1');
            UI.playlistContainer.classList.add('has-focus');
            // 如果有选中项，使其获得焦点
            setTimeout(() => {
                const selectedItem = UI.playlistItems.querySelector('.selected');
                if (selectedItem) {
                    selectedItem.focus();
                }
            }, 50);
            // 新增: 重新渲染以更新节目信息
            renderPlaylist(UI.playlistSearchInput.value);
        } else {
            // 如果关闭频道列表，确保移除焦点
            UI.playlistSearchInput.blur();
            UI.playlistSearchInput.style.border = "";
            UI.playlistSearchInput.style.boxShadow = "";
            // 清除选中项
            const selectedItem = UI.playlistItems.querySelector('.selected');
            if (selectedItem) {
                selectedItem.classList.remove('selected');
            }
        }
    }
    function loadVolumeSettings() {
        chrome.storage.local.get(["volume", "loudnessEnabled"], function(result) {
            if (result.volume !== undefined) {
                UI.videoPlayer.volume = result.volume;
                UI.volumeProgress.style.width = result.volume * 100 + "%";
                updateVolumeIcon();
            }
            if (result.loudnessEnabled !== undefined && result.loudnessEnabled) {
                // 延迟一小会儿确保 video 元素准备好，或者在尝试播放时触发
                // 这里我们直接调用，toggleLoudnessEqualizer 内部会处理初始化
                setTimeout(() => {
                    if (result.loudnessEnabled) toggleLoudnessEqualizer(true);
                }, 1000);
            }
        });
    }
    function switchToPrevChannel() {
        if (!state.isM3UPlaylist || state.currentPlaylist.length === 0) {
            showNotification("当前不是频道列表模式或列表为空",'warning', 1500);
            return;
        }
        if (state.currentPlaylistIndex === -1) {
            state.currentPlaylistIndex = 0;
        }
        let prevIndex = state.currentPlaylistIndex - 1;
        if (prevIndex < 0) {
            prevIndex = state.currentPlaylist.length - 1;
        }
        console.log(`[频道切换] 切换到上一个频道: ${state.currentPlaylistIndex} → ${prevIndex}`);
        const item = state.currentPlaylist[prevIndex];
        if (item) {
            showNotification(`切换到上一个频道: ${item.title || `频道 ${prevIndex + 1}`}`, 1500);
        }
        playPlaylistItem(prevIndex);
    }
    function switchToNextChannel() {
        if (!state.isM3UPlaylist || state.currentPlaylist.length === 0) {
            showNotification("当前不是频道列表模式或列表为空",'warning', 1500);
            return;
        }
        if (state.currentPlaylistIndex === -1) {
            state.currentPlaylistIndex = 0;
        }
        let nextIndex = state.currentPlaylistIndex + 1;
        if (nextIndex >= state.currentPlaylist.length) {
            nextIndex = 0;
        }
        console.log(`[频道切换] 切换到下一个频道: ${state.currentPlaylistIndex} → ${nextIndex}`);
        const item = state.currentPlaylist[nextIndex];
        if (item) {
            showNotification(`切换到下一个频道: ${item.title || `频道 ${nextIndex + 1}`}`, 1500);
        }
        playPlaylistItem(nextIndex);
    }
    function parseInitialUrl() {
        const urlParams = new URLSearchParams(window.location.search);
        const queryUrl = urlParams.get("url");
        const hashUrl = window.location.hash.substring(1);
        state.videoUrl = queryUrl || hashUrl;
        if (state.videoUrl) {
            UI.videoInfo.textContent = decodeURIComponent(state.videoUrl);
            try {
                const urlObj = new URL(state.videoUrl);
                state.baseUrl = urlObj.href.substring(0, urlObj.href.lastIndexOf("/") + 1);
                state.originalPlaylistUrl = state.videoUrl;
            } catch (e) {
                console.warn("基础URL解析失败:", e);
                state.baseUrl = "";
                state.originalPlaylistUrl = state.videoUrl;
            }
        }
    }
    function clearTimers(keys = []) {
        const targets = keys.length > 0 ? keys : ["load", "stall"];
        targets.forEach(key => {
            if (state.timers[key]) {
                clearTimeout(state.timers[key]);
                state.timers[key] = null;
            }
        });
    }
    function showLoading(show) {
        UI.loading.style.display = show ? "block" : "none";
    }
    function showError(message) {
        showLoading(false);
        UI.errorMessage.textContent = message;
        UI.errorMessage.style.display = "block";
        if (message.includes("黑名单") || message.includes("拦截") || message.includes("禁止")) {
            UI.errorMessage.classList.add("blacklist-error");
        } else {
            UI.errorMessage.classList.remove("blacklist-error");
        }
    }
    function formatTime(seconds) {
        if (seconds === Infinity || isNaN(seconds)) return "Live";
        const m = Math.floor(seconds / 60);
        const s = Math.floor(seconds % 60);
        return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
    }
    function startVideoLoadProcess() {
        showLoading(true);
        UI.errorMessage.style.display = "none";
        UI.errorMessage.classList.remove("blacklist-error");
        checkAndInitPlayer(state.videoUrl);
    }
    // 新增：从 storage 加载用户设置
    function loadSettings() {
        chrome.storage.local.get([
            'loadTimeout',
            'stallTimeout',
            'maxRetryRounds',
            'searchDebounce',
            'playlistRefreshInterval',
            'autoRefreshEnabled',
            'epgEnabled',
            'epgUrl',
            'marqueeSpeed',
            'marqueeColor',
            'marqueeFontSize',
            'headerRules'
        ], function(result) {
            // 更新 CONFIG（将用户友好的单位转换为毫秒）
            if (result.loadTimeout !== undefined) {
                CONFIG.LOAD_TIMEOUT_MS = result.loadTimeout;
            }
            if (result.stallTimeout !== undefined) {
                CONFIG.STALL_TIMEOUT_MS = result.stallTimeout;
            }
            if (result.maxRetryRounds !== undefined) {
                CONFIG.MAX_RETRY_ROUNDS = result.maxRetryRounds;
            }
            if (result.searchDebounce !== undefined) {
                CONFIG.SEARCH_DEBOUNCE_MS = result.searchDebounce;
            }
            if (result.playlistRefreshInterval !== undefined) {
                CONFIG.PLAYLIST_REFRESH_INTERVAL = result.playlistRefreshInterval;
            }
            if (result.autoRefreshEnabled !== undefined) {
                CONFIG.AUTO_REFRESH_ENABLED = result.autoRefreshEnabled;
            }
            if (result.epgEnabled !== undefined) {
                CONFIG.EPG_ENABLED = result.epgEnabled;
            }
            if (result.epgUrl !== undefined) {
                CONFIG.EPG_URL = result.epgUrl;
            }
            if (result.marqueeSpeed !== undefined) {
                CONFIG.MARQUEE_SPEED = result.marqueeSpeed;
            }
            if (result.marqueeColor !== undefined) {
                CONFIG.MARQUEE_COLOR = result.marqueeColor;
            }
            if (result.marqueeFontSize !== undefined) {
                CONFIG.MARQUEE_FONT_SIZE = result.marqueeFontSize;
            }
            if (result.headerRules !== undefined) {
                CONFIG.RULES = result.headerRules;
            }            
            console.log('[设置] 配置已从 storage 加载');
            console.log('[设置] 加载超时:', CONFIG.LOAD_TIMEOUT_MS, 'ms');
            console.log('[设置] 卡顿超时:', CONFIG.STALL_TIMEOUT_MS, 'ms');
            console.log('[设置] 最大重试轮次:', CONFIG.MAX_RETRY_ROUNDS);
            console.log('[设置] 列表刷新间隔:', CONFIG.PLAYLIST_REFRESH_INTERVAL, 'ms');
            console.log('[设置] 自动刷新:', CONFIG.AUTO_REFRESH_ENABLED);
            console.log('[设置] EPG启用:', CONFIG.EPG_ENABLED);
            console.log('[设置] EPG URL:', CONFIG.EPG_URL);
            console.log('[设置] 跑马灯速度:', CONFIG.MARQUEE_SPEED, 's/char');
            console.log('[设置] 跑马灯颜色:', CONFIG.MARQUEE_COLOR);
            console.log('[设置] 跑马灯字体大小:', CONFIG.MARQUEE_FONT_SIZE, 'px');
            // 如果EPG启用，加载数据
            if (CONFIG.EPG_ENABLED) {
                loadEPG();
            }
        });
    }
    // 新增：监听设置更新消息
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        if (message.action === 'settingsUpdated') {
            console.log('[设置] 收到设置更新通知');
            // 更新 CONFIG
            if (message.config.loadTimeout) {
                CONFIG.LOAD_TIMEOUT_MS = message.config.loadTimeout;
                console.log('[设置] 更新加载超时:', CONFIG.LOAD_TIMEOUT_MS, 'ms');
            }
            if (message.config.stallTimeout) {
                CONFIG.STALL_TIMEOUT_MS = message.config.stallTimeout;
                console.log('[设置] 更新卡顿超时:', CONFIG.STALL_TIMEOUT_MS, 'ms');
            }
            if (message.config.maxRetryRounds) {
                CONFIG.MAX_RETRY_ROUNDS = message.config.maxRetryRounds;
                console.log('[设置] 更新最大重试轮次:', CONFIG.MAX_RETRY_ROUNDS);
            }
            if (message.config.searchDebounce) {
                CONFIG.SEARCH_DEBOUNCE_MS = message.config.searchDebounce;
                console.log('[设置] 更新搜索防抖:', CONFIG.SEARCH_DEBOUNCE_MS, 'ms');
            }
            if (message.config.playlistRefreshInterval) {
                CONFIG.PLAYLIST_REFRESH_INTERVAL = message.config.playlistRefreshInterval;
                console.log('[设置] 更新列表刷新间隔:', CONFIG.PLAYLIST_REFRESH_INTERVAL, 'ms');
                // 如果正在播放M3U列表，重启刷新定时器
                if (state.isM3UPlaylist && CONFIG.AUTO_REFRESH_ENABLED) {
                    if (state.timers.refreshPlaylist) {
                        clearTimeout(state.timers.refreshPlaylist);
                    }
                    startPlaylistRefreshTimer();
                }
            }
            if (message.config.autoRefreshEnabled !== undefined) {
                CONFIG.AUTO_REFRESH_ENABLED = message.config.autoRefreshEnabled;
                console.log('[设置] 更新自动刷新:', CONFIG.AUTO_REFRESH_ENABLED);
                if (!CONFIG.AUTO_REFRESH_ENABLED && state.timers.refreshPlaylist) {
                    clearTimeout(state.timers.refreshPlaylist);
                    state.timers.refreshPlaylist = null;
                } else if (CONFIG.AUTO_REFRESH_ENABLED && state.isM3UPlaylist) {
                    startPlaylistRefreshTimer();
                }
            }
            if (message.config.blacklist) {
                state.blacklist = message.config.blacklist;
                state.isBlacklistLoaded = true;
                console.log(`[设置] 黑名单已更新，${state.blacklist.length} 个关键词`);
            }
            if (message.config.headerRules) {
                CONFIG.RULES = message.config.headerRules;
                console.log(`[设置] headerRules已更新，${CONFIG.RULES.length} 条规则`);
            }            
            // 在 chrome.runtime.onMessage 监听器中，修改 EPG 相关部分为：
            if (message.config.epgEnabled !== undefined) {
                const oldEnabled = CONFIG.EPG_ENABLED;
                CONFIG.EPG_ENABLED = message.config.epgEnabled;
                console.log('[设置] 更新EPG启用:', CONFIG.EPG_ENABLED);
                if (CONFIG.EPG_ENABLED !== oldEnabled) {  // 只在启用状态真正变化时才操作
                    if (CONFIG.EPG_ENABLED) {
                        loadEPG();  // 启用时才加载
                    } else {
                        state.epgData = {};
                        state.channelMap = {};
                        state.epgExpiryTime = 0;
                        if (state.timers.epgRefresh) {
                            clearTimeout(state.timers.epgRefresh);
                            state.timers.epgRefresh = null;
                        }
                    }
                }
            }
            if (message.config.epgUrl) {
                const oldUrl = CONFIG.EPG_URL;
                CONFIG.EPG_URL = message.config.epgUrl;
                console.log('[设置] 更新EPG URL:', CONFIG.EPG_URL);
                // URL 改变且 EPG 已启用时，才重新加载
                if (CONFIG.EPG_ENABLED && oldUrl !== CONFIG.EPG_URL) {
                    loadEPG();
                }
            }
            if (message.config.marqueeSpeed !== undefined) {
                CONFIG.MARQUEE_SPEED = message.config.marqueeSpeed;
                console.log('[设置] 更新跑马灯速度:', CONFIG.MARQUEE_SPEED, 'px/s');
            }
            if (message.config.marqueeColor !== undefined) {
                CONFIG.MARQUEE_COLOR = message.config.marqueeColor;
                console.log('[设置] 更新跑马灯颜色:', CONFIG.MARQUEE_COLOR);
            }
            if (message.config.marqueeFontSize !== undefined) {
                CONFIG.MARQUEE_FONT_SIZE = message.config.marqueeFontSize;
                console.log('[设置] 更新跑马灯字体大小:', CONFIG.MARQUEE_FONT_SIZE, 'px');
            }
            // 更新信息面板
            updateInfoPanel();
            showNotification('设置已更新', 'success',2000);
        }
    });
    // 修改后的 loadBlacklist 函数：优先从 storage，没有则从文件
    function loadBlacklist() {
        state.blacklist = [];
        state.isBlacklistLoaded = false;
        console.log('[黑名单] 开始加载黑名单...');
        // 1. 首先尝试从 storage 加载（用户自定义的）
        chrome.storage.local.get(['blacklist', 'blacklistContent'], function(result) {
            if (result.blacklist && Array.isArray(result.blacklist) && result.blacklist.length > 0) {
                // 从 storage 的数组加载成功
                state.blacklist = result.blacklist;
                console.log(`[黑名单] 从 storage 加载 ${state.blacklist.length} 个关键词`);
                state.isBlacklistLoaded = true;
                if (state.videoUrl) startVideoLoadProcess();
            } else if (result.blacklistContent) {
                // 从 storage 的字符串内容加载
                state.blacklist = result.blacklistContent.split('\n')
                    .map(line => line.trim())
                    .filter(line => line && !line.startsWith('#') && !line.startsWith('//'))
                    .filter(keyword => keyword.length > 0);
                console.log(`[黑名单] 从 storage 内容加载 ${state.blacklist.length} 个关键词`);
                state.isBlacklistLoaded = true;
                if (state.videoUrl) startVideoLoadProcess();
            } else {
                // 2. storage 中没有，则从文件加载
                console.log('[黑名单] storage 中无黑名单，尝试从文件加载');
                fetch(CONFIG.BLACKLIST_URL)
                    .then(response => {
                        if (!response.ok) {
                            throw new Error(`HTTP ${response.status}`);
                        }
                        return response.text();
                    })
                    .then(text => {
                        state.blacklist = text.split('\n')
                            .map(line => line.trim())
                            .filter(line => line && !line.startsWith('#') && !line.startsWith('//'))
                            .filter(keyword => keyword.length > 0);
                        console.log(`[黑名单] 从文件加载 ${state.blacklist.length} 个关键词`);
                        state.isBlacklistLoaded = true;
                        if (state.videoUrl) startVideoLoadProcess();
                    })
                    .catch(error => {
                        console.warn('[黑名单] 文件加载失败，使用空黑名单:', error);
                        state.blacklist = [];
                        state.isBlacklistLoaded = true;
                        if (state.videoUrl) startVideoLoadProcess();
                    });
            }
        });
    }
    // 新增：为所有控制按钮添加统一的鼠标效果
    function addButtonHoverEffects() {
        const staticButtons = [
            UI.backBtn,
            UI.playPauseBtn,
            UI.prevChannelBtn,
            UI.nextChannelBtn,
            UI.volumeBtn,
            UI.fullscreenBtn,
            UI.playlistBtn,
            UI.closePlaylistBtn,
            UI.clearSearchBtn,
            UI.epgBtn // 新增
        ];
        staticButtons.forEach(button => {
            if (!button) return;
            setupButtonHoverEffects(button);
        });
    }
    function setupButtonHoverEffects(button) {
        if (!button) return;
        button.style.opacity = '1';
        button.style.transition = 'opacity 0.2s ease';
        button.addEventListener('mouseenter', () => {
            button.style.opacity = '0.8';
        });
        button.addEventListener('mouseleave', () => {
            button.style.opacity = '1';
        });
        button.addEventListener('mousedown', () => {
            button.style.opacity = '0.6';
        });
        button.addEventListener('mouseup', () => {
            button.style.opacity = '0.8';
        });
    }
    function checkUrlInBlacklist(url, urlType = "URL") {
        if (!url || typeof url !== 'string') {
            return false;
        }
        // 等待黑名单加载完成
        if (!state.isBlacklistLoaded) {
            console.log(`[黑名单] 等待黑名单加载完成...`);
            setTimeout(() => {
                checkUrlInBlacklist(url, urlType);
            }, 100);
            return false;
        }
        const lowerUrl = url.toLowerCase();
        for (const keyword of state.blacklist) {
            if (!keyword) continue;
            const lowerKeyword = keyword.toLowerCase();
            // 支持简单的通配符匹配
            if (lowerKeyword.includes('*')) {
                // 将通配符转换为正则表达式
                const pattern = lowerKeyword
                    .replace(/\./g, '\\.')
                    .replace(/\*/g, '.*');
                const regex = new RegExp(`^${pattern}$`);
                if (regex.test(lowerUrl)) {
                    console.warn(`[黑名单拦截] ${urlType} 匹配通配符模式: "${keyword}"`);
                    console.warn(`[黑名单拦截] 被拦截的URL: ${url}`);
                    showError(
                        `播放被拦截：链接匹配黑名单规则\n\n` +
                        `规则: ${keyword}\n` +
                        `URL: ${url.substring(0, 80)}${url.length > 80 ? '...' : ''}`
                    );
                    handleBlacklistedInPlaylist(url, keyword);
                    return true;
                }
            } else if (lowerUrl.includes(lowerKeyword)) {
                console.warn(`[黑名单拦截] ${urlType} 包含黑名单关键词: "${keyword}"`);
                console.warn(`[黑名单拦截] 被拦截的URL: ${url}`);
                showError(
                    `播放被拦截：链接包含黑名单关键词\n\n` +
                    `关键词: ${keyword}\n` +
                    `URL: ${url.substring(0, 80)}${url.length > 80 ? '...' : ''}`
                );
                handleBlacklistedInPlaylist(url, keyword);
                return true;
            }
        }
        return false;
    }
    // 新增：处理频道列表中被黑名单拦截的项目
    function handleBlacklistedInPlaylist(blockedUrl, keyword) {
        if (!state.isM3UPlaylist || state.currentPlaylistIndex === -1) {
            return;
        }
        const item = state.currentPlaylist[state.currentPlaylistIndex];
        if (!item) return;
        // 从当前频道的URL列表中移除被拦截的URL
        if (item.urls && item.urls.length > 0) {
            const originalLength = item.urls.length;
            item.urls = item.urls.filter(url => url !== blockedUrl);
            if (item.urls.length < originalLength) {
                console.warn(`[黑名单] 从频道 "${item.title}" 中移除 ${originalLength - item.urls.length} 个被拦截的源`);
                // 更新当前频道信息
                if (state.currentChannelInfo.urls) {
                    state.currentChannelInfo.urls = state.currentChannelInfo.urls.filter(url => url !== blockedUrl);
                }
                // 如果当前正在播放被拦截的源，切换到下一个源
                if (item.currentUrlIndex !== undefined &&
                    item.urls.length > 0 &&
                    item.currentUrlIndex >= item.urls.length) {
                    item.currentUrlIndex = 0;
                    showNotification(`源被黑名单拦截，自动切换`, 2000);
                    // 自动播放下一个源
                    const nextUrl = item.urls[0];
                    setTimeout(() => {
                        if (checkUrlInBlacklist(nextUrl, "下一个源")) {
                            return;
                        }
                        destroyPlayer();
                        showLoading(true);
                        UI.errorMessage.style.display = "none";
                        UI.videoInfo.textContent = item.title || decodeURIComponent(nextUrl);
                        checkAndInitPlayer(nextUrl);
                    }, 1500);
                }
            }
            // 如果频道所有源都被拦截，跳过这个频道
            if (item.urls.length === 0) {
                console.warn(`[黑名单] 频道 "${item.title}" 所有源均被拦截，将跳过`);
                showNotification(`频道 "${item.title}" 已被屏蔽`, 3000);
                // 自动播放下一个频道
                setTimeout(() => {
                    let nextIndex = state.currentPlaylistIndex + 1;
                    while (nextIndex < state.currentPlaylist.length) {
                        const nextItem = state.currentPlaylist[nextIndex];
                        if (nextItem && nextItem.urls && nextItem.urls.length > 0) {
                            // 检查下一个频道的第一个URL是否在黑名单中
                            const firstUrl = nextItem.urls[0];
                            if (!checkUrlInBlacklist(firstUrl, "下一个频道URL")) {
                                playPlaylistItem(nextIndex);
                                return;
                            }
                        }
                        nextIndex++;
                    }
                    // 所有频道都被屏蔽
                    showError("所有频道均被黑名单拦截，无法播放");
                }, 1500);
            }
        }
    }
    function checkAndInitPlayer(url) {
        const thisRequestId = ++state.loadRequestId;
        // 等待黑名单加载完成
        if (!state.isBlacklistLoaded) {
            console.log(`[Req #${thisRequestId}] 等待黑名单加载...`);
            setTimeout(() => {
                if (thisRequestId === state.loadRequestId) {
                    checkAndInitPlayer(url);
                }
            }, 100);
            return;
        }
        // 检查URL是否在黑名单中（包括原始URL）
        if (checkUrlInBlacklist(url, "原始URL")) {
            return;
        }
        const lowerUrl = url.toLowerCase();
        //if (/(?:\.(flv|m3u8|m3u)|#m3u8|#m3u)([?#].*)?$/.test(lowerUrl)) {
        if (/(?:#m3u8|#m3u|#ts|#flv)([?#].*)?$/.test(lowerUrl)) {
            if (thisRequestId === state.loadRequestId) {
                initPlayerWithUrl(url);
            }
        } else {
            console.log(`[Req #${thisRequestId}] 检测重定向及 Content-Type:`, url);
            new Promise(resolve => {
                chrome.runtime.sendMessage({
                    action: "checkRedirect",
                    url: url
                }, response => resolve(response));
            }).then(response => {
                if (thisRequestId !== state.loadRequestId) {
                    console.warn(`[Req #${thisRequestId}] 请求已过期 (当前ID: ${state.loadRequestId})，丢弃结果。`);
                    return;
                }
                if (response && response.success) {
                    console.log(`[Req #${thisRequestId}] 重定向成功: ${response.finalUrl}`);
                    // 检查重定向后的URL是否在黑名单中
                    if (checkUrlInBlacklist(response.finalUrl, "重定向URL")) {
                        return;
                    }
                    initPlayerWithUrl(response.finalUrl, response.contentType || "");
                } else {
                    console.warn(`[Req #${thisRequestId}] 重定向检测无响应或失败，尝试直连`);
                    initPlayerWithUrl(url);
                }
            });
        }
    }
    function destroyPlayer() {
        //console.log("销毁播放器，重置类型为未知");
        if (state.player) {
            if (typeof state.player.destroy === "function") {
                state.player.destroy();
            } else if (state.player instanceof Hls) {
                state.player.destroy();
            }
            state.player = null;
        }
        UI.videoPlayer.removeAttribute("src");
        UI.videoPlayer.load();
        state.isPlaying = false;
        clearTimers();
        // 进阶面板重置
        if (UI.advancedBtn) UI.advancedBtn.disabled = true;
        if (UI.advancedPanel) UI.advancedPanel.style.display = 'none';
        state.streamInfo = {
            resolution: "未知",
            type: "未知",
            codec: "未知",
            bitrate: "未知",
            bandwidthEstimate: 0
        };
    }
    function initPlayerWithUrl(url, contentType = "") {
        // 再次检查URL（以防万一）
        if (checkUrlInBlacklist(url, "播放URL")) {
            return;
        }
        const lowerUrl = url.toLowerCase();
        const ct = contentType.toLowerCase();
        const isHlsContent = ct.includes("mpegurl") || ct.includes("hls") || ct.includes("text/html") || ct.includes("text/plain") || ct.includes("application/octet-stream");
        const isTsContent = ct.includes("mp2t");
        if (/(?:[.]m3u|#m3u)([?#].*)?$/.test(lowerUrl)) {
            //state.streamInfo.type = "M3U";
            //console.log("设置播放器类型:", state.streamInfo.type);
            initM3UPlaylist(url);
        } else if (/(?:[.]m3u8|#m3u8)([?#].*)?$/.test(lowerUrl)) {
            //state.streamInfo.type = isHlsContent ? "HLS (Type)" : "HLS";
            //console.log("设置播放器类型:", state.streamInfo.type);
            initHlsPlayer(url);
        } else if (isTsContent || /(?:[.]flv|[.]ts|#ts|#flv)([?#].*)?$/.test(lowerUrl)) {
            const mCT = isTsContent ? "TS" : "";
            initMpegtsPlayer(url,mCT);
        } else if (isHlsContent) {
            //state.streamInfo.type = "HLS (Type)";
            //console.log("设置播放器类型:", state.streamInfo.type);
            initHlsPlayer(url);
        } else {
            //state.streamInfo.type = "原生";
            //console.log("设置播放器类型:", state.streamInfo.type);
            initNativePlayer(url);
        }
    }
    /**
     * 使用 mpegts.js 初始化播放器
     * @param {string} url - 媒体流地址
     * @param {string} [mCT=""] - 内容类型提示，"TS" 表示 TS裸流，其他值（包括空字符串）视为 FLV
     */
    function initMpegtsPlayer(url, mCT = "") {
        const lowerUrl = url.toLowerCase();
        if (!mpegts.isSupported() || !mpegts.getFeatureList().mseLivePlayback) {
            return handleError("您的浏览器不支持 MPEG-TS/FLV 播放（需要 MSE 支持）");
        }
        destroyPlayer();
        const isTsStream = mCT === "TS" || mCT.toUpperCase() === "TS" || /(\.ts|#ts)([?#].*)?$/i.test(lowerUrl);
        const mediaType = isTsStream ? "mpegts" : "flv";
        state.streamInfo.type = isTsStream ? "TS" : "FLV";
        // state.streamInfo.codec = "未知";        // 可选：初始化
        // state.streamInfo.bitrate = "未知";      // 可选：初始化
        const player = mpegts.createPlayer({
            type: mediaType,
            url: url,
            isLive: true,
        }, {
            enableWorker: true,
            //stashInitialSize: 128 * 1024,
            //enableStashBuffer: false,
            //liveBufferLatencyChasing: true,
            fixAudioTimestampGap: true,
        });
        player.attachMediaElement(UI.videoPlayer);
        player.load();
        // ────────────────────────────────────────────────
        //  1. 获取编码方式（video & audio codec）
        // ────────────────────────────────────────────────
        // 监听媒体信息
        player.on(mpegts.Events.MEDIA_INFO, (info) => {
            clearTimers(["load"]);
            // 分辨率
            if (info.width && info.height) {
                state.streamInfo.resolution = `${info.width}x${info.height}`;
            }
            // 编码方式 - 使用 formatCodecName 美化显示
            if (info.videoCodec) {
                //state.streamInfo.videoCodecRaw = info.videoCodec;           // 保存原始值（可选）
                state.streamInfo.codec = formatCodecName(info.videoCodec);  // 美化后的名称
                // console.log("视频编码:", state.streamInfo.codec);
            }
            //if (info.audioCodec) {
            //    state.streamInfo.audioCodecRaw = info.audioCodec;
            //    state.streamInfo.audioCodecDisplay = formatCodecName(info.audioCodec);
                // console.log("音频编码:", state.streamInfo.audioCodecDisplay);
            //}
            updateInfoPanel(); // 在这里更新UI，显示美化后的编码名称
        });
        // ────────────────────────────────────────────────
        player.on(mpegts.Events.ERROR, (errType, errDetail) => {
            console.error("mpegts Error:", errType, errDetail);
            handleError(`播放错误: ${errType} - ${errDetail}`);
        });
        state.player = player;
        attachCommonVideoEvents();
    }
    function initHlsPlayer(url) {
        if (Hls.isSupported()) {
            destroyPlayer();
            state.streamInfo.type = "HLS";
            const player = new Hls({
                debug: false,
                capLevelToPlayerSize: true,
                autoLevelEnabled: true,
                fragLoadingMaxRetry: 1,
                fragLoadingRetryDelay: 500,
                // --- 【新增建议】针对加密流和扩展环境的优化 ---
                xhrSetup: function (xhr, url) {
                    // 仅针对 Key 文件进行特殊处理（如果需要）
                    // 许多加密流的 Key 文件扩展名为 .key 或包含 keyfile
                    if (url.includes('.key') || url.includes('keyfile')) {
                        // console.log('正在请求解密 Key:', url);
                        // 场景A：如果 Key 服务器需要 Token
                        // xhr.setRequestHeader('Authorization', 'Bearer xxx');
                        // 场景B：扩展环境通常不需要设置 withCredentials，除非服务器明确要求
                        xhr.withCredentials = true; 
                    }
                }
                // -------------------------------------------
            });
            player.loadSource(url);
            player.attachMedia(UI.videoPlayer);
            player.on(Hls.Events.MANIFEST_PARSED, (event, data) => {
                clearTimers(["load"]);
                console.log("HLS Manifest Parsed");
                showLoading(false);
                updateAdvancedPanel(player);
                updateResolutionFromHls(player);
                attemptPlay();
            });
            player.on(Hls.Events.LEVEL_SWITCHED, (event, data) => { 
                updateAdvancedPanel(player); 
                /*const level = player.levels[player.currentLevel];
                let res = "未知";
                if (level?.width && level?.height) {
                    res = `${level.width}×${level.height}`;
                } else if (video.videoWidth && video.videoHeight) {
                    res = `${video.videoWidth}×${video.videoHeight}`;
                }
                state.streamInfo.resolution = res;*/
                updateResolutionFromHls(player);
                console.log("幻麻吕后分辨率:", state.streamInfo.resolution);
            });
            player.on(Hls.Events.AUDIO_TRACK_SWITCHED, () => {
                updateAdvancedPanel(player);
                updateResolutionFromHls(player);
            });
            player.on(Hls.Events.SUBTITLE_TRACK_SWITCHED, () => updateAdvancedPanel(player));
            player.on(Hls.Events.AUDIO_TRACKS_UPDATED, () => updateAdvancedPanel(player));
            player.on(Hls.Events.SUBTITLE_TRACKS_UPDATED, () => updateAdvancedPanel(player));
            // 级别切换时更新（尤其是自动切换）
            player.on(Hls.Events.BUFFER_CODECS, (event, data) => {
                console.log("[BUFFER_CODECS] 触发了！", data);
                let videoCodec = null;
                // 正确方式1：直接取对象（最常见、最推荐）
                if (data?.video?.codec) {
                    videoCodec = data.video.codec;
                }
                // 或者方式2：用 tracks 兜底（你的数据里也有）
                else if (data?.tracks?.video?.codec) {
                    videoCodec = data.tracks.video.codec;
                }
                if (videoCodec) {
                    console.log("[BUFFER_CODECS] 成功获取视频编码:", videoCodec);
                    state.streamInfo.codec = formatCodecName(videoCodec);
                    updateInfoPanel();
                } else {
                    console.log("[BUFFER_CODECS] 没有找到视频 codec");
                }
                // 可选：音频也取一下
                if (data?.audio?.codec) {
                    console.log("[BUFFER_CODECS] 音频编码:", data.audio.codec);
                }
            });
            // 实时更新带宽估计（无 manifest bitrate 时用）
            player.on(Hls.Events.FRAG_LOADED, () => {
                if (player.bandwidthEstimate > 0) {
                    state.streamInfo.bandwidthEstimate = player.bandwidthEstimate;
                    updateBitrateDisplay(player);
                    updateInfoPanel();
                }
            });
            player.on(Hls.Events.ERROR, (event, data) => {
                if (data.fatal) {
                    console.error("HLS Fatal Error:", data.type, data.details);
                    handleError(`HLS播放错误: ${data.details}`);
                }
            });
            state.player = player;
            attachCommonVideoEvents();
        } else if (UI.videoPlayer.canPlayType("application/vnd.apple.mpegurl")) {
            destroyPlayer();
            UI.videoPlayer.src = url;
            attachCommonVideoEvents();
        } else {
            handleError("您的浏览器不支持HLS播放");
        }
    }
    /**
     * 简单通配符匹配：支持 * （转换为 .* 正则）
     * @param {string} url      - 当前请求的完整 URL
     * @param {string} pattern  - 如 '*.abc.com' 或 'https://cdn.*.com/path/*'
     * @returns {boolean}
     */
    function matchesPattern(url, pattern) {
        // 转义正则特殊字符，然后把 * 转为 .*
        const escaped = pattern.replace(/[.+?^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*');
        const regex = new RegExp(`^${escaped}$`, 'i');  // i = 不区分大小写
        return regex.test(url);
    }
    // ────────────────────────────────────────────────
    //  更新进阶设置面板（核心功能）
    // ────────────────────────────────────────────────
    function updateAdvancedPanel(hls) {
        if (!hls) return;
        const hasQuality   = hls.levels?.length > 1;
        const hasAudio     = hls.audioTracks?.length > 1;
        const hasSubtitle  = hls.subtitleTracks?.length > 0;
        UI.advancedBtn.disabled = !(hasQuality || hasAudio || hasSubtitle);
        // 码率
        const qContainer = document.getElementById('quality-options');
        qContainer.innerHTML = '';
        if (hasQuality) {
            hls.levels.forEach((level, idx) => {
                const item = document.createElement('div');
                item.className = 'option-item';
                item.textContent = levelToText(level);
                if (idx === hls.currentLevel) item.classList.add('active');
                item.onclick = () => {
                    hls.currentLevel = idx;
                    hls.autoLevelEnabled = false;
                    updateAdvancedPanel(hls);
                    showNotification(`码率：${levelToText(level)}`, 1500);
                };
                qContainer.appendChild(item);
            });
        } else {
            qContainer.innerHTML = '<div class="option-item disabled">无多码率选项</div>';
        }
        // 音轨
        const aContainer = document.getElementById('audio-options');
        aContainer.innerHTML = '';
        if (hasAudio) {
            hls.audioTracks.forEach((track, idx) => {
                const item = document.createElement('div');
                item.className = 'option-item';
                item.textContent = track.name || track.lang || `音轨 ${idx+1}`;
                if (hls.audioTrack === idx) item.classList.add('active');
                item.onclick = () => {
                    hls.audioTrack = idx;
                    updateAdvancedPanel(hls);
                    showNotification(`音轨：${track.name || track.lang || '未知'}`, 1500);
                };
                aContainer.appendChild(item);
            });
        } else {
            aContainer.innerHTML = '<div class="option-item disabled">无多音轨</div>';
        }
        // 字幕
        const sContainer = document.getElementById('subtitle-options');
        sContainer.innerHTML = '';
        const offItem = document.createElement('div');
        offItem.className = 'option-item' + (hls.subtitleTrack < 0 ? ' active' : '');
        offItem.textContent = '关闭字幕';
        offItem.onclick = () => {
            hls.subtitleTrack = -1;
            updateAdvancedPanel(hls);
        };
        sContainer.appendChild(offItem);
        if (hasSubtitle) {
            hls.subtitleTracks.forEach((track, idx) => {
                const item = document.createElement('div');
                item.className = 'option-item';
                item.textContent = track.name || track.lang || `字幕 ${idx+1}`;
                if (hls.subtitleTrack === idx) item.classList.add('active');
                item.onclick = () => {
                    hls.subtitleTrack = idx;
                    updateAdvancedPanel(hls);
                    showNotification(`字幕：${track.name || track.lang || '未知'}`, 1500);
                };
                sContainer.appendChild(item);
            });
        }
    }
    function levelToText(level) {
        if (!level) return '未知';
        if (level.height) {
            let txt = level.height + 'p';
            if (level.bitrate) txt += ` (${formatBitrate(level.bitrate)})`;
            return txt;
        }
        if (level.bitrate) return formatBitrate(level.bitrate);
        return 'Level ' + (level.idx ?? '?');
    }
    // 格式化 codec 显示，更友好
    function formatCodecName(codec) {
        if (!codec) return "未知";
        if (codec.includes("avc1")) return "H.264";
        if (codec.includes("hvc1") || codec.includes("hev1")) return "H.265/HEVC";
        if (codec.includes("av01")) return "AV1";
        if (codec.includes("vp9")) return "VP9";
        if (codec.includes("mp4a")) return "AAC"; // 音频
        return codec.split('.')[0].toUpperCase(); // fallback
    }
    // 专门更新码率显示（避免重复逻辑）
    function updateBitrateDisplay(hls) {
        if (!hls) return;
        const currentLevel = hls.levels[hls.currentLevel];
        if (currentLevel?.bitrate > 0) {
            state.streamInfo.bitrate = formatBitrate(currentLevel.bitrate);
        } else if (hls.bandwidthEstimate > 10000) { // 避免太小不显示
            state.streamInfo.bitrate = formatBitrate(hls.bandwidthEstimate) + " (网速)";
        }
    }
    // 友好显示码率（kbps / Mbps）
    function formatBitrate(bitsPerSecond) {
        if (!bitsPerSecond || isNaN(bitsPerSecond)) return "未知";
        if (bitsPerSecond >= 1000000) {
            return (bitsPerSecond / 1000000).toFixed(1) + " Mbps";
        }
        return Math.round(bitsPerSecond / 1000) + " kbps";
    }
    function initNativePlayer(url) {
        destroyPlayer();
        state.streamInfo.type = "原生";
        const lower = url.toLowerCase();
        if (lower.includes(".mp4")) state.streamInfo.type = "MP4";
        else if (lower.includes(".webm")) state.streamInfo.type = "WebM";
        else if (lower.includes(".ogg") || lower.includes(".ogv")) state.streamInfo.type = "OGG";
        UI.videoPlayer.src = url;
        attachCommonVideoEvents();
    }
    function attachCommonVideoEvents() {
        UI.videoPlayer.onloadedmetadata = function() {
            clearTimers(["load"]);
            showLoading(false);
            updateVideoInfoFromElement();
            attemptPlay();
        };
        UI.videoPlayer.onloadeddata = function() {
            updateVideoInfoFromElement();
        };
        UI.videoPlayer.onerror = function() {
            if (!UI.videoPlayer.getAttribute("src") && !UI.videoPlayer.currentSrc) return;
            handleError("视频加载失败或格式不支持");
        };
        UI.videoPlayer.onplay = () => {
            state.isPlaying = true;
            UI.playPauseBtn.textContent = "❚❚";
            UI.playPauseBtn.title = "暂停(空格键)";
        };
        UI.videoPlayer.onpause = () => {
            state.isPlaying = false;
            UI.playPauseBtn.textContent = "▶";
            UI.playPauseBtn.title = "播放(空格键)";
        };
        UI.videoPlayer.ontimeupdate = updateProgress;
        UI.videoPlayer.onvolumechange = updateVolumeIcon;
        UI.videoPlayer.onended = () => {
            if (state.isM3UPlaylist) {
                const item = state.currentPlaylist[state.currentPlaylistIndex];
                if (item && item.urls && item.currentUrlIndex < item.urls.length - 1) {
                    item.currentUrlIndex++;
                    console.log(`当前源播放结束，切换至本频道下一个源: ${item.currentUrlIndex + 1}/${item.urls.length}`);
                    showNotification(`播放结束，切换到源 ${item.currentUrlIndex + 1}/${item.urls.length}`, 1500);
                    const nextUrl = item.urls[item.currentUrlIndex];
                    destroyPlayer();
                    showLoading(true);
                    UI.errorMessage.style.display = "none";
                    UI.videoInfo.textContent = item.title || decodeURIComponent(nextUrl);
                    checkAndInitPlayer(nextUrl);
                    if (state.timers.load) clearTimeout(state.timers.load);
                    state.timers.load = setTimeout(() => {
                        console.error(`加载超时 (${CONFIG.LOAD_TIMEOUT_MS}ms)，切换线路。`);
                        tryNextRedundantUrl();
                    }, CONFIG.LOAD_TIMEOUT_MS);
                    return;
                }
                if (state.currentPlaylistIndex < state.currentPlaylist.length - 1) {
                    playPlaylistItem(state.currentPlaylistIndex + 1);
                }
            }
        };
        UI.videoPlayer.onwaiting = () => {
            if (state.isM3UPlaylist && state.isPlaying) {
                console.warn(`卡顿检测: 启动超时计时器 (${CONFIG.STALL_TIMEOUT_MS}ms)`);
                if (state.timers.stall) clearTimeout(state.timers.stall);
                state.timers.stall = setTimeout(() => {
                    console.error("播放停滞超时，尝试切换线路。");
                    //showNotification("卡顿超时，自动换源", 1500);
                    tryNextRedundantUrl();
                }, CONFIG.STALL_TIMEOUT_MS);
            }
        };
        UI.videoPlayer.onplaying = () => {
            if (state.timers.stall) {
                clearTimeout(state.timers.stall);
                state.timers.stall = null;
            }
        };
    }
    function handleError(msg) {
        if (state.isM3UPlaylist) {
            console.warn(`捕获错误: ${msg} -> 尝试下一个源`);
            tryNextRedundantUrl();
        } else {
            showError(msg);
        }
    }
    let isFirstPlay = true;
    function attemptPlay() {
        const promise = UI.videoPlayer.play();
        if (promise !== undefined) {
            promise.then(() => {
                state.isPlaying = true;
                UI.playPauseBtn.textContent = "❚❚";
                UI.playPauseBtn.title = "暂停(空格键)";
                if (isFirstPlay && !document.fullscreenElement) {
                    isFirstPlay = false;
                }
            }).catch(error => {
                console.error("自动播放被阻止或失败:", error);
                state.isPlaying = false;
                UI.playPauseBtn.textContent = "▶";
                UI.playPauseBtn.title = "播放(空格键)";
            });
        }
    }
    function initM3UPlaylist(url) {
        state.isM3UPlaylist = true;
        state.streamInfo.type = "M3U";
        const parser = new M3UParser;
        parser.parseFromUrl(url).then(playlist => {
            if (!playlist || playlist.length === 0) {
                throw new Error("频道列表为空");
            }
            const processedPlaylist = playlist.map(item => {
                // 假设parser已解析tvg-id，如果没有，这里添加
                if (!item.tvgId && item.attributes) {
                    item.tvgId = item.attributes['tvg-id'];
                }
                const rawUrls = item.urls && item.urls.length > 0 ? item.urls : [item.url];
                const validUrls = rawUrls.filter(u => u).map(u => {
                    if (!u.startsWith("http") && !u.startsWith("//")) {
                        return M3UParser.resolveUrl(state.baseUrl, u);
                    }
                    return u;
                });
                item.urls = validUrls;
                return item;
            }).filter(item => item.urls.length > 0);
            if (processedPlaylist.length === 0) {
                throw new Error("解析后无有效项目");
            }
            if (state.currentPlaylist.length === 0) {
                state.currentPlaylist = processedPlaylist;
                renderPlaylist();
                playPlaylistItem(0);
                togglePlaylistUI(true);
                if (CONFIG.AUTO_REFRESH_ENABLED) {
                    startPlaylistRefreshTimer();
                }
            } else {
                refreshPlaylist(processedPlaylist);
            }
        }).catch(err => {
            console.error("M3U解析失败:", err);
            showError("解析频道列表失败: " + err.message);
        });
    }
    function startPlaylistRefreshTimer() {
        if (state.timers.refreshPlaylist) {
            clearTimeout(state.timers.refreshPlaylist);
            state.timers.refreshPlaylist = null;
        }
        if (!CONFIG.AUTO_REFRESH_ENABLED) {
            console.log('[定时刷新] 自动刷新已禁用');
            return;
        }
        if (CONFIG.PLAYLIST_REFRESH_INTERVAL <= 0) {
            console.log('[定时刷新] 刷新间隔为0，不启用定时刷新');
            return;
        }
        state.timers.refreshPlaylist = setTimeout(() => {
            console.log(`[定时刷新] 开始刷新频道列表...`);
            refreshM3UPlaylist();
        }, CONFIG.PLAYLIST_REFRESH_INTERVAL);
        console.log(`[定时刷新] 已设置定时器，${Math.round(CONFIG.PLAYLIST_REFRESH_INTERVAL/1000)}秒后刷新`);
    }
    function refreshM3UPlaylist() {
        if (!state.isM3UPlaylist || !state.originalPlaylistUrl) {
            console.warn("[定时刷新] 当前不是M3U频道列表或缺少原始URL");
            startPlaylistRefreshTimer();
            return;
        }
        console.log(`[定时刷新] 刷新频道列表: ${state.originalPlaylistUrl}`);
        const parser = new M3UParser;
        parser.parseFromUrl(state.originalPlaylistUrl).then(playlist => {
            if (!playlist || playlist.length === 0) {
                console.warn("[定时刷新] 刷新的频道列表为空");
                startPlaylistRefreshTimer();
                return;
            }
            const processedPlaylist = playlist.map(item => {
                const rawUrls = item.urls && item.urls.length > 0 ? item.urls : [item.url];
                const validUrls = rawUrls.filter(u => u).map(u => {
                    if (!u.startsWith("http") && !u.startsWith("//")) {
                        return M3UParser.resolveUrl(state.baseUrl, u);
                    }
                    return u;
                });
                item.urls = validUrls;
                return item;
            }).filter(item => item.urls.length > 0);
            if (processedPlaylist.length === 0) {
                console.warn("[定时刷新] 解析后无有效项目");
                startPlaylistRefreshTimer();
                return;
            }
            refreshPlaylist(processedPlaylist);
            startPlaylistRefreshTimer();
        }).catch(err => {
            console.error("[定时刷新] M3U解析失败:", err);
            startPlaylistRefreshTimer();
        });
    }
    function refreshPlaylist(newPlaylist) {
        console.log('[定时刷新] 开始刷新频道列表...');
        const oldIndex = state.currentPlaylistIndex;
        const oldItem = oldIndex >= 0 ? state.currentPlaylist[oldIndex] : null;
        if (oldItem) {
            state.currentChannelInfo = {
                title: oldItem.title || "",
                originalIndex: oldIndex,
                urls: [...oldItem.urls],
                currentUrlIndex: oldItem.currentUrlIndex || 0,
                currentRound: oldItem.currentRound || 1
            };
            console.log(`[定时刷新] 保存当前频道: "${state.currentChannelInfo.title}"`);
        }
        const oldPlaylist = [...state.currentPlaylist];
        state.currentPlaylist = newPlaylist;
        let newIndex = -1;
        if (state.currentChannelInfo.title) {
            newIndex = state.currentPlaylist.findIndex(item =>
                item.title === state.currentChannelInfo.title
            );
            if (newIndex === -1 && state.currentChannelInfo.urls.length > 0) {
                newIndex = state.currentPlaylist.findIndex(item =>
                    item.urls && item.urls.some(url =>
                        state.currentChannelInfo.urls.includes(url)
                    )
                );
            }
        }
        if (newIndex === -1) {
            console.log(`[定时刷新] 当前频道在新列表中不存在，继续播放原频道`);
            if (oldItem) {
                const preservedItem = {
                    ...oldItem,
                    title: oldItem.title ? `${oldItem.title} (旧列表)` : "旧列表频道"
                };
                state.currentPlaylist.push(preservedItem);
                newIndex = state.currentPlaylist.length - 1;
                state.currentPlaylistIndex = newIndex;
            }
        } else {
            console.log(`[定时刷新] 在新列表中找到当前频道，位置: ${newIndex}`);
            state.currentPlaylistIndex = newIndex;
            const newItem = state.currentPlaylist[newIndex];
            if (newItem.urls && newItem.urls.length > 0) {
                newItem.currentUrlIndex = oldItem ? oldItem.currentUrlIndex || 0 : 0;
                newItem.currentRound = oldItem ? oldItem.currentRound || 1 : 1;
            }
        }
        renderPlaylist(UI.playlistSearchInput.value);
        updatePlaylistHighlight();
        if (!UI.playlistContainer.classList.contains("hidden")) {
            const currentSearch = UI.playlistSearchInput.value;
            if (currentSearch) {
                renderPlaylist(currentSearch);
            }
            addRefreshIndicator();
        }
        showRefreshNotification(`频道列表已刷新: ${oldPlaylist.length} → ${newPlaylist.length} 个频道`);
        console.log(`[定时刷新] 频道列表刷新完成: ${oldPlaylist.length} → ${newPlaylist.length} 个频道`);
    }
    function addRefreshIndicator() {
        const oldIndicator = UI.playlistContainer.querySelector('.refresh-indicator');
        if (oldIndicator) {
            oldIndicator.remove();
        }
        const indicator = document.createElement('div');
        indicator.className = 'refresh-indicator';
        indicator.textContent = '刷新中...';
        indicator.style.cssText = `
            position: absolute;
            top: 10px;
            right: 10px;
            background: rgba(0, 100, 0, 0.8);
            color: white;
            padding: 5px 10px;
            border-radius: 3px;
            font-size: 12px;
            z-index: 1002;
        `;
        UI.playlistContainer.appendChild(indicator);
        setTimeout(() => {
            if (indicator.parentNode) {
                indicator.parentNode.removeChild(indicator);
            }
        }, 1500);
    }
    function showRefreshNotification(message) {
        const oldNotifications = document.querySelectorAll('.refresh-notification');
        oldNotifications.forEach(n => n.remove());
        const notification = document.createElement("div");
        notification.className = "refresh-notification";
        notification.textContent = message;
        if (!document.querySelector('#refresh-notification-style')) {
            const style = document.createElement('style');
            style.id = 'refresh-notification-style';
            style.textContent = `
                @keyframes fadeInOut {
                    0% { opacity: 0; transform: translateY(-10px); }
                    10% { opacity: 1; transform: translateY(0); }
                    90% { opacity: 1; transform: translateY(0); }
                    100% { opacity: 0; transform: translateY(-10px); }
                }
                .refresh-notification {
                    pointer-events: none;
                }
            `;
            document.head.appendChild(style);
        }
        document.body.appendChild(notification);
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 3000);
    }
    function manualSwitchToNextSource() {
        if (state.currentPlaylistIndex === -1) return;
        const item = state.currentPlaylist[state.currentPlaylistIndex];
        if (!item || !item.urls || item.urls.length === 0) {
            showError("当前频道没有可用的源");
            return;
        }
        /*if (item.urls.length <= 1) {
            showNotification("当前频道只有一个源", 1500);
            return;
        }*/
        if (item.currentUrlIndex === undefined) item.currentUrlIndex = 0;
        if (item.currentRound === undefined) item.currentRound = 1;
        const nextIndex = (item.currentUrlIndex + 1) % item.urls.length;
        if (nextIndex === 0) {
            if (item.currentRound < CONFIG.MAX_RETRY_ROUNDS) {
                item.currentRound++;
            }
        }
        console.log(`[手动换源] 从源 ${item.currentUrlIndex + 1} 切换到源 ${nextIndex + 1} (轮次: ${item.currentRound}/${CONFIG.MAX_RETRY_ROUNDS})`);
        item.currentUrlIndex = nextIndex;
        const nextUrl = item.urls[nextIndex];
        // 检查黑名单
        if (checkUrlInBlacklist(nextUrl, "手动换源URL")) {
            // 如果被拦截，继续尝试下一个
            setTimeout(() => manualSwitchToNextSource(), 500);
            return;
        }
        showLoading(true);
        UI.errorMessage.style.display = "none";
        showNotification(`切换到源 ${nextIndex + 1}/${item.urls.length}`, 2000);
        destroyPlayer();
        checkAndInitPlayer(nextUrl);
        if (state.timers.load) clearTimeout(state.timers.load);
        state.timers.load = setTimeout(() => {
            console.error(`[手动换源] 加载超时 (${CONFIG.LOAD_TIMEOUT_MS}ms)，触发自动换源逻辑。`);
            tryNextRedundantUrl();
        }, CONFIG.LOAD_TIMEOUT_MS);
        setTimeout(updateInfoPanel, 500);
    }
    function showNotification(message, type = 'info', duration = 2000) {
        // 1. 获取现有通知元素
        let notification = document.querySelector('.source-notification');
        
        // 定义颜色映射
        const typeStyles = {
            'info': 'rgba(0, 100, 200, 0.9)',
            'success': 'rgba(40, 167, 69, 0.9)',
            'warning': 'rgba(255, 152, 0, 0.9)'
        };
        const backgroundColor = typeStyles[type] || typeStyles['info'];
    
        // 2. 优化：如果已存在，直接复用并更新，避免频繁操作 DOM
        if (notification) {
            // 清除之前的定时销毁任务
            if (notification.timer) clearTimeout(notification.timer);
            
            notification.textContent = message;
            notification.style.background = backgroundColor;
            
            // 关键：重置动画（通过小技巧触发重新播放）
            notification.style.animation = 'none';
            notification.offsetHeight; // 触发 reflow
            notification.style.animation = `fadeInOut ${duration/1000}s ease-in-out forwards`;
        } else {
            // 3. 首次创建元素
            notification = document.createElement("div");
            notification.className = "source-notification";
            notification.textContent = message;
            notification.style.cssText = `
                position: fixed;
                top: 20px;
                left: 50%;
                transform: translateX(-50%);
                background: ${backgroundColor};
                color: white;
                padding: 10px 15px;
                border-radius: 5px;
                z-index: 1000;
                font-size: 14px;
                box-shadow: 0 4px 12px rgba(0,0,0,0.15);
                pointer-events: none;
                animation: fadeInOut ${duration/1000}s ease-in-out forwards;
            `;
            document.body.appendChild(notification);
        }
    
        // 4. 设置定时销毁
        notification.timer = setTimeout(() => {
            if (notification && notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, duration);
    }
    function tryNextRedundantUrl() {
        if (state.currentPlaylistIndex === -1) return;
        const item = state.currentPlaylist[state.currentPlaylistIndex];
        if (!item || !item.urls || item.urls.length === 0) {
            showError("频道列表数据错误");
            return;
        }
        if (item.currentRound === undefined) item.currentRound = 1;
        if (item.currentUrlIndex === undefined) item.currentUrlIndex = 0;
        const nextIndex = item.currentUrlIndex + 1;
        if (nextIndex < item.urls.length) {
            item.currentUrlIndex = nextIndex;
        } else if (item.currentRound < CONFIG.MAX_RETRY_ROUNDS) {
            item.currentUrlIndex = 0;
            item.currentRound++;
            console.warn(`频道 [${item.title}] 开启第 ${item.currentRound}/${CONFIG.MAX_RETRY_ROUNDS} 轮尝试...`);
            showNotification(`第 ${item.currentRound} 轮尝试 (共 ${CONFIG.MAX_RETRY_ROUNDS} 轮)`, 2000);
        } else {
            if (state.timers.load) {
                clearTimeout(state.timers.load);
                state.timers.load = null;
            }
            destroyPlayer();
            state.isPlaying = false;
            UI.playPauseBtn.textContent = "▶";
            UI.playPauseBtn.title = "播放";
            showError(`频道 [${item.title || "未知"}] 无法播放或太过卡顿，请尝试其他频道。`);
            return;
        }
        const nextUrl = item.urls[item.currentUrlIndex];
        // 检查黑名单
        if (checkUrlInBlacklist(nextUrl, "自动换源URL")) {
            // 如果被拦截，继续尝试下一个
            setTimeout(() => tryNextRedundantUrl(), 500);
            return;
        }
        console.warn(`自动换源 (轮次:${item.currentRound}, 索引:${item.currentUrlIndex}): ${nextUrl}`);
        showNotification(`自动切换到源 ${item.currentUrlIndex + 1}/${item.urls.length}`, 1500);
        destroyPlayer();
        showLoading(true);
        UI.errorMessage.style.display = "none";
        checkAndInitPlayer(nextUrl);
        state.timers.load = setTimeout(() => {
            console.error(`加载超时 (${CONFIG.LOAD_TIMEOUT_MS}ms)，切换线路。`);
            tryNextRedundantUrl();
        }, CONFIG.LOAD_TIMEOUT_MS);
    }
    function playPlaylistItem(index) {
        if (index < 0 || index >= state.currentPlaylist.length) return;
        const item = state.currentPlaylist[index];
        const itemUrl = item.urls[0];
        // 检查URL是否在黑名单中
        if (checkUrlInBlacklist(itemUrl, "频道列表URL")) {
            return;
        }
        state.currentPlaylistIndex = index;
        item.currentUrlIndex = 0;
        item.currentRound = 1;
        state.currentChannelInfo = {
            title: item.title || "",
            originalIndex: index,
            urls: [...item.urls]
        };
        updatePlaylistHighlight();
        UI.videoInfo.textContent = item.title || decodeURIComponent(itemUrl);
        destroyPlayer();
        showLoading(true);
        UI.errorMessage.style.display = "none";
        checkAndInitPlayer(itemUrl);
        state.timers.load = setTimeout(() => {
            console.error(`加载超时 (${CONFIG.LOAD_TIMEOUT_MS}ms)，切换线路。`);
            tryNextRedundantUrl();
        }, CONFIG.LOAD_TIMEOUT_MS);
    }
    function renderPlaylist(searchTerm = "") {
        UI.playlistItems.innerHTML = "";
        const lowerTerm = searchTerm.toLowerCase();
        const fragment = document.createDocumentFragment();
        state.currentPlaylist.forEach((item, index) => {
            const channelName = item.title || `项目 ${index + 1}`;
            if (searchTerm && !channelName.toLowerCase().includes(lowerTerm)) {
                return;
            }
            const el = document.createElement("div");
            el.className = "playlist-item";
            if (index === state.currentPlaylistIndex) el.classList.add("active");
            el.textContent = channelName;
            el.dataset.index = index;
            el.onclick = () => {
                playPlaylistItem(index);
                // 点击后保持频道列表焦点状态
                maintainPlaylistFocus();
            };
            setupButtonHoverEffects(el);
            // 添加鼠标和焦点事件以显示EPG弹出框
            el.addEventListener('mouseenter', () => showEpgPopup(el, item));
            el.addEventListener('mouseleave', hideEpgPopup);
            el.addEventListener('focus', () => showEpgPopup(el, item));
            el.addEventListener('blur', hideEpgPopup);
            // 如果EPG启用，添加当前节目显示
            if (CONFIG.EPG_ENABLED) {
                const chId = getChannelId(item);
                const programs = state.epgData[chId] || [];
                const current = getCurrentProgram(programs);
                if (current) {
                    const span = document.createElement('span');
                    span.className = 'current-program';
                    span.textContent = `当前: ${current.title}`;
                    el.appendChild(span);
                }
            }
            fragment.appendChild(el);
        });
        UI.playlistItems.appendChild(fragment);
    }
    function updatePlaylistHighlight() {
        const items = UI.playlistItems.children;
        for (let el of items) {
            if (parseInt(el.dataset.index) === state.currentPlaylistIndex) {
                el.classList.add("active");
                el.scrollIntoView({
                    behavior: "smooth",
                    block: "nearest"
                });
            } else {
                el.classList.remove("active");
            }
        }
    }
    function handlePlaylistSearch(e) {
        const term = e.target.value;
        if (term) UI.clearSearchBtn.classList.add("visible");
        else UI.clearSearchBtn.classList.remove("visible");
        if (state.timers.searchDebounce) clearTimeout(state.timers.searchDebounce);
        state.timers.searchDebounce = setTimeout(() => {
            renderPlaylist(term);
            // 搜索后清除选中项
            const selectedItem = UI.playlistItems.querySelector('.selected');
            if (selectedItem) {
                selectedItem.classList.remove('selected');
            }
        }, CONFIG.SEARCH_DEBOUNCE_MS);
    }
    function clearSearch() {
        UI.playlistSearchInput.value = "";
        UI.clearSearchBtn.classList.remove("visible");
        renderPlaylist("");
        // 清除选中项
        const selectedItem = UI.playlistItems.querySelector('.selected');
        if (selectedItem) {
            selectedItem.classList.remove('selected');
        }
    }
    function updateVideoInfoFromElement() {
        if (UI.videoPlayer.videoWidth && UI.videoPlayer.videoHeight) {
            state.streamInfo.resolution = `${UI.videoPlayer.videoWidth}x${UI.videoPlayer.videoHeight}`;
        }
        updateInfoPanel();
    }
    function updateResolutionFromHls(hls) {
        if (!hls?.levels?.length) return;
        let idx = hls.currentLevel;
        // 自动模式下优先使用最近一次自适应结果
        if (idx < 0 && hls.autoLevelEnabled) {
            idx = hls.autoLevelLast >= 0 ? hls.autoLevelLast :
                  hls.nextLoadLevel >= 0   ? hls.nextLoadLevel : 0;
        }
        // 防止索引越界（虽然正常情况下不应该发生，但防御性编程）
        idx = Math.max(0, Math.min(idx, hls.levels.length - 1));
        const level = hls.levels[idx];
        if (level?.width > 0 && level?.height > 0) {
            state.streamInfo.resolution = `${level.width}×${level.height}`;
        }
        // 可选：增加 video 元素 fallback（最保险）
        else if (hls.media?.videoWidth > 0 && hls.media?.videoHeight > 0) {
            state.streamInfo.resolution = `${hls.media.videoWidth}×${hls.media.videoHeight}(ｖ)`;
        }
        updateInfoPanel();
    }
    function updateInfoPanel() {
        const lines = [
            `类型: ${state.streamInfo.type}`,    
            `分辨率: ${state.streamInfo.resolution}`            
        ];
        if (state.streamInfo.type==="HLS") {
            lines.push(`码率: ${state.streamInfo.bitrate}`);
        }
        if (state.streamInfo.type==="HLS" || state.streamInfo.type==="TS" || state.streamInfo.type==="FLV") {
            lines.push(`编码: ${state.streamInfo.codec}`);
        }        
        if (state.isM3UPlaylist && state.currentPlaylistIndex >= 0) {
            const item = state.currentPlaylist[state.currentPlaylistIndex];
            if (item) {
                const totalUrls = item.urls ? item.urls.length : 0;
                const currentIndex = (item.currentUrlIndex || 0) + 1;
                const round = item.currentRound || 1;
                if (totalUrls >= 1) {
                    lines.push(`源: ${currentIndex}/${totalUrls}`);
                    //lines.push(`轮次: ${round}/${CONFIG.MAX_RETRY_ROUNDS}`);
                }                
                lines.push(`频道列表: ${state.currentPlaylistIndex + 1}/${state.currentPlaylist.length}`);
                //lines.push(`加载超时: ${Math.round(CONFIG.LOAD_TIMEOUT_MS/1000)}秒`);
                //lines.push(`卡顿超时: ${Math.round(CONFIG.STALL_TIMEOUT_MS/1000)}秒`);
                //lines.push(`最大重试: ${CONFIG.MAX_RETRY_ROUNDS}轮`);
                if (CONFIG.AUTO_REFRESH_ENABLED && state.timers.refreshPlaylist) {
                    lines.push(`列表刷新: ${Math.round(CONFIG.PLAYLIST_REFRESH_INTERVAL/60000)}分钟`);
                }
                if (item.title && item.title.includes("(旧列表)")) {
                    lines.push(`状态: 来自旧列表`);
                }
            }
        }
        // 添加黑名单信息
        if (state.blacklist.length > 0) {
            lines.push(`黑名单: ${state.blacklist.length}个规则`);
        }
        // 创建带颜色分类的HTML内容
        const coloredLines = lines.map(line => {
            if (line.includes(':')) {
                const parts = line.split(':');
                const label = parts[0];
                const value = parts.slice(1).join(':').trim();
                return `<div class="info-line"><span class="info-label">${label}</span> <span class="info-maohao">:</span> <span class="info-value">${value}</span></div>`;
            }
            return `<div class="info-line"><span class="info-label">${line}</span></div>`;
        });
        UI.infoPanel.innerHTML = coloredLines.join('');
    }
    function toggleVideoInfo() {
        updateInfoPanel();
        const currentDisplay = UI.infoPanel.style.display;
        UI.infoPanel.style.display = currentDisplay === "none" ? "block" : "none";
    }
    function updateProgress() {
        const { currentTime, duration } = UI.videoPlayer;
        if (duration && !isNaN(duration) && duration !== Infinity) {
            const percent = currentTime / duration * 100;
            UI.progressBar.style.width = percent + "%";
            UI.timeDisplay.textContent = `${formatTime(currentTime)} / ${formatTime(duration)}`;
        } else {
            UI.progressBar.style.width = "100%";
            UI.timeDisplay.textContent = `${formatTime(currentTime)} / Live`;
        }
    }
    function seek(e) {
        if (!UI.videoPlayer.duration || UI.videoPlayer.duration === Infinity) return;
        const rect = UI.progress.getBoundingClientRect();
        const pos = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
        UI.videoPlayer.currentTime = pos * UI.videoPlayer.duration;
    }
    function adjustVolume(e) {
        const rect = UI.volumeSlider.getBoundingClientRect();
        let volume = (e.clientX - rect.left) / rect.width;
        volume = Math.max(0, Math.min(1, volume));
        UI.videoPlayer.volume = volume;
        UI.volumeProgress.style.width = volume * 100 + "%";
        updateVolumeIcon();
        chrome.storage.local.set({
            volume: volume
        });
    }
    function updateVolumeIcon() {
        const v = UI.videoPlayer.volume;
        if (UI.videoPlayer.muted || v === 0) UI.volumeBtn.textContent = "🔇";
        else if (v < .5) UI.volumeBtn.textContent = "🔉";
        else UI.volumeBtn.textContent = "🔊";
    }
    function toggleMute() {
        UI.videoPlayer.muted = !UI.videoPlayer.muted;
        updateVolumeIcon();
    }
    function toggleFullscreen() {
        const container = document.querySelector(".player-container");
        if (!document.fullscreenElement) {
            (container.requestFullscreen || container.webkitRequestFullscreen || container.msRequestFullscreen).call(container);
        } else {
            (document.exitFullscreen || document.webkitExitFullscreen || document.msExitFullscreen).call(document);
        }
    }
    function initAudioContext() {
        if (state.audioContext) return;
        try {
            state.audioContext = new (window.AudioContext || window.webkitAudioContext)();
            state.sourceNode = state.audioContext.createMediaElementSource(UI.videoPlayer);
            state.dynamicsCompressor = state.audioContext.createDynamicsCompressor();
            // 配置压缩器以实现响度均衡
            state.dynamicsCompressor.threshold.setValueAtTime(-24, state.audioContext.currentTime);
            state.dynamicsCompressor.knee.setValueAtTime(30, state.audioContext.currentTime);
            state.dynamicsCompressor.ratio.setValueAtTime(12, state.audioContext.currentTime);
            state.dynamicsCompressor.attack.setValueAtTime(0.003, state.audioContext.currentTime);
            state.dynamicsCompressor.release.setValueAtTime(0.25, state.audioContext.currentTime);
            state.sourceNode.connect(state.audioContext.destination);
        } catch (e) {
            console.error('Web Audio API 初始化失败:', e);
        }
    }
    function toggleLoudnessEqualizer(forceState) {
        if (!state.audioContext) initAudioContext();
        if (!state.audioContext) return;
        // 修复：如果是点击事件触发，forceState 会是 Event 对象，此时应视为 undefined
        const actualForceState = (typeof forceState === 'boolean') ? forceState : undefined;
        if (actualForceState !== undefined) {
            state.isLoudnessEnabled = actualForceState;
        } else {
            state.isLoudnessEnabled = !state.isLoudnessEnabled;
        }
        // 保存状态到 storage
        chrome.storage.local.set({ loudnessEnabled: state.isLoudnessEnabled });
        if (state.isLoudnessEnabled) {
            state.sourceNode.disconnect();
            state.sourceNode.connect(state.dynamicsCompressor);
            state.dynamicsCompressor.connect(state.audioContext.destination);
            UI.loudnessBtn.style.color = '#1E90FF';
            //UI.loudnessBtn.title = '响度均衡: 开启(L)';
            showNotification("响度均衡已开启",'success', 1500);
        } else {
            state.sourceNode.disconnect();
            state.dynamicsCompressor.disconnect();
            state.sourceNode.connect(state.audioContext.destination);
            UI.loudnessBtn.style.color = 'white';
            //UI.loudnessBtn.title = '响度均衡: 关闭(L)';
            showNotification("响度均衡已关闭",'info', 1500);
        }
        if (state.audioContext.state === 'suspended') {
            state.audioContext.resume();
        }
    }
    function togglePlayPause() {
        if (UI.videoPlayer.paused) attemptPlay();
        else UI.videoPlayer.pause();
    }
    function showControls() {
        UI.controls.classList.remove("hidden");
        if (state.timers.controls) clearTimeout(state.timers.controls);
        state.timers.controls = setTimeout(() => {
            if (state.isPlaying) {
                UI.controls.classList.add("hidden");
            }
        }, 30000);
    }
    function initGlobalEvents() {
        document.addEventListener("mousemove", showControls);
        // 添加键盘事件监听
        document.addEventListener("keydown", handleKeyDown);
        // 新增：进阶面板开关
        UI.advancedBtn.onclick = (e) => {
            e.stopPropagation();
            const isVisible = UI.advancedPanel.style.display !== 'none';
            UI.advancedPanel.style.display = isVisible ? 'none' : 'block';
        };
        // 点击其他地方关闭
        document.addEventListener('click', (e) => {
            if (!e.target.closest('.advanced-btn') && 
                !e.target.closest('.advanced-panel')) {
                if (UI.advancedPanel) UI.advancedPanel.style.display = 'none';
            }
        });
        UI.playPauseBtn.onclick = togglePlayPause;
        UI.prevChannelBtn.onclick = function(e) {
            e.stopPropagation();
            switchToPrevChannel();
        };
        UI.nextChannelBtn.onclick = function(e) {
            e.stopPropagation();
            switchToNextChannel();
        };
        UI.volumeBtn.onclick = toggleMute;
        UI.volumeSlider.onclick = adjustVolume;
        UI.fullscreenBtn.onclick = toggleFullscreen;
        UI.backBtn.onclick = () => window.close();
        UI.infoBtn.onclick = toggleVideoInfo;
        UI.playlistBtn.onclick = () => togglePlaylistUI();
        UI.closePlaylistBtn.onclick = () => togglePlaylistUI(false);
        UI.progress.onclick = seek;
        UI.playlistSearchInput.oninput = handlePlaylistSearch;
        UI.clearSearchBtn.onclick = clearSearch;
        UI.switchSourceBtn.onclick = function(e) {
            e.stopPropagation();
            manualSwitchToNextSource();
        };
        UI.playlistContainer.onmouseleave = () => {
            if (document.activeElement !== UI.playlistSearchInput) {
                state.timers.hidePlaylist = setTimeout(() => togglePlaylistUI(false), 300);
            }
        };
        UI.playlistContainer.onmouseenter = () => {
            if (state.timers.hidePlaylist) clearTimeout(state.timers.hidePlaylist);
        };
    }
    window.addEventListener('beforeunload', function() {
        if (state.timers.refreshPlaylist) {
            clearTimeout(state.timers.refreshPlaylist);
            console.log('[清理] 频道列表刷新定时器已清理');
        }
        if (state.timers.load) {
            clearTimeout(state.timers.load);
            console.log('[清理] 加载定时器已清理');
        }
        if (state.timers.stall) {
            clearTimeout(state.timers.stall);
            console.log('[清理] 卡顿定时器已清理');
        }
        if (state.timers.epgRefresh) {
            clearTimeout(state.timers.epgRefresh);
            console.log('[清理] EPG刷新定时器已清理');
        }
    });
    init();
});